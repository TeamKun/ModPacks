package handmadevehicle2.add;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import handmadevehicle2.item.ItemSpawnHMV2;
import handmadevehicle2.mod_HandmadeVehicle2;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import objmodel.AdvancedModelLoader;


import handmadevehicle2.mod_HandmadeVehicle2;
import handmadevehicle2.item.ItemSpawnHMV2;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import objmodel.AdvancedModelLoader;

public class HMVAddVehicle2 {
	
	static boolean vacanspawn = false;
	static int spawn_rare = 10;
	
	static Item itema;
	  static Item itemb;
	  static Item itemc;
	  static Item itemd;
	  static Item iteme;
	  static Item itemf;
	  static Item itemg;
	  static Item itemh;
	  static Item itemi;
	  static String re1 = "abc";
	  static String re2 = "def";
	  static String re3 = "ghi";
	
	  static boolean cansell = true;
	  
	static int sell_eme;
	  static int sell_iron;
	  static int sell_red;
	
	  static String USname = null;
	  static String JPname = null;
	  
	public static void load(boolean isClient, InputStream inputStream, String domain,  RegistryEvent.Register<Item> event) {
		
		{
			itema = Item.func_150899_d(0);
			itemb = Item.func_150899_d(0);
			itemc = Item.func_150899_d(0);
			itemd = Item.func_150899_d(0);
			iteme = Item.func_150899_d(0);
			itemf = Item.func_150899_d(0);
			itemg = Item.func_150899_d(0);
			itemh = Item.func_150899_d(0);
			itemi = Item.func_150899_d(0);
			re1 = "abc";
			re2 = "def";
			re3 = "ghi";

			cansell = true;
			
			sell_eme = 1;
			sell_iron = 1;
			sell_red = 1;
			USname = null;
			JPname = null;
			
			vacanspawn = false;
			spawn_rare = 10;
		}
		
		Item newgun = null;
		try {
			
			// File file = new File(configfile,"hmg_handmadeguns.txt");
			{
				BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
				//BufferedReader br = new BufferedReader(new FileReader(file)); // ファイルを開く

				String str;
				while ((str = br.readLine()) != null) { // 1行ずつ読み込む
					// System.out.println(str);
					String[] type = str.split(",");

					int guntype = 0;

					if (type.length != 0) {// 1
						if (type[0].equals("ADD_LIST")) {
							cansell = Boolean.parseBoolean(type[1]);
						}
						
						if (type[0].equals("Sell_EMERALD")) {
							sell_eme = Integer.parseInt(type[1]);
						}
						if (type[0].equals("Sell_IRONINGOT")) {
							sell_iron = Integer.parseInt(type[1]);
						}
						if (type[0].equals("Sell_REDSTONE")) {
							sell_red = Integer.parseInt(type[1]);
						}
						if (type[0].equals("USname")) {
							USname = type[1];
						}
						if (type[0].equals("JPname")) {
							JPname = type[1];
						}
						
						if(type[0].equals("vacanspawn")){
							vacanspawn = Boolean.parseBoolean(type[1]);
	            		}
						
						if (type[0].equals("Vehicle")) {
							String GunName = type[1];
							newgun = new ItemSpawnHMV2(0).func_77655_b(GunName).setRegistryName(mod_HandmadeVehicle2.MOD_ID,GunName)
											.func_77637_a(mod_HandmadeVehicle2.tabhmv);
							//ItemGunBase gun = (ItemGunBase) newgun;
							event.getRegistry().register(newgun);
							{
								mod_HandmadeVehicle2.gun_model_item[mod_HandmadeVehicle2.gun_model_id] = newgun;
								mod_HandmadeVehicle2.gun_model_name[mod_HandmadeVehicle2.gun_model_id] = GunName;
								++mod_HandmadeVehicle2.gun_model_id;
							}
							if(cansell){
								mod_HandmadeVehicle2.gun_eme[mod_HandmadeVehicle2.gun_id] = sell_eme;
								mod_HandmadeVehicle2.gun_iron[mod_HandmadeVehicle2.gun_id] = sell_iron;
								mod_HandmadeVehicle2.gun_red[mod_HandmadeVehicle2.gun_id] = sell_red;
								mod_HandmadeVehicle2.gun_item[mod_HandmadeVehicle2.gun_id] = newgun;
								++mod_HandmadeVehicle2.gun_id;
							}
							if(vacanspawn) {
								
								mod_HandmadeVehicle2.spawn_entity[mod_HandmadeVehicle2.max_spawn] = newgun;
								++mod_HandmadeVehicle2.max_spawn;
								ItemSpawnHMV2 vehicle = (ItemSpawnHMV2) newgun;
								vehicle.vacanspawn = true;
								System.out.println(String.format("add_vehicle_spawn"));
							}
							createlang(GunName);
						}
						
						if(newgun != null && newgun instanceof  ItemSpawnHMV2) {
							ItemSpawnHMV2 vehicle = (ItemSpawnHMV2) newgun;
							
							if(mod_HandmadeVehicle2.proxy.getClient()){
								if (type[0].equals("ObjModel")) {
									vehicle.model = AdvancedModelLoader
											.loadModel(new ResourceLocation("handmadevehicle2:addvehicle/" +domain + "/addmodel/" + type[1]));
								}
								if (type[0].equals("ObjTexture")) {
									vehicle.tex = new ResourceLocation("handmadevehicle2:addvehicle/" +domain + "/addmodel/" + type[1]);
								}
							}
							
							if(type[0].equals("exhaust_model")){
								 {
									 vehicle.exhaust_model = "handmadevehicle2:addvehicle/" +domain + "/addmodel/" + type[1];
								}
		            		}
							if(type[0].equals("exhaust_tex")){
								 {
									 vehicle.exhaust_tex = "handmadevehicle2:addvehicle/" +domain + "/addmodel/" + type[1];
								}
		            		}
							
							
							if(type[0].equals("vacanspawn")){
								//vehicle.vacanspawn = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("spawn_rare")){
								vehicle.spawn_rare = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("bomber_sighting")){
								vehicle.bomber_sighting = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("spg_sighting")){
								vehicle.spg_sighting = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("amphibious")){
								vehicle.amphibious = Boolean.parseBoolean(type[1]);
		            		}
							
							if(type[0].equals("ridding_roteplayer")){
								vehicle.ridding_roteplayer = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("riddng_maximum")){
								vehicle.riddng_maximum = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("riddingx")){
								for(int w1 = 0; w1 < vehicle.riddng_maximum; ++w1) {
									vehicle.riddingx[w1] = Double.parseDouble(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("riddingy")){
								for(int w1 = 0; w1 < vehicle.riddng_maximum; ++w1) {
									vehicle.riddingy[w1] = Double.parseDouble(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("riddingz")){
								for(int w1 = 0; w1 < vehicle.riddng_maximum; ++w1) {
									vehicle.riddingz[w1] = Double.parseDouble(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("riddingx_roteplayer")){
								for(int w1 = 0; w1 < vehicle.riddng_maximum; ++w1) {
									vehicle.riddingx_roteplayer[w1] = Double.parseDouble(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("riddingy_roteplayer")){
								for(int w1 = 0; w1 < vehicle.riddng_maximum; ++w1) {
									vehicle.riddingy_roteplayer[w1] = Double.parseDouble(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("riddingz_roteplayer")){
								for(int w1 = 0; w1 < vehicle.riddng_maximum; ++w1) {
									vehicle.riddingz_roteplayer[w1] = Double.parseDouble(type[w1 + 1]);
								}
		            		}
							
							
							if(type[0].equals("ridding_view1_x")){
								vehicle.ridding_view1_x = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("ridding_view1_y")){
								vehicle.ridding_view1_y = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("ridding_view1_z")){
								vehicle.ridding_view1_z = Float.parseFloat(type[1]);
		            		}
							
							if(type[0].equals("ridding_view_x")){
								vehicle.ridding_view_x = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("ridding_view_y")){
								vehicle.ridding_view_y = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("ridding_view_z")){
								vehicle.ridding_view_z = Float.parseFloat(type[1]);
		            		}
							
							
							
							if(type[0].equals("ridding_invisible")){
								vehicle.ridding_invisible = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("ridding_zoom")){
								vehicle.ridding_zoom = Float.parseFloat(type[1]);
		            		}
							
							if(type[0].equals("hud_icon")){
								vehicle.hud_icon = "handmadevehicle2:addvehicle/" +domain + "/addhud/" +type[1];
		            		}
							if(type[0].equals("render_hud_icon_hori")){
								vehicle.render_hud_icon_hori = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("hud_icon_hori")){
								vehicle.hud_icon_hori = "handmadevehicle2:addvehicle/" +domain + "/addhud/" +type[1];
		            		}
							if(type[0].equals("renderhud")){
								vehicle.renderhud = Boolean.parseBoolean(type[1]);
		            		}
							
							if(type[0].equals("hud_icon_scope")){
								vehicle.hud_icon_scope = "handmadevehicle2:addvehicle/" +domain + "/addoverlay/" + type[1];
		            		}
							if(type[0].equals("render_hud_scope")){
								vehicle.render_hud_scope = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("hud_icon_scope_zoom")){
								vehicle.hud_icon_scope_zoom = "handmadevehicle2:addvehicle/" +domain + "/addoverlay/" + type[1];
		            		}
							if(type[0].equals("render_hud_scope_zoom")){
								vehicle.render_hud_scope_zoom = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("render_rader")){
								vehicle.render_rader = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("aarader")){
								vehicle.aarader = Boolean.parseBoolean(type[1]);
		            		}
							
							if(type[0].equals("roodbreak")){
								vehicle.roodbreak = Boolean.parseBoolean(type[1]);
		            		}
							
							
							if(type[0].equals("vehicletype")){
								vehicle.vehicletype = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("movesound")){
								vehicle.movesound = type[1];
		            		}
							if(type[0].equals("hp")){
								vehicle.maxhp = Double.parseDouble(type[1]);
		            		}
							if(type[0].equals("width")){
								vehicle.setwidth = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("height")){
								vehicle.setheight = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("riddng_opentop")){
								vehicle.riddng_opentop = Boolean.parseBoolean(type[1]);
		            		}
							
							if(type[0].equals("damage_angle")){
								vehicle.damage_front = Float.parseFloat(type[1]);
								vehicle.damage_side = Float.parseFloat(type[2]);
								vehicle.damage_rear = Float.parseFloat(type[3]);
								vehicle.damage_top = Float.parseFloat(type[4]);
								vehicle.damage_bottom = Float.parseFloat(type[5]);
		            		}
							if(type[0].equals("can_turret")){
								vehicle.can_turret = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("turret_height")){
								vehicle.turret_height = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("damage_turret_angle")){
								vehicle.damage_turret_front = Float.parseFloat(type[1]);
								vehicle.damage_turret_side = Float.parseFloat(type[1]);
								vehicle.damage_turret_rear = Float.parseFloat(type[3]);
		            		}
							
							if(type[0].equals("antibullet")){
								vehicle.antibullet_0 = Float.parseFloat(type[1]);
								vehicle.antibullet_1 = Float.parseFloat(type[1]);
								vehicle.antibullet_2 = Float.parseFloat(type[3]);
								vehicle.antibullet_3 = Float.parseFloat(type[4]);
		            		}
							if(type[0].equals("ridding_damege")){
								vehicle.ridding_damege = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("speed")){
								vehicle.sp = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("turnspeed")){
								vehicle.turnspeed = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("stepHeight")){
								vehicle.stepHeight = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("trottlemax")){
								vehicle.thmax = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("trottlemin")){
								vehicle.thmin = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("trottleaccelerationmax")){
								vehicle.thmaxa = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("trottleaccelerationmin")){
								vehicle.thmina = Float.parseFloat(type[1]);
		            		}
							
							if(type[0].equals("angle_max")){
								vehicle.rotationp_max = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("angle_min")){
								vehicle.rotationp_min = Float.parseFloat(type[1]);
		            		}
							
							if(type[0].equals("ridding_rotation_lock")){
								vehicle.ridding_rotation_lock = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("angle_yaw_max")){
								vehicle.rotation_max = Float.parseFloat(type[1]);
		            		}
							
							if(type[0].equals("model_angle_base_x")){
								vehicle.model_angle_base_x = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("model_angle_base_y")){
								vehicle.model_angle_base_y = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("model_angle_base_z")){
								vehicle.model_angle_base_z = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("model_angle_offset_x")){
								vehicle.model_angle_offset_x = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("model_angle_offset_y")){
								vehicle.model_angle_offset_y = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("model_angle_offset_z")){
								vehicle.model_angle_offset_z = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("model_angle_x")){
								vehicle.model_angle_x = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("model_angle_y")){
								vehicle.model_angle_y = Float.parseFloat(type[1]);
		            		}
							if(type[0].equals("model_angle_z")){
								vehicle.model_angle_z = Float.parseFloat(type[1]);
		            		}
							
							
							if(type[0].equals("mob_min_range")){
								vehicle.mob_min_range = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("mob_max_range")){
								vehicle.mob_max_range = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("mob_min_height")){
								vehicle.mob_min_height = Integer.parseInt(type[1]);
		            		}
							
							if(type[0].equals("turret")){
								vehicle.turret = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("turretrote")){
								for(int w1 = 0; w1 < vehicle.turret; ++w1) {
									vehicle.turretrote[w1] = Boolean.parseBoolean(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("arm_x")){
								for(int w1 = 0; w1 < vehicle.turret; ++w1) {
									vehicle.arm_x[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("arm_y")){
								for(int w1 = 0; w1 < vehicle.turret; ++w1) {
									vehicle.arm_y[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("arm_z")){
								for(int w1 = 0; w1 < vehicle.turret; ++w1) {
									vehicle.arm_z[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("hand_x")){
								for(int w1 = 0; w1 < vehicle.turret; ++w1) {
									vehicle.hand_x[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("hand_y")){
								for(int w1 = 0; w1 < vehicle.turret; ++w1) {
									vehicle.hand_y[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("hand_z")){
								for(int w1 = 0; w1 < vehicle.turret; ++w1) {
									vehicle.hand_z[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							
							if(type[0].equals("finger_type")){
								for(int w1 = 0; w1 < vehicle.turret; ++w1) {
									vehicle.finger_type[w1] = Integer.parseInt(type[w1 + 1]);
								}
		            		}
							
							if(type[0].equals("pera")){
								vehicle.pera = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("pera_x")){
								for(int w1 = 0; w1 < vehicle.pera; ++w1) {
									vehicle.pera_x[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("pera_y")){
								for(int w1 = 0; w1 < vehicle.pera; ++w1) {
									vehicle.pera_y[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("pera_z")){
								for(int w1 = 0; w1 < vehicle.pera; ++w1) {
									vehicle.pera_z[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("perarote_x")){
								for(int w1 = 0; w1 < vehicle.pera; ++w1) {
									vehicle.perarote_x[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("perarote_y")){
								for(int w1 = 0; w1 < vehicle.pera; ++w1) {
									vehicle.perarote_y[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("perarote_z")){
								for(int w1 = 0; w1 < vehicle.pera; ++w1) {
									vehicle.perarote_z[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							
							if(type[0].equals("rader")){
								vehicle.rader = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("raderturret")){
								for(int w1 = 0; w1 < vehicle.rader; ++w1) {
									vehicle.raderturret[w1] = Integer.parseInt(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("rader_x")){
								for(int w1 = 0; w1 < vehicle.rader; ++w1) {
									vehicle.rader_x[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("rader_y")){
								for(int w1 = 0; w1 < vehicle.rader; ++w1) {
									vehicle.rader_y[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("rader_z")){
								for(int w1 = 0; w1 < vehicle.rader; ++w1) {
									vehicle.rader_z[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("raderrote_x")){
								for(int w1 = 0; w1 < vehicle.rader; ++w1) {
									vehicle.raderrote_x[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("raderrote_y")){
								for(int w1 = 0; w1 < vehicle.rader; ++w1) {
									vehicle.raderrote_y[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("raderrote_z")){
								for(int w1 = 0; w1 < vehicle.rader; ++w1) {
									vehicle.raderrote_z[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							
							
							
							if(type[0].equals("cloud")){
								vehicle.cloud = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("cloud_x")){
								for(int w1 = 0; w1 < vehicle.cloud; ++w1) {
									vehicle.cloud_x[w1] = Double.parseDouble(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("cloud_y")){
								for(int w1 = 0; w1 < vehicle.cloud; ++w1) {
									vehicle.cloud_y[w1] = Double.parseDouble(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("cloud_z")){
								for(int w1 = 0; w1 < vehicle.cloud; ++w1) {
									vehicle.cloud_z[w1] = Double.parseDouble(type[w1 + 1]);
								}
		            		}
							
							
							
							if(type[0].equals("exhaust")){
								vehicle.exhaust = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("exhaust_ab")){
								vehicle.exhaust_ab = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("exhaust_x")){
								for(int w1 = 0; w1 < vehicle.exhaust; ++w1) {
									vehicle.exhaust_x[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("exhaust_y")){
								for(int w1 = 0; w1 < vehicle.exhaust; ++w1) {
									vehicle.exhaust_y[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("exhaust_z")){
								for(int w1 = 0; w1 < vehicle.exhaust; ++w1) {
									vehicle.exhaust_z[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							
							if(type[0].equals("laser_sight")){
								vehicle.laser_sight = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("rote_laser_sight")){
								for(int w1 = 0; w1 < vehicle.laser_sight; ++w1) {
									vehicle.rote_laser_sight[w1] = Boolean.parseBoolean(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("laser_sight_x")){
								for(int w1 = 0; w1 < vehicle.laser_sight; ++w1) {
									vehicle.laser_sight_x[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("laser_sight_y")){
								for(int w1 = 0; w1 < vehicle.laser_sight; ++w1) {
									vehicle.laser_sight_y[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("laser_sight_z")){
								for(int w1 = 0; w1 < vehicle.laser_sight; ++w1) {
									vehicle.laser_sight_z[w1] = Float.parseFloat(type[w1 + 1]);
								}
		            		}
							if(type[0].equals("laser_sight_weapon")){
								for(int w1 = 0; w1 < vehicle.laser_sight; ++w1) {
									vehicle.laser_sight_weapon[w1] = Integer.parseInt(type[w1 + 1]);
								}
		            		}
							
							
							
							
							
							
							
							//weapon1
							if(type[0].equals("weapon1true")){
								vehicle.weapon1true = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("weapon1key")){
								vehicle.weapon1key = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("w1name")){
								vehicle.w1name = type[1];
		            		}
							if(type[0].equals("w1missile_aam")){
								vehicle.w1missile_aam = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("ammo1")){
								vehicle.ammo1 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("magazine1")){
								vehicle.magazine = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("reload_time1")){
								vehicle.reload_time1 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("reloadsoundset1")){
								vehicle.reloadsoundset1 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("reloadsound1")){
								vehicle.reloadsound1 = type[1];
		            		}
							if(type[0].equals("w1cycle")){
								vehicle.w1cycle = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("w1barst")){
								vehicle.w1barst = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("w1crossfire")){
								vehicle.w1crossfire = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("w1can_cooldown")){
								vehicle.w1can_cooldown = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("weapon1")){
								vehicle.weapon1 = Integer.parseInt(type[1]);
		            		}
							for(int w1 = 0; w1 < vehicle.weapon1; ++w1) {
								if(type[0].equals("bullet_type1")){
									vehicle.bullet_type1[w1] = Integer.parseInt(type[w1 + 1]);
			            		}
								if(type[0].equals("bullet_model1")){
									 {
										 vehicle.bullet_model1[w1] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w1 + 1];
									}
			            		}
								if(type[0].equals("bullet_tex1")){
									 {
										 vehicle.bullet_tex1[w1] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w1 + 1];
									}
			            		}
								if(type[0].equals("fire_model1")){
									 {
										 vehicle.fire_model1[w1] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w1 + 1];
									}
			            		}
								if(type[0].equals("fire_tex1")){
									 {
										 vehicle.fire_tex1[w1] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w1 + 1];
									}
			            		}
								if(type[0].equals("fire_time1")){
									 {
										 vehicle.fire_time1[w1] = Integer.parseInt(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("sound_fire1")){
									 {
										 vehicle.sound_fire1[w1] = type[w1 + 1];
									}
			            		}
								if(type[0].equals("fire_pointx1")){
									 {
										 vehicle.fire_pointx1[w1] = Float.parseFloat(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("fire_pointy1")){
									 {
										 vehicle.fire_pointy1[w1] = Float.parseFloat(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("fire_pointz1")){
									 {
										 vehicle.fire_pointz1[w1] = Float.parseFloat(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("basis_pointx1")){
									 {
										 vehicle.basis_pointx1[w1] = Float.parseFloat(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("basis_pointy1")){
									 {
										 vehicle.basis_pointy1[w1] = Float.parseFloat(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("basis_pointz1")){
									 {
										 vehicle.basis_pointz1[w1] = Float.parseFloat(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("fire_yoffset1")){
									 {
										 vehicle.fire_yoffset1[w1] = Double.parseDouble(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("rotationfollowing1")){
									 {
										 vehicle.rotationfollowing1[w1] = Boolean.parseBoolean(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("rotationfirepoint1")){
									 {
										 vehicle.rotationfirepoint1[w1] = Boolean.parseBoolean(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("rotation_player1")){
									 {
										 vehicle.rotation_player1[w1] = Boolean.parseBoolean(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("rotation_firepointbxbz1")){
									 {
										 vehicle.rotation_firepointbxbz1[w1] = Boolean.parseBoolean(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("rotation_lock_pitch_vehicle1")){
									 {
										 vehicle.rotation_lock_pitch_vehicle1[w1] = Boolean.parseBoolean(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("bullet_damage1")){
									 {
										 vehicle.bullet_damage1[w1] = Integer.parseInt(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("bullet_speed1")){
									 {
										 vehicle.bullet_speed1[w1] = Float.parseFloat(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("bullet_bure1")){
									 {
										 vehicle.bullet_bure1[w1] = Float.parseFloat(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("bullet_expower1")){
									 {
										 vehicle.bullet_expower1[w1] = Float.parseFloat(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("bullet_ex1")){
									 {
										 vehicle.bullet_ex1[w1] = Boolean.parseBoolean(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("bullet_kazu1")){
									 {
										 vehicle.bullet_kazu1[w1] = Integer.parseInt(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("bullet_gravity1")){
									 {
										 vehicle.bullet_gravity1[w1] = Double.parseDouble(type[w1 + 1]);
									}
			            		}
								if(type[0].equals("bullet_livingtime1")){
									 {
										 vehicle.bullet_livingtime1[w1] = Integer.parseInt(type[w1 + 1]);
									}
			            		}
							}
							
							if(type[0].equals("mob_w1range")){
								vehicle.mob_w1range = Integer.parseInt(type[1]);
		            		}
							
							
							
							
							
							
							
							
							//weapon2
							if(type[0].equals("weapon2true")){
								vehicle.weapon2true = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("weapon2key")){
								vehicle.weapon2key = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("w2name")){
								vehicle.w2name = type[1];
		            		}
							if(type[0].equals("w2missile_aam")){
								vehicle.w2missile_aam = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("ammo2")){
								vehicle.ammo2 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("magazine2")){
								vehicle.magazine2 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("reload_time2")){
								vehicle.reload_time2 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("reloadsoundset2")){
								vehicle.reloadsoundset2 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("reloadsound2")){
								vehicle.reloadsound2 = type[1];
		            		}
							if(type[0].equals("w2cycle")){
								vehicle.w2cycle = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("w2barst")){
								vehicle.w2barst = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("w2crossfire")){
								vehicle.w2crossfire = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("w2can_cooldown")){
								vehicle.w2can_cooldown = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("weapon2")){
								vehicle.weapon2 = Integer.parseInt(type[1]);
		            		}
							for(int w2 = 0; w2 < vehicle.weapon2; ++w2) {
								if(type[0].equals("bullet_type2")){
									vehicle.bullet_type2[w2] = Integer.parseInt(type[w2 + 1]);
			            		}
								if(type[0].equals("bullet_model2")){
									 {
										 vehicle.bullet_model2[w2] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w2 + 1];
									}
			            		}
								if(type[0].equals("bullet_tex2")){
									 {
										 vehicle.bullet_tex2[w2] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w2 + 1];
									}
			            		}
								if(type[0].equals("fire_model2")){
									 {
										 vehicle.fire_model2[w2] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w2 + 1];
									}
			            		}
								if(type[0].equals("fire_tex2")){
									 {
										 vehicle.fire_tex2[w2] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w2 + 1];
									}
			            		}
								if(type[0].equals("fire_time2")){
									 {
										 vehicle.fire_time2[w2] = Integer.parseInt(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("sound_fire2")){
									 {
										 vehicle.sound_fire2[w2] = type[w2 + 1];
									}
			            		}
								if(type[0].equals("fire_pointx2")){
									 {
										 vehicle.fire_pointx2[w2] = Float.parseFloat(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("fire_pointy2")){
									 {
										 vehicle.fire_pointy2[w2] = Float.parseFloat(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("fire_pointz2")){
									 {
										 vehicle.fire_pointz2[w2] = Float.parseFloat(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("basis_pointx2")){
									 {
										 vehicle.basis_pointx2[w2] = Float.parseFloat(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("basis_pointy2")){
									 {
										 vehicle.basis_pointy2[w2] = Float.parseFloat(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("basis_pointz2")){
									 {
										 vehicle.basis_pointz2[w2] = Float.parseFloat(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("fire_yoffset2")){
									 {
										 vehicle.fire_yoffset2[w2] = Double.parseDouble(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("rotationfollowing2")){
									 {
										 vehicle.rotationfollowing2[w2] = Boolean.parseBoolean(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("rotationfirepoint2")){
									 {
										 vehicle.rotationfirepoint2[w2] = Boolean.parseBoolean(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("rotation_player2")){
									 {
										 vehicle.rotation_player2[w2] = Boolean.parseBoolean(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("rotation_firepointbxbz2")){
									 {
										 vehicle.rotation_firepointbxbz1[w2] = Boolean.parseBoolean(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("rotation_lock_pitch_vehicle2")){
									 {
										 vehicle.rotation_lock_pitch_vehicle1[w2] = Boolean.parseBoolean(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("bullet_damage2")){
									 {
										 vehicle.bullet_damage2[w2] = Integer.parseInt(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("bullet_speed2")){
									 {
										 vehicle.bullet_speed2[w2] = Float.parseFloat(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("bullet_bure2")){
									 {
										 vehicle.bullet_bure2[w2] = Float.parseFloat(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("bullet_expower2")){
									 {
										 vehicle.bullet_expower2[w2] = Float.parseFloat(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("bullet_ex2")){
									 {
										 vehicle.bullet_ex2[w2] = Boolean.parseBoolean(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("bullet_kazu2")){
									 {
										 vehicle.bullet_kazu2[w2] = Integer.parseInt(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("bullet_gravity2")){
									 {
										 vehicle.bullet_gravity2[w2] = Double.parseDouble(type[w2 + 1]);
									}
			            		}
								if(type[0].equals("bullet_livingtime2")){
									 {
										 vehicle.bullet_livingtime2[w2] = Integer.parseInt(type[w2 + 1]);
									}
			            		}
							}
							
							if(type[0].equals("mob_w2range")){
								vehicle.mob_w2range = Integer.parseInt(type[1]);
		            		}
							
							//weapon1
							if(type[0].equals("weapon3true")){
								vehicle.weapon3true = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("weapon3key")){
								vehicle.weapon3key = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("w3name")){
								vehicle.w3name = type[1];
		            		}
							if(type[0].equals("w3missile_aam")){
								vehicle.w3missile_aam = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("ammo3")){
								vehicle.ammo3 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("magazine3")){
								vehicle.magazine3 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("reload_time3")){
								vehicle.reload_time3 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("reloadsoundset3")){
								vehicle.reloadsoundset3 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("reloadsound3")){
								vehicle.reloadsound3 = type[1];
		            		}
							if(type[0].equals("w3cycle")){
								vehicle.w3cycle = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("w3barst")){
								vehicle.w3barst = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("w3crossfire")){
								vehicle.w3crossfire = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("w3can_cooldown")){
								vehicle.w3can_cooldown = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("weapon3")){
								vehicle.weapon3 = Integer.parseInt(type[1]);
		            		}
							for(int w3 = 0; w3 < vehicle.weapon3; ++w3) {
								if(type[0].equals("bullet_type3")){
									vehicle.bullet_type3[w3] = Integer.parseInt(type[w3 + 1]);
			            		}
								if(type[0].equals("bullet_model3")){
									 {
										 vehicle.bullet_model3[w3] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w3 + 1];
									}
			            		}
								if(type[0].equals("bullet_tex3")){
									 {
										 vehicle.bullet_tex3[w3] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w3 + 1];
									}
			            		}
								if(type[0].equals("fire_model3")){
									 {
										 vehicle.fire_model3[w3] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w3 + 1];
									}
			            		}
								if(type[0].equals("fire_tex3")){
									 {
										 vehicle.fire_tex3[w3] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w3 + 1];
									}
			            		}
								if(type[0].equals("fire_time3")){
									 {
										 vehicle.fire_time3[w3] = Integer.parseInt(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("sound_fire3")){
									 {
										 vehicle.sound_fire3[w3] = type[w3 + 1];
									}
			            		}
								if(type[0].equals("fire_pointx3")){
									 {
										 vehicle.fire_pointx3[w3] = Float.parseFloat(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("fire_pointy3")){
									 {
										 vehicle.fire_pointy3[w3] = Float.parseFloat(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("fire_pointz3")){
									 {
										 vehicle.fire_pointz3[w3] = Float.parseFloat(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("basis_pointx3")){
									 {
										 vehicle.basis_pointx3[w3] = Float.parseFloat(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("basis_pointy3")){
									 {
										 vehicle.basis_pointy3[w3] = Float.parseFloat(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("basis_pointz3")){
									 {
										 vehicle.basis_pointz3[w3] = Float.parseFloat(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("fire_yoffset3")){
									 {
										 vehicle.fire_yoffset3[w3] = Double.parseDouble(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("rotationfollowing3")){
									 {
										 vehicle.rotationfollowing3[w3] = Boolean.parseBoolean(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("rotationfirepoint3")){
									 {
										 vehicle.rotationfirepoint3[w3] = Boolean.parseBoolean(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("rotation_player3")){
									 {
										 vehicle.rotation_player3[w3] = Boolean.parseBoolean(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("rotation_firepointbxbz3")){
									 {
										 vehicle.rotation_firepointbxbz1[w3] = Boolean.parseBoolean(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("rotation_lock_pitch_vehicle3")){
									 {
										 vehicle.rotation_lock_pitch_vehicle1[w3] = Boolean.parseBoolean(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("bullet_damage3")){
									 {
										 vehicle.bullet_damage3[w3] = Integer.parseInt(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("bullet_speed3")){
									 {
										 vehicle.bullet_speed3[w3] = Float.parseFloat(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("bullet_bure3")){
									 {
										 vehicle.bullet_bure3[w3] = Float.parseFloat(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("bullet_expower3")){
									 {
										 vehicle.bullet_expower3[w3] = Float.parseFloat(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("bullet_ex3")){
									 {
										 vehicle.bullet_ex3[w3] = Boolean.parseBoolean(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("bullet_kazu3")){
									 {
										 vehicle.bullet_kazu3[w3] = Integer.parseInt(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("bullet_gravity3")){
									 {
										 vehicle.bullet_gravity3[w3] = Double.parseDouble(type[w3 + 1]);
									}
			            		}
								if(type[0].equals("bullet_livingtime3")){
									 {
										 vehicle.bullet_livingtime3[w3] = Integer.parseInt(type[w3 + 1]);
									}
			            		}
							}
							
							if(type[0].equals("mob_w3range")){
								vehicle.mob_w3range = Integer.parseInt(type[1]);
		            		}
							
							
							//weapon1
							if(type[0].equals("weapon4true")){
								vehicle.weapon4true = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("weapon4key")){
								vehicle.weapon4key = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("w4name")){
								vehicle.w4name = type[1];
		            		}
							if(type[0].equals("w4missile_aam")){
								vehicle.w4missile_aam = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("ammo4")){
								vehicle.ammo4 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("magazine4")){
								vehicle.magazine4 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("reload_time4")){
								vehicle.reload_time4 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("reloadsoundset4")){
								vehicle.reloadsoundset4 = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("reloadsound4")){
								vehicle.reloadsound4 = type[1];
		            		}
							if(type[0].equals("w4cycle")){
								vehicle.w4cycle = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("w4barst")){
								vehicle.w4barst = Integer.parseInt(type[1]);
		            		}
							if(type[0].equals("w4crossfire")){
								vehicle.w4crossfire = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("w4can_cooldown")){
								vehicle.w4can_cooldown = Boolean.parseBoolean(type[1]);
		            		}
							if(type[0].equals("weapon4")){
								vehicle.weapon4 = Integer.parseInt(type[1]);
		            		}
							for(int w4 = 0; w4 < vehicle.weapon4; ++w4) {
								if(type[0].equals("bullet_type4")){
									vehicle.bullet_type4[w4] = Integer.parseInt(type[w4 + 1]);
			            		}
								if(type[0].equals("bullet_model4")){
									 {
										 vehicle.bullet_model4[w4] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w4 + 1];
									}
			            		}
								if(type[0].equals("bullet_tex4")){
									 {
										 vehicle.bullet_tex4[w4] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w4 + 1];
									}
			            		}
								if(type[0].equals("fire_model4")){
									 {
										 vehicle.fire_model4[w4] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w4 + 1];
									}
			            		}
								if(type[0].equals("fire_tex4")){
									 {
										 vehicle.fire_tex4[w4] = "handmadevehicle2:addvehicle/" +domain + "/addentity/" + type[w4 + 1];
									}
			            		}
								if(type[0].equals("fire_time4")){
									 {
										 vehicle.fire_time4[w4] = Integer.parseInt(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("sound_fire4")){
									 {
										 vehicle.sound_fire4[w4] = type[w4 + 1];
									}
			            		}
								if(type[0].equals("fire_pointx4")){
									 {
										 vehicle.fire_pointx4[w4] = Float.parseFloat(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("fire_pointy4")){
									 {
										 vehicle.fire_pointy4[w4] = Float.parseFloat(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("fire_pointz4")){
									 {
										 vehicle.fire_pointz4[w4] = Float.parseFloat(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("basis_pointx4")){
									 {
										 vehicle.basis_pointx4[w4] = Float.parseFloat(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("basis_pointy4")){
									 {
										 vehicle.basis_pointy4[w4] = Float.parseFloat(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("basis_pointz4")){
									 {
										 vehicle.basis_pointz4[w4] = Float.parseFloat(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("fire_yoffset4")){
									 {
										 vehicle.fire_yoffset4[w4] = Double.parseDouble(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("rotationfollowing4")){
									 {
										 vehicle.rotationfollowing4[w4] = Boolean.parseBoolean(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("rotationfirepoint4")){
									 {
										 vehicle.rotationfirepoint4[w4] = Boolean.parseBoolean(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("rotation_player4")){
									 {
										 vehicle.rotation_player4[w4] = Boolean.parseBoolean(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("rotation_firepointbxbz4")){
									 {
										 vehicle.rotation_firepointbxbz1[w4] = Boolean.parseBoolean(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("rotation_lock_pitch_vehicle4")){
									 {
										 vehicle.rotation_lock_pitch_vehicle1[w4] = Boolean.parseBoolean(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("bullet_damage4")){
									 {
										 vehicle.bullet_damage4[w4] = Integer.parseInt(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("bullet_speed4")){
									 {
										 vehicle.bullet_speed4[w4] = Float.parseFloat(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("bullet_bure4")){
									 {
										 vehicle.bullet_bure4[w4] = Float.parseFloat(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("bullet_expower4")){
									 {
										 vehicle.bullet_expower4[w4] = Float.parseFloat(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("bullet_ex4")){
									 {
										 vehicle.bullet_ex4[w4] = Boolean.parseBoolean(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("bullet_kazu4")){
									 {
										 vehicle.bullet_kazu4[w4] = Integer.parseInt(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("bullet_gravity4")){
									 {
										 vehicle.bullet_gravity4[w4] = Double.parseDouble(type[w4 + 1]);
									}
			            		}
								if(type[0].equals("bullet_livingtime4")){
									 {
										 vehicle.bullet_livingtime4[w4] = Integer.parseInt(type[w4 + 1]);
									}
			            		}
							}
							
							if(type[0].equals("mob_w4range")){
								vehicle.mob_w4range = Integer.parseInt(type[1]);
		            		}
							
							
							
							
							
							if(type[0].equals("Recipe1")){
		          				  re1 = type[1];
		              		    }
		                		if(type[0].equals("Recipe2")){
		            				  re2 = type[1];
		                		}
		                		if(type[0].equals("Recipe3")){
		            				  re3 = type[1];
		                		    }
		                		if(type[0].equals("ItemA")){
		                			if(!type[1].equals("null")) {
		                				itema = event.getRegistry().getValue(new ResourceLocation(type[1], type[2]));
		                			}else {
		                				itema = Items.field_190931_a;
		                			}
		                	    }
		                		if(type[0].equals("ItemB")){
		                			if(!type[1].equals("null")) {
		                				itemb = event.getRegistry().getValue(new ResourceLocation(type[1], type[2]));
		                			}else {
		                				itemb = Items.field_190931_a;
		                			}
		                	    }
		                		if(type[0].equals("ItemC")){
		                			if(!type[1].equals("null")) {
		                				itemc = event.getRegistry().getValue(new ResourceLocation(type[1], type[2]));
		                			}else {
		                				itemc = Items.field_190931_a;
		                			}
		                	    }
		                		if(type[0].equals("ItemD")){
		                			if(!type[1].equals("null")) {
		                				itemd = event.getRegistry().getValue(new ResourceLocation(type[1], type[2]));
		                			}else {
		                				itemd = Items.field_190931_a;
		                			}
		                	    }
		                		if(type[0].equals("ItemE")){
		                			if(!type[1].equals("null")) {
		                				iteme = event.getRegistry().getValue(new ResourceLocation(type[1], type[2]));
		                			}else {
		                				iteme = Items.field_190931_a;
		                			}
		                	    }
		                		if(type[0].equals("ItemF")){
		                			if(!type[1].equals("null")) {
		                				itemf = event.getRegistry().getValue(new ResourceLocation(type[1], type[2]));
		                			}else {
		                				itemf = Items.field_190931_a;
		                			}
		                	    }
		                		if(type[0].equals("ItemG")){
		                			if(!type[1].equals("null")) {
		                				itemg = event.getRegistry().getValue(new ResourceLocation(type[1], type[2]));
		                			}else {
		                				itemg = Items.field_190931_a;
		                			}
		                	    }
		                		if(type[0].equals("ItemH")){
		                			if(!type[1].equals("null")) {
		                				itemh = event.getRegistry().getValue(new ResourceLocation(type[1], type[2]));
		                			}else {
		                				itemh = Items.field_190931_a;
		                			}
		                	    }
		                		if(type[0].equals("ItemI")){
		                			if(!type[1].equals("null")) {
		                				itemi = event.getRegistry().getValue(new ResourceLocation(type[1], type[2]));
		                			}else {
		                				itemi = Items.field_190931_a;
		                			}
		                	    }
		                		if(type[0].equals("addNewRecipe")){
		                			Item additem = event.getRegistry().getValue(new ResourceLocation(type[1], type[2]));
		              			  int kazu1 = Integer.parseInt(type[3]);
		              			GameRegistry.addShapedRecipe(
		              					new ResourceLocation(type[2]),
		              	                new ResourceLocation("handmadeguns2"),
		              	                new ItemStack(additem, kazu1), new Object[]{
		              	                		"abc",
		    	                  				"def",
		    	                  				"ghi", 
		    	                  				'a',itema,
		    	                  				'b',itemb,
		    	                  				'c',itemc,
		    	                  				'd',itemd,
		    	                  				'e',iteme,
		    	                  				'f',itemf,
		    	                  				'g',itemg,
		    	                  				'h',itemh,
		    	                  				'i',itemi
		              				 });
		                		}
						}
					}
				}
				br.close(); // ファイルを閉じる
			}
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public static void createlang(String GunName) {
		try {
	    	{
	    		File newfile2 = new File(mod_HandmadeVehicle2.proxy.ProxyFile(),"mods" + File.separatorChar + "handmadevehicle2" 
		                + File.separatorChar +  "assets" + File.separatorChar + "handmadevehicle2" + 
	    				File.separatorChar + "lang"+ File.separatorChar +  "gunname" + File.separatorChar + GunName);
		    	  newfile2.createNewFile();
		    	  BufferedWriter bw = new BufferedWriter(new FileWriter(newfile2));
					if (USname != null) {
						String name = new String(USname.getBytes("UTF8"), "UTF8");
						bw.write("USname,");
						bw.write(USname);
						bw.newLine();
					}
					if (JPname != null) {
						String name = new String(JPname.getBytes("UTF8"), "UTF8");
						bw.write("JPname,");
						bw.write(JPname);
						bw.newLine();
					}
					bw.close();
	    	}
	  } catch (FileNotFoundException ex) {
	    ex.printStackTrace();
	  } catch (IOException ex) {
	    ex.printStackTrace();
	  }
	}
}

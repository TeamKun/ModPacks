package handmadevehicle2.add;

import gvclib.Createjson;
import handmadevehicle2.mod_HandmadeVehicle2;
import net.minecraftforge.client.event.ModelRegistryEvent;

public class HMV2ModelRegistry {
	public static void registry(mod_HandmadeVehicle2 mod, ModelRegistryEvent event){
		
		for(int id = 0; id < mod.gun_model_id; ++id) {
			Createjson.addjson(mod.gun_model_item[id], mod.MOD_ID, mod.gun_model_name[id], true);
		}
		
		Createjson.addjson(mod.hmv2_icon, mod.MOD_ID, "hmv2_icon", false);
		
		Createjson.addjson(mod.hmv2_wrench, mod.MOD_ID, "hmv2_wrench", false);
		Createjson.addjson(mod.hmv2_tank_s, mod.MOD_ID, "hmv2_tank_s", false);
		
		Createjson.addjsonblock(mod.hmv2_crafter, mod.MOD_ID, "hmv2_crafter", false);
		
	}
}

package handmadevehicle2;


import java.io.File;
import gvclib.render.Render_S_Biped;
import handmadevehicle2.entity.EntityHMV2_S;
import handmadevehicle2.entity.EntityHMV2_Vehicle;
import handmadevehicle2.render.RenderHMV2_Vehicle;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.client.registry.RenderingRegistry;


import gvclib.render.Render_S_Biped;
import handmadevehicle2.entity.EntityHMV2_S;
import handmadevehicle2.entity.EntityHMV2_Vehicle;
import handmadevehicle2.render.RenderHMV2_Vehicle;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
//import net.minecraftforge.fml.common.registry.GameRegistry;
//import net.minecraftforge.fml.common.registry.VillagerRegistry;
public class ClientProxyHMV2 extends CommonSideProxyHMV2 {
	@Override
	public File ProxyFile(){
		return Minecraft.func_71410_x().field_71412_D;
	}
	 @Override
	    public EntityPlayer getEntityPlayerInstance() {
	        return Minecraft.func_71410_x().field_71439_g;
	    }
	 
    @Override
	public World getCilentWorld(){
		return FMLClientHandler.instance().getClient().field_71441_e;
		}
    
    @Override
    public void registerClientInfo() {
        //ClientRegistry.registerKeyBinding(Speedreload);
    }
    
    @Override
    public boolean getClient() {
        return true;
    }
    
    @Override
	public void reisterRenderers(){
    	Minecraft mc = FMLClientHandler.instance().getClient();
    	RenderManager rendermanager = mc.func_175598_ae();
    	//RenderItem renderitem = mc.getRenderItem();
    	RenderingRegistry.registerEntityRenderingHandler(EntityHMV2_Vehicle.class, new RenderHMV2_Vehicle(rendermanager));
    	RenderingRegistry.registerEntityRenderingHandler(EntityHMV2_S.class, new Render_S_Biped(rendermanager, "handmadevehicle2:textures/mob/tank_s.png", 1));
    }
    
    @Override
    public void registerTileEntity() {
    	//GameRegistry.registerTileEntity(GVCTileEntityItemG36.class, "GVCTileEntitysample");
    }
    
    @Override
    public void InitRendering()
    {
    	//ClientRegistry.bindTileEntitySpecialRenderer(GVCTileEntityItemG36.class, new GVCRenderItemG36());
    }

    @Override
    public boolean jumped(){
		return Minecraft.func_71410_x().field_71474_y.field_74314_A.func_151470_d();
		//return false;
	}
    
    @Override
    public boolean leftclick(){
		return Minecraft.func_71410_x().field_71474_y.field_74312_F.func_151470_d();
		//return false;
	}
}

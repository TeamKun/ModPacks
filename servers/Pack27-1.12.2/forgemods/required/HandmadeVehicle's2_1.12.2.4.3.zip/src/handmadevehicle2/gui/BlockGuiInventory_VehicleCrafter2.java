package handmadevehicle2.gui;

import java.io.IOException;
import handmadevehicle2.block.TileEntity_VehicleCrafter2;
import handmadevehicle2.mod_HandmadeVehicle2;
import handmadevehicle2.network.HMVMessageKeyPressed2;
import handmadevehicle2.network.HMVPacketHandler2;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;


import org.lwjgl.opengl.GL11;

import handmadevehicle2.mod_HandmadeVehicle2;
import handmadevehicle2.block.TileEntity_VehicleCrafter2;
import handmadevehicle2.network.HMVMessageKeyPressed2;
import handmadevehicle2.network.HMVPacketHandler2;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class BlockGuiInventory_VehicleCrafter2 extends GuiContainer
{
    private static final ResourceLocation FURNACE_GUI_TEXTURES = new ResourceLocation("handmadevehicle2:textures/gui/crafter.png");
    /** The player inventory bound to this GUI. */
    private final InventoryPlayer playerInventory;
    private final IInventory tileFurnace;
    private final TileEntity_VehicleCrafter2 tile;
    
    private GuiButton next;
    private GuiButton back;

    public BlockGuiInventory_VehicleCrafter2(InventoryPlayer playerInv, IInventory furnaceInv, TileEntity_VehicleCrafter2 t)
    {
        super(new BlockContainerInventory_VehicleCrafter2(playerInv, furnaceInv));
        this.playerInventory = playerInv;
        this.tileFurnace = furnaceInv;
        this.tile = t;
    }
    public void func_73866_w_()
    {
    	super.func_73866_w_();
    	this.next = this.func_189646_b(new GuiButton(0, this.field_146294_l / 2 - 10, this.field_146295_m / 2 - 69, 20, 20, I18n.func_135052_a("next")));
    	this.back = this.func_189646_b(new GuiButton(1, this.field_146294_l / 2 - 60, this.field_146295_m / 2 - 69, 20, 20, I18n.func_135052_a("back")));
    }
    protected void func_146284_a(GuiButton button) throws IOException
    {
    	 if (button.field_146127_k == 0)
         {
    		 if(tile.sell_id < (mod_HandmadeVehicle2.gun_id - 1)) {
    			 ++tile.sell_id;
    		 }else {
    			 tile.sell_id = 0;
    		 }
    		 HMVPacketHandler2.INSTANCE.sendToServer(new HMVMessageKeyPressed2(1, tile.func_174877_v().func_177958_n(), tile.func_174877_v().func_177956_o(), tile.func_174877_v().func_177952_p()));
         }
    	 if (button.field_146127_k == 1)
         {
    		 if(tile.sell_id > 0) {
    			 --tile.sell_id;
    		 }else {
    			 tile.sell_id = (mod_HandmadeVehicle2.gun_id - 1);
    		 }
    		 HMVPacketHandler2.INSTANCE.sendToServer(new HMVMessageKeyPressed2(2, tile.func_174877_v().func_177958_n(), tile.func_174877_v().func_177956_o(), tile.func_174877_v().func_177952_p()));
         }
    }
    /**
     * Draws the screen and all the components in it.
     */
    public void func_73863_a(int mouseX, int mouseY, float partialTicks)
    {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);
        this.func_191948_b(mouseX, mouseY);
    }

    /**
     * Draw the foreground layer for the GuiContainer (everything in front of the items)
     */
    protected void func_146979_b(int mouseX, int mouseY)
    {
        String s = this.tileFurnace.func_145748_c_().func_150260_c();
        this.field_146289_q.func_78276_b(s, this.field_146999_f / 2 - this.field_146289_q.func_78256_a(s) / 2, 6, 4210752);
        this.field_146289_q.func_78276_b(this.playerInventory.func_145748_c_().func_150260_c(), 8, this.field_147000_g - 96 + 2, 4210752);
    }

    /**
     * Draws the background layer of this container (behind the items).
     */
    protected void func_146976_a(float partialTicks, int mouseX, int mouseY)
    {
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        this.field_146297_k.func_110434_K().func_110577_a(FURNACE_GUI_TEXTURES);
        int k = (this.field_146294_l - this.field_146999_f) / 2;
        int l = (this.field_146295_m - this.field_147000_g) / 2;
        this.func_73729_b(k, l, 0, 0, this.field_146999_f, this.field_147000_g);
        
        {
        	FontRenderer fontReader = field_146297_k.field_71466_p;
    		field_146297_k.field_71466_p.func_78264_a(field_146297_k.func_152349_b());
    		RenderItem renderitem = field_146297_k.func_175599_af();
        	GL11.glPushMatrix();
    		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    		GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
    				GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
    				GlStateManager.DestFactor.ZERO);
    		field_146297_k.field_71446_o.func_110577_a(TextureMap.field_110575_b);
        	{
				ItemStack item = new ItemStack(mod_HandmadeVehicle2.gun_item[tile.sell_id]);
				if (!item.func_190926_b()) {
					GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.4F);
					renderitem.func_175042_a(item, k + 56, l + 17);
					GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
					//String d2 = String.format("%1$3d", doll.getRemain_S());
					//fontReader.drawString(d2,  k + 115, l + 80, 0xFFFFFF);
				}
			}
        	{
				ItemStack item = new ItemStack(Items.field_151166_bC);
				if (!item.func_190926_b()) {
					GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.4F);
					renderitem.func_175042_a(item, k + 20, l + 35);
					GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
					String d2 = String.format("%1$3d", mod_HandmadeVehicle2.gun_eme[tile.sell_id]);
					fontReader.func_78276_b(d2,  k + 28, l + 45, 0xFFFFFF);
				}
			}
        	{
				ItemStack item = new ItemStack(Items.field_151042_j);
				if (!item.func_190926_b()) {
					GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.4F);
					renderitem.func_175042_a(item, k + 56, l + 35);
					GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
					String d2 = String.format("%1$3d", mod_HandmadeVehicle2.gun_iron[tile.sell_id]);
					fontReader.func_78276_b(d2,  k + 62, l + 45, 0xFFFFFF);
				}
			}
        	{
				ItemStack item = new ItemStack(Items.field_151137_ax);
				if (!item.func_190926_b()) {
					GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.4F);
					renderitem.func_175042_a(item, k + 92, l + 35);
					GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
					String d2 = String.format("%1$3d", mod_HandmadeVehicle2.gun_red[tile.sell_id]);
					fontReader.func_78276_b(d2,  k + 98, l + 45, 0xFFFFFF);
				}
			}
        	GL11.glPopMatrix();
        }
    }

    private int getCookProgressScaled(int pixels)
    {
        int i = this.tileFurnace.func_174887_a_(2);
        int j = this.tileFurnace.func_174887_a_(3);
        return j != 0 && i != 0 ? i * pixels / j : 0;
    }

    private int getBurnLeftScaled(int pixels)
    {
        int i = this.tileFurnace.func_174887_a_(1);

        if (i == 0)
        {
            i = 200;
        }

        return this.tileFurnace.func_174887_a_(0) * pixels / i;
    }
}

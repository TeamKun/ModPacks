package handmadevehicle2.gui;

import handmadevehicle2.block.TileEntity_VehicleCrafter2;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

public class GuiHandlerHMV2 implements IGuiHandler {
	/*
	 * ServerでGUIが開かれたときに呼ばれる 通常はContainerを生成する。
	 */
	@Override
	public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
		BlockPos pos = new BlockPos(x, y, z);
		if (ID == 0) {
			TileEntity tileentity = player.field_70170_p.func_175625_s(pos);
			if (!world.func_175667_e(pos)) {
				return null;
			}else
            if (tileentity instanceof TileEntity_VehicleCrafter2)
            {
            	return new BlockContainerInventory_VehicleCrafter2(player.field_71071_by, (TileEntity_VehicleCrafter2)tileentity);
            }
		}
		return null;
	}

	/*
	 * ClientでGUIが開かれたときに呼ばれる 通常はGUIを生成する
	 */
	@Override
	public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
		BlockPos pos = new BlockPos(x, y, z);
		if (ID == 0) {
			TileEntity tileentity = player.field_70170_p.func_175625_s(pos);
			if (!world.func_175667_e(pos)) {
				return null;
			}else
            if (tileentity instanceof TileEntity_VehicleCrafter2)
            {
            	return new BlockGuiInventory_VehicleCrafter2(player.field_71071_by, (TileEntity_VehicleCrafter2)tileentity, (TileEntity_VehicleCrafter2)tileentity);
            }
		}
		
		return null;
	}
}

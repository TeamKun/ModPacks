package handmadevehicle2.entity;

import java.util.List;
import java.util.Random;
import gvclib.entity.living.AI_AirCraftSet;
import gvclib.entity.living.AI_EntityMoveAirCraft;
import gvclib.entity.living.AI_EntityMoveTank;
import gvclib.entity.living.AI_EntityWeapon;
import gvclib.entity.living.AI_TankSet;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.PL_AirCraftMove;
import gvclib.entity.living.PL_TankMove;
import gvclib.entity.living.cnt.VehicleCNT_Tank_SPG;
import gvclib.event.GVCSoundEvent;
import gvclib.mod_GVCLib;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;


import gvclib.mod_GVCLib;
import gvclib.entity.living.AI_AirCraftSet;
import gvclib.entity.living.AI_EntityMoveAirCraft;
import gvclib.entity.living.AI_EntityMoveTank;
import gvclib.entity.living.AI_EntityWeapon;
import gvclib.entity.living.AI_TankSet;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.ISoldier;
import gvclib.entity.living.PL_AirCraftMove;
import gvclib.entity.living.PL_TankMove;
import gvclib.entity.living.cnt.VehicleCNT_Tank_SPG;
import gvclib.event.GVCSoundEvent;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AI_EntityVehicle {

	public static void load(EntityHMV2_Vehicle vehicle) {

		vehicle.readinformation();
		
		if(vehicle.riddng_maximum > 1){
			vehicle.render_hud_information_5 = "V-KEY:ALLY-Boarding";
			vehicle.render_hud_information_6 = "B-KEY:ALLY-Get off";
		}
		
		
		 if(vehicle.vehicletype == 2) {
			    vehicle.render_hud_information_1 = "Z-KEY:Get off";
	        	vehicle.render_hud_information_2 = "W/S-KEY:Throttle-UP/DWON";
	            vehicle.render_hud_information_3 = "SPEAC/SHIFT-KEY:UP/DWON";
	            vehicle.render_hud_information_4 = "Mouse-UP/DOWN:PICTH-UP/DOWN";
	            
	        }
		 if(vehicle.vehicletype == 3 || vehicle.spg_sighting) {
			    vehicle.render_hud_information_1 = "G-KEY:SPG_MODE";
	            
	        }
		
		if(vehicle.vehicletype == 2) {
			vehicle.ridding_sneakdismount = false;
			/*if(vehicle.getArmID_S() == 1) {
				vehicle.render_hud_scaleup_text1 = false;
				vehicle.render_hud_scaleup_text2 = true;
			}else {
				vehicle.render_hud_scaleup_text1 = true;
				vehicle.render_hud_scaleup_text2 = false;
			}*/
		}
		if(vehicle.vehicletype == 5) {
			if (vehicle.field_70170_p
					.func_180495_p(new BlockPos(vehicle.field_70165_t, vehicle.field_70163_u + 0.8, vehicle.field_70161_v))
					.func_185904_a() == Material.field_151586_h) {
				//entity.motionY = 0.05F;
				vehicle.field_70181_x = -vehicle.field_70181_x;
				vehicle.field_70181_x = vehicle.field_70181_x * 0.5F;
			}
		}
		if(vehicle.amphibious){
			if (vehicle.field_70170_p
					.func_180495_p(new BlockPos(vehicle.field_70165_t, vehicle.field_70163_u + 0.8, vehicle.field_70161_v))
					.func_185904_a() == Material.field_151586_h) {
				vehicle.field_70181_x = 0.05F;
			}
			/*if(vehicle.collidedHorizontally && vehicle.isWet()){
				//this.stepHeight = 2F;
				vehicle.motionY = 0.2F;
			}*/
			if(vehicle.field_70123_F){
				//this.stepHeight = 2F;
				vehicle.field_70181_x = 0.2F;
			}
		}
		
		{
			if(vehicle.weapon1key == 0 && vehicle.weapon2key == 0 && vehicle.weapon3key == 0){
				vehicle.weapon_mode = 4;
				if(vehicle.getArmID_S() == 1) {
					vehicle.render_hud_scaleup_text1 = false;
					vehicle.render_hud_scaleup_text2 = true;
					vehicle.render_hud_scaleup_text3 = false;
				}else if(vehicle.getArmID_S() == 2) {
					vehicle.render_hud_scaleup_text1 = false;
					vehicle.render_hud_scaleup_text2 = false;
					vehicle.render_hud_scaleup_text3 = true;
				}else {
					vehicle.render_hud_scaleup_text1 = true;
					vehicle.render_hud_scaleup_text2 = false;
					vehicle.render_hud_scaleup_text3 = false;
				}
			}
			
			else if(vehicle.weapon1key == 0 && vehicle.weapon2key == 0){
				vehicle.weapon_mode = 1;
				if(vehicle.getArmID_S() == 1) {
					vehicle.render_hud_scaleup_text1 = false;
					vehicle.render_hud_scaleup_text2 = true;
				}else {
					vehicle.render_hud_scaleup_text1 = true;
					vehicle.render_hud_scaleup_text2 = false;
				}
			}
			else if(vehicle.weapon1key == 0 && vehicle.weapon3key == 0){
				vehicle.weapon_mode = 2;
				if(vehicle.getArmID_S() == 1) {
					vehicle.render_hud_scaleup_text1 = false;
					vehicle.render_hud_scaleup_text3 = true;
				}else {
					vehicle.render_hud_scaleup_text1 = true;
					vehicle.render_hud_scaleup_text3 = false;
				}
			}
			else if(vehicle.weapon2key == 0 && vehicle.weapon3key == 0){
				vehicle.weapon_mode = 3;
				if(vehicle.getArmID_S() == 1) {
					vehicle.render_hud_scaleup_text2 = false;
					vehicle.render_hud_scaleup_text3 = true;
				}else {
					vehicle.render_hud_scaleup_text2 = true;
					vehicle.render_hud_scaleup_text3 = false;
				}
			}
			
			else if(vehicle.weapon1key == 2 && vehicle.weapon2key == 2 && vehicle.weapon3key == 2){
				vehicle.weapon_mode = 14;
				if(vehicle.getArmID_S() == 1) {
					vehicle.render_hud_scaleup_text1 = false;
					vehicle.render_hud_scaleup_text2 = true;
					vehicle.render_hud_scaleup_text3 = false;
				}else if(vehicle.getArmID_S() == 2) {
					vehicle.render_hud_scaleup_text1 = false;
					vehicle.render_hud_scaleup_text2 = false;
					vehicle.render_hud_scaleup_text3 = true;
				}else {
					vehicle.render_hud_scaleup_text1 = true;
					vehicle.render_hud_scaleup_text2 = false;
					vehicle.render_hud_scaleup_text3 = false;
				}
			}
			
			else if(vehicle.weapon1key == 2 && vehicle.weapon2key == 2){
				vehicle.weapon_mode = 11;
				if(vehicle.getArmID_S() == 1) {
					vehicle.render_hud_scaleup_text1 = false;
					vehicle.render_hud_scaleup_text2 = true;
				}else {
					vehicle.render_hud_scaleup_text1 = true;
					vehicle.render_hud_scaleup_text2 = false;
				}
			}
			else if(vehicle.weapon1key == 2 && vehicle.weapon3key == 2){
				vehicle.weapon_mode = 12;
				if(vehicle.getArmID_S() == 1) {
					vehicle.render_hud_scaleup_text1 = false;
					vehicle.render_hud_scaleup_text3 = true;
				}else {
					vehicle.render_hud_scaleup_text1 = true;
					vehicle.render_hud_scaleup_text3 = false;
				}
			}
			else if(vehicle.weapon2key == 2 && vehicle.weapon3key == 2){
				vehicle.weapon_mode = 13;
				if(vehicle.getArmID_S() == 1) {
					vehicle.render_hud_scaleup_text2 = false;
					vehicle.render_hud_scaleup_text3 = true;
				}else {
					vehicle.render_hud_scaleup_text2 = true;
					vehicle.render_hud_scaleup_text3 = false;
				}
			}
			
			else {
				vehicle.weapon_mode = 0;
			}
		}
		
		
		if(vehicle.bomber_sighting){
			float bsp = (float)Math.tan((vehicle.field_70159_w * vehicle.field_70159_w) + (vehicle.field_70179_y * vehicle.field_70179_y)) * 10;
			for(int ii = 0; ii < 10 ; ++ii) {
				if(vehicle.bullet_type1[ii] == 3 || vehicle.bullet_type1[ii] == 2)vehicle.bullet_speed1[ii] = bsp;
				if(vehicle.bullet_type2[ii] == 3 || vehicle.bullet_type2[ii] == 2)vehicle.bullet_speed2[ii] = bsp;
				if(vehicle.bullet_type3[ii] == 3 || vehicle.bullet_type3[ii] == 2)vehicle.bullet_speed3[ii] = bsp;
			}
			
		}
		
		
		
		/*
		if(!vehicle.vacanspawn && vehicle.getcanDespawn() == 0 && !vehicle.world.isRemote) {
			System.out.println(String.format("desspawn"));
			vehicle.setDead();
			if(vehicle.getControllingPassenger() != null)
			{
				vehicle.getControllingPassenger().setDead();
			}
		}
		*/
		if(vehicle.vacanspawn && vehicle.getcanDespawn() == 0 && !vehicle.field_70170_p.field_72995_K && vehicle.spawn) {
			Random ra = new Random();
			int i = ra.nextInt(100 - vehicle.spawn_rare);
			if (i == 0) {
				System.out.println(String.format("desspawn2"));
				vehicle.func_70106_y();
				if (vehicle.func_184179_bs() != null) {
					vehicle.func_184179_bs().func_70106_y();
				}
			}
		}
		vehicle.spawn = false;
		
		float f1 = vehicle.field_70759_as * (2 * (float) Math.PI / 360);
		
		vehicle.roadattack();
		
		if(vehicle.vehicletype == 3) {
			VehicleCNT_Tank_SPG.load(vehicle, vehicle.movesound);
		}else {
			if (vehicle.func_82171_bF() && vehicle.func_184179_bs() != null  && vehicle.func_110143_aJ() > 0.0F)
			{
				if(vehicle.func_184179_bs() instanceof EntityPlayer)
				{
				EntityPlayer entitylivingbase = (EntityPlayer) vehicle.func_184179_bs();
				Vec3d looked = entitylivingbase.func_70040_Z();
				
				if(vehicle.vehicletype == 3 || vehicle.spg_sighting) {
					spg_mode(vehicle, entitylivingbase);
				}else {
					if(vehicle.vehicletype == 0) {
						vehicle.rotation = entitylivingbase.field_70759_as;
						vehicle.rotationp = entitylivingbase.field_70125_A;
						PL_TankMove.move2(entitylivingbase, vehicle, vehicle.sp, vehicle.turnspeed);
					}else if(vehicle.vehicletype == 1 || vehicle.vehicletype == 4) {
						vehicle.rotation  = entitylivingbase.field_70759_as;
						if(vehicle.getFTMode() != 1){
							PL_AirCraftMove.movefighter(entitylivingbase, vehicle, vehicle.sp, vehicle.turnspeed);
						}else if(vehicle.getFTMode() == 1){
							vehicle.rotep = 0;
						if ((vehicle.field_70125_A > (vehicle.rotep + vehicle.turnspeed)) || (vehicle.field_70125_A < vehicle.rotep - vehicle.turnspeed)) {
							if (vehicle.field_70125_A < vehicle.rotep) {
								vehicle.rotationp = vehicle.rotationp + vehicle.turnspeed*1;
								vehicle.field_70125_A = vehicle.field_70125_A + vehicle.turnspeed*1;
								vehicle.field_70127_C = vehicle.field_70127_C + vehicle.turnspeed*1;
							} else if (vehicle.field_70125_A > vehicle.rotep) {
								vehicle.rotationp = vehicle.rotationp - vehicle.turnspeed*1;
								vehicle.field_70125_A = vehicle.field_70125_A - vehicle.turnspeed*1;
								vehicle.field_70127_C = vehicle.field_70127_C - vehicle.turnspeed*1;
							}
						}
					}
					else if(vehicle.getFTMode() == 2){
						if (entitylivingbase.field_191988_bg > 0.0F) {
							vehicle.field_70125_A = vehicle.field_70125_A + 0.2F;
						}
						if (entitylivingbase.field_191988_bg < 0.0F) {
							vehicle.field_70125_A = vehicle.field_70125_A - 0.2F;
						}
						if (entitylivingbase.field_70702_br < 0.0F) {
							vehicle.field_70759_as = vehicle.field_70759_as + vehicle.turnspeed* 1F;
							vehicle.field_70177_z = vehicle.field_70177_z + vehicle.turnspeed* 1F;
						}
						if (entitylivingbase.field_70702_br > 0.0F) {
							vehicle.field_70759_as = vehicle.field_70759_as - vehicle.turnspeed* 1F;
							vehicle.field_70177_z = vehicle.field_70177_z - vehicle.turnspeed* 1F;
						}
					}
					}else if(vehicle.vehicletype == 2) {
						if(vehicle.getFTMode() != 1){
							PL_AirCraftMove.moveheli_NEW(entitylivingbase, vehicle, vehicle.sp, vehicle.turnspeed);
						}else {
							PL_AirCraftMove.moveheligunner(entitylivingbase, vehicle, vehicle.sp, vehicle.turnspeed);
							vehicle.rotep = 0;
							if ((vehicle.field_70125_A > (vehicle.rotep + vehicle.turnspeed)) || (vehicle.field_70125_A < vehicle.rotep - vehicle.turnspeed)) {
								if (vehicle.field_70125_A < vehicle.rotep) {
									vehicle.rotationp = vehicle.rotationp + vehicle.turnspeed*1;
									vehicle.field_70125_A = vehicle.field_70125_A + vehicle.turnspeed*1;
									vehicle.field_70127_C = vehicle.field_70127_C + vehicle.turnspeed*1;
								} else if (vehicle.field_70125_A > vehicle.rotep) {
									vehicle.rotationp = vehicle.rotationp - vehicle.turnspeed*1;
									vehicle.field_70125_A = vehicle.field_70125_A - vehicle.turnspeed*1;
									vehicle.field_70127_C = vehicle.field_70127_C - vehicle.turnspeed*1;
								}
							}
						}
					}else if(vehicle.vehicletype == 5) {
						PL_TankMove.movecar(entitylivingbase, vehicle, vehicle.sp, vehicle.turnspeed);
					}
				}
				
				
				
				
				
				vehicle.roadattack();
				
				boolean left = mod_GVCLib.proxy.leftclick();
				boolean right = mod_GVCLib.proxy.rightclick();
				boolean jump = mod_GVCLib.proxy.jumped();
				boolean kx = mod_GVCLib.proxy.keyx();
				boolean kg = mod_GVCLib.proxy.keyg();
				boolean kc = mod_GVCLib.proxy.keyc();
				boolean kh = mod_GVCLib.proxy.keyh();
				boolean kf = mod_GVCLib.proxy.keyf();
				if (left) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(11, vehicle.func_145782_y()));
					vehicle.server1 = true;
				}
				if (right) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(12, vehicle.func_145782_y()));
				}
				if (jump) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(13, vehicle.func_145782_y()));
				}
				if (kx) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(14, vehicle.func_145782_y()));
				}
				if (kg) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(15, vehicle.func_145782_y()));
					if(vehicle.vehicletype == 3 || vehicle.spg_sighting) {
						if(vehicle.getFTMode() >= 1){
						}else if(vehicle.field_70170_p.field_72995_K)
						{
							float yaw;
							if(vehicle.rotationfollowing1[0]) {
								yaw = entitylivingbase.field_70759_as * (2 * (float) Math.PI / 360);
							}else {
								yaw = vehicle.field_70177_z * (2 * (float) Math.PI / 360);
							}
							vehicle.spg_yaw -= MathHelper.func_76126_a(yaw) * (vehicle.spg_min_range);
							vehicle.spg_picth += MathHelper.func_76134_b(yaw) * (vehicle.spg_min_range);
						}
					}
				}
				if (kc) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(16, vehicle.func_145782_y()));
				}
				if (kh) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(18, vehicle.func_145782_y()));
				}
				if (kf) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(19, vehicle.func_145782_y()));
				}
				
				/*if(vehicle.vehicletype == 2) {
					if (vehicle.serverx) {
						if(vehicle.cooltime3 >= 5){
							if(vehicle.getArmID_S() == 1) {
								vehicle.setArmID_S(0);
							}else {
								vehicle.setArmID_S(1);
							}
							vehicle.playSound(GVCSoundEvent.reload_shell, 1.0F, 1.0F);
							vehicle.cooltime3 = 0;
						}
						vehicle.serverx = false;
					}
				
				 if (vehicle.server1) {
						if(vehicle.getArmID_S() == 1){
		    				if(vehicle.cooltime2 >= vehicle.ammo2){
		    					vehicle.counter2 = true;
		    					vehicle.cooltime2 = 0;
		    				}
		    				if(vehicle.weapon2true) {
		    					vehicle.weapon2active(looked, entitylivingbase);
		        		    }
		    			}else {
		    				if(vehicle.cooltime >= vehicle.ammo1){
		    					vehicle.counter1 = true;
		    					vehicle.cooltime = 0;
		    				}
		    				if(vehicle.weapon1true) {
		    					vehicle.weapon1active(looked, entitylivingbase);
		        		    }
		    			}
						vehicle.server1 = false;
					}
				}else */
				{
					
					
		    		    if(vehicle.server1)
		    		    {
		    		        if(vehicle.weapon_mode == 1) {
		    		        	if(vehicle.getArmID_S() == 1) {
		    		        		weapon2(vehicle, entitylivingbase, looked);
			    		    	}else {
			    		        	weapon1(vehicle, entitylivingbase, looked);
		    		        	}
		    		    	}else if(vehicle.weapon_mode == 2) {
		    		        	if(vehicle.getArmID_S() == 1) {
		    		        		weapon3(vehicle, entitylivingbase, looked);
			    		    	}else {
			    		        	weapon1(vehicle, entitylivingbase, looked);
		    		        	}
		    		    	}else if(vehicle.weapon_mode == 3) {
		    		        	if(vehicle.getArmID_S() == 1) {
		    		        		weapon3(vehicle, entitylivingbase, looked);
			    		    	}else {
			    		        	weapon2(vehicle, entitylivingbase, looked);
		    		        	}
		    		    	}else if(vehicle.weapon_mode == 4) {
		    		        	if(vehicle.getArmID_S() == 1) {
		    		        		weapon2(vehicle, entitylivingbase, looked);
			    		    	}else if(vehicle.getArmID_S() == 2){
			    		        	weapon3(vehicle, entitylivingbase, looked);
		    		        	}else {
			    		        	weapon1(vehicle, entitylivingbase, looked);
		    		        	}
		    		    	}else {
		    		    		if(vehicle.weapon1key == 0){
				    				weapon1(vehicle, entitylivingbase, looked);
				    			}
			    		    	if(vehicle.weapon2key == 0){
			    		    		weapon2(vehicle, entitylivingbase, looked);
				    			}
		    		    	}
		    		    	vehicle.server1 = false;
						}
		    		    
		    		    if(vehicle.server2)
		    		    {
		    		    	/*if(vehicle.weapon1key == 1){
			    				if(vehicle.cooltime >= vehicle.ammo1){
			    					vehicle.counter1 = true;
			    					vehicle.cooltime = 0;
			    				}
			    				if(vehicle.weapon1true) {
			    					if(vehicle.getArmID_R() == 1 && vehicle.weapon11true){
			    						vehicle.weapon11active(looked, entitylivingbase);
			    					}else if(vehicle.getArmID_R() == 2 && vehicle.weapon12true){
			    						vehicle.weapon12active(looked, entitylivingbase);
			    					}else {
			    						vehicle.weapon1active(looked, entitylivingbase);
			    					}
			        		    }
			    			}
		    		    	
		    		    	if(vehicle.weapon2key == 1){
			    				if(vehicle.cooltime2 >= vehicle.ammo2){
			    					vehicle.counter2 = true;
			    					vehicle. cooltime2 = 0;
			    				}
			    				if(vehicle.weapon2true) {
			        		    	vehicle.weapon2active(looked, entitylivingbase);
			        		    }
			    			}*/
		    		    	vehicle.server2 = false;
						}
		    		    
		    		    if(vehicle.serverspace)
		    		    {
		    		    	/*if(vehicle.weapon1key == 2){
			    				if(vehicle.cooltime >= vehicle.ammo1){
			    					vehicle.counter1 = true;
			    					vehicle.cooltime = 0;
			    				}
			    				if(vehicle.weapon1true) {
			    					if(vehicle.getArmID_R() == 1 && vehicle.weapon11true){
			    						vehicle.weapon11active(looked, entitylivingbase);
			    					}else if(vehicle.getArmID_R() == 2 && vehicle.weapon12true){
			    						vehicle.weapon12active(looked, entitylivingbase);
			    					}else {
			    						vehicle.weapon1active(looked, entitylivingbase);
			    					}
			        		    }
			    			}
		    		    	
		    		    	if(vehicle.weapon2key == 2){
			    				if(vehicle.cooltime2 >= vehicle.ammo2){
			    					vehicle.counter2 = true;
			    					vehicle.cooltime2 = 0;
			    				}
			    				if(vehicle.weapon2true) {
			        		    	vehicle.weapon2active(looked, entitylivingbase);
			        		    }
			    			}*/
		    		    	if(vehicle.weapon_mode == 11) {
		    		        	if(vehicle.getArmID_S() == 1) {
		    		        		weapon2(vehicle, entitylivingbase, looked);
			    		    	}else {
			    		        	weapon1(vehicle, entitylivingbase, looked);
		    		        	}
		    		    	}else if(vehicle.weapon_mode == 12) {
		    		        	if(vehicle.getArmID_S() == 1) {
		    		        		weapon3(vehicle, entitylivingbase, looked);
			    		    	}else {
			    		        	weapon1(vehicle, entitylivingbase, looked);
		    		        	}
		    		    	}else if(vehicle.weapon_mode == 13) {
		    		        	if(vehicle.getArmID_S() == 1) {
		    		        		weapon3(vehicle, entitylivingbase, looked);
			    		    	}else {
			    		        	weapon2(vehicle, entitylivingbase, looked);
		    		        	}
		    		    	}else if(vehicle.weapon_mode == 14) {
		    		        	if(vehicle.getArmID_S() == 1) {
		    		        		weapon2(vehicle, entitylivingbase, looked);
			    		    	}else if(vehicle.getArmID_S() == 2){
			    		        	weapon3(vehicle, entitylivingbase, looked);
		    		        	}else {
			    		        	weapon1(vehicle, entitylivingbase, looked);
		    		        	}
		    		    	}else {
		    		    		if(vehicle.weapon1key == 2){
				    				weapon1(vehicle, entitylivingbase, looked);
				    			}
			    		    	if(vehicle.weapon2key == 2){
			    		    		weapon2(vehicle, entitylivingbase, looked);
				    			}
		    		    	}
		    		    	vehicle.serverspace = false;
						}
		    		    
		    		    if(vehicle.weapon_mode != 0) {
		    		    	if (vehicle.serverx) {
								if(vehicle.cooltime5 >= 5){
									if(vehicle.weapon_mode == 4 || vehicle.weapon_mode == 14) {
										if(vehicle.getArmID_S() == 1) {
											vehicle.setArmID_S(2);
										}else if(vehicle.getArmID_S() == 2) {
											vehicle.setArmID_S(0);
										}else {
											vehicle.setArmID_S(1);
										}
									}else {
										if(vehicle.getArmID_S() == 1) {
											vehicle.setArmID_S(0);
										}else {
											vehicle.setArmID_S(1);
										}
									}
									vehicle.func_184185_a(GVCSoundEvent.reload_shell, 1.0F, 1.0F);
									vehicle.cooltime5 = 0;
								}
								vehicle.serverx = false;
							}
		    		    }
		    		    
		    		    if (vehicle.serverg) {
		    		    	if(vehicle.vehicletype == 3 || vehicle.spg_sighting) {
		    		    		if (vehicle.cooltime6 > 1 && vehicle.getWeaponChange() > 0) {
			    					if(vehicle.getFTMode() >= 1){
			    						vehicle.setFTMode(0);
			    					}else
			    					{
			    						vehicle.setFTMode(1);
			    						float yaw;
			    						if(vehicle.rotationfollowing1[0]) {
			    							yaw = entitylivingbase.field_70759_as * (2 * (float) Math.PI / 360);
			    						}else {
			    							yaw = vehicle.field_70177_z * (2 * (float) Math.PI / 360);
			    						}
			    						//spg_yaw = 0;
			    						//spg_picth = 0;
			    						vehicle.spg_yaw -= MathHelper.func_76126_a(yaw) * (vehicle.spg_min_range);
			    						vehicle.spg_picth += MathHelper.func_76134_b(yaw) * (vehicle.spg_min_range);
			    					}
			    					vehicle.cooltime6 = 0;
			    					vehicle.setWeaponChange(vehicle.getWeaponChange() - 1);
			    				}
			    				{
			    					vehicle.serverg = false;
			    				}
		    		    	}else if(vehicle.vehicletype == 1 || vehicle.vehicletype == 4) {
		    		    		{
		    						if(vehicle.cooltime6 >= 5){
		    							if(vehicle.getFTMode() == 1) {
		    								vehicle.setFTMode(2);
		    							}
		    							if(vehicle.getFTMode() == 2) {
		    								vehicle.setFTMode(0);
		    							}
		    							else {
		    								vehicle.setFTMode(1);
		    							}
		    							vehicle.func_184185_a(GVCSoundEvent.reload_shell, 1.0F, 1.0F);
		    							vehicle.cooltime6 = 0;
		    						}
		    						vehicle.serverg = false;
		    					}
		    		    	}else if(vehicle.vehicletype == 2) {
		    		    		{
		    						 if(vehicle.cooltime6 >= 5){
		    								if(vehicle.getFTMode() >= 1){
		    									vehicle.setFTMode(0);
		    								}else
		    								{
		    									vehicle.setFTMode(1);
		    								}
		    								vehicle.cooltime6 = 0;
		    								vehicle.func_184185_a(GVCSoundEvent.reload_shell, 1.0F, 1.0F);
		    							}
		    							{
		    								vehicle.serverg = false;
		    							}
		    						}
		    		    	}
		    			}
		    		    
		    		    if (vehicle.serverf) {
		    		    	weapon4(vehicle, entitylivingbase, looked);
							vehicle.serverf = false;
						}
		    		    
		    		    
		    		    if (vehicle.serverh) {
							if(vehicle.cooltime6 >= 5){
								if(vehicle.getBoost()) {
									vehicle.setBoost(false);
								}else {
									vehicle.setBoost(true);
								}
								vehicle.cooltime6 = 0;
							}
							vehicle.serverh = false;
						}
				}
				
				
				
				
				
				
				}//player
				else if(vehicle.func_184179_bs() instanceof EntityGVCLivingBase) {
					vehicle.roadattack();
					EntityGVCLivingBase entitylivingbase = (EntityGVCLivingBase) vehicle.func_184179_bs();
					Vec3d looked = entitylivingbase.func_70040_Z();
					if(vehicle.vehicletype == 0) {
						vehicle.rotation = entitylivingbase.field_70759_as;
						vehicle.rotationp = entitylivingbase.field_70125_A;
						AI_EntityMoveTank.move(vehicle, entitylivingbase, f1, vehicle.sp, vehicle.turnspeed, vehicle.mob_min_range, vehicle.mob_max_range);
					}else if(vehicle.vehicletype == 1) {
						AI_EntityMoveAirCraft.movefighter(vehicle, entitylivingbase, f1, vehicle.sp, vehicle.turnspeed, vehicle.mob_min_range, vehicle.mob_max_range, vehicle.mob_min_height);
					}else if(vehicle.vehicletype == 2) {
						AI_EntityMoveAirCraft.moveheli_new(vehicle, entitylivingbase, f1, vehicle.sp, vehicle.turnspeed, vehicle.mob_min_range, vehicle.mob_max_range, vehicle.mob_min_height);
					}else {
						AI_EntityMoveTank.move(vehicle, entitylivingbase, f1, vehicle.sp, vehicle.turnspeed, vehicle.mob_min_range, vehicle.mob_max_range);
					}
					
					if(AI_EntityWeapon.getRange(entitylivingbase, vehicle.mob_w1range, vehicle.mob_w1range_max_y, vehicle.mob_w1range_min_y)){
						if(vehicle.cooltime >= vehicle.ammo1 && vehicle.getRemain_L() > 0){
							vehicle.counter1 = true;
							vehicle.cooltime = 0;
						}
						if(vehicle.weapon1true) {
		    		    	vehicle.weapon1activeMob(looked, entitylivingbase, vehicle.vehicletype);
		    		    }
					}
					/*
					if(AI_EntityWeapon.getRange(entitylivingbase, vehicle.mob_w2range, vehicle.mob_w2range_max_y, vehicle.mob_w2range_min_y)){
	    				if(vehicle.cooltime2 >= vehicle.ammo2 && vehicle.getRemain_R() > 0){
	    					vehicle.counter2 = true;
	    					vehicle.cooltime2 = 0;
	    				}
	    				if(vehicle.weapon2true) {
	        		    	vehicle.weapon2activeMob(looked, entitylivingbase, vehicle.vehicletype);
	        		    }
	    			}
	    			*/
				}
			}
			if(vehicle.vehicletype == 0 || vehicle.vehicletype == 3 || vehicle.vehicletype == 5) {
				AI_TankSet.set2(vehicle, vehicle.movesound, f1, vehicle.sp, 0.1F);
			}else if(vehicle.vehicletype == 1 || vehicle.vehicletype == 4) {
				AI_AirCraftSet.setfighter(vehicle, vehicle.movesound, f1, vehicle.sp, 0.1F);
			}else if(vehicle.vehicletype == 2) {
				AI_AirCraftSet.setheli_NEW(vehicle, vehicle.movesound, f1, vehicle.sp, 0.1F);
			}
		}
		
		
		
		
		
		vehicle.catchEntityBiped();
		
		
	}
	
	
	public static void weapon1(EntityHMV2_Vehicle vehicle, EntityPlayer entitylivingbase, Vec3d looked) {
		if(vehicle.cooltime >= vehicle.ammo1){
			vehicle.counter1 = true;
			vehicle.cooltime = 0;
		}
		if(vehicle.weapon1true) {
			{
				vehicle.weapon1active(looked, entitylivingbase);
			}
	    }
	}
	
	public static void weapon2(EntityHMV2_Vehicle vehicle, EntityPlayer entitylivingbase, Vec3d looked) {
		if(vehicle.cooltime2 >= vehicle.ammo2){
			vehicle.counter2 = true;
			vehicle.cooltime2 = 0;
		}
		if(vehicle.weapon2true) {
	    	vehicle.weapon2active(looked, entitylivingbase);
	    }
	}
	
	public static void weapon3(EntityHMV2_Vehicle vehicle, EntityPlayer entitylivingbase, Vec3d looked) {
		if(vehicle.cooltime3 >= vehicle.ammo3){
			vehicle.counter3 = true;
			vehicle.cooltime3 = 0;
		}
		if(vehicle.weapon3true) {
	    	vehicle.weapon3active(looked, entitylivingbase);
	    }
	}
	
	public static void weapon4(EntityHMV2_Vehicle vehicle, EntityPlayer entitylivingbase, Vec3d looked) {
		if(vehicle.cooltime4 >= vehicle.ammo4){
			vehicle.counter4 = true;
			vehicle.cooltime4 = 0;
		}
		if(vehicle.weapon4true) {
	    	vehicle.weapon4active(looked, entitylivingbase);
	    }
	}
	
	
	
	public static void spg_mode(EntityHMV2_Vehicle vehicle, EntityPlayer entitylivingbase) {
		if (vehicle.getFTMode() == 1) {
			vehicle.spg_mode = true;
			{
				int range = 120;
				float yaw = entitylivingbase.field_70759_as * (2 * (float) Math.PI / 360);
				float xx = 0;
				float zz = 0;
				if (entitylivingbase.field_191988_bg > 0.0F && (vehicle.spg_yaw < range && vehicle.spg_picth < range)) {
					xx = xx + 1;
				}
				if (entitylivingbase.field_191988_bg < 0.0F && (vehicle.spg_yaw > -range && vehicle.spg_picth > -range)) {
					xx = xx - 1;
				}
				if (entitylivingbase.field_70702_br > 0.0F && (vehicle.spg_yaw < range && vehicle.spg_picth < range)) {
					zz = zz + 1;
				}
				if (entitylivingbase.field_70702_br < 0.0F && (vehicle.spg_yaw > -range && vehicle.spg_picth > -range)) {
					zz = zz - 1;
				}
				vehicle.spg_yaw -= MathHelper.func_76126_a(yaw) * xx;
				vehicle.spg_picth += MathHelper.func_76134_b(yaw) * xx;
				vehicle.spg_yaw -= MathHelper.func_76126_a(yaw - 1.57F) * zz;
				vehicle.spg_picth += MathHelper.func_76134_b(yaw - 1.57F) * zz;
				double d5 = vehicle.spg_yaw;
				double d7 = vehicle.spg_picth;
				float yawoffset = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
				vehicle.rotation = yawoffset;
				vehicle.rotationp = -40;
				BlockPos bp = vehicle.field_70170_p.func_175645_m(new BlockPos(vehicle.spg_yaw + vehicle.field_70165_t, vehicle.field_70163_u, vehicle.spg_picth + vehicle.field_70161_v));
				vehicle.spg_y = bp.func_177956_o();
			}
		} else {
			vehicle.spg_mode = false;
			vehicle.spg_yaw = 0;
			vehicle.spg_picth = 0;
			if(vehicle.vehicletype == 0 || vehicle.vehicletype == 3) {
				vehicle.rotation = entitylivingbase.field_70759_as;
				vehicle.rotationp = entitylivingbase.field_70125_A;
				PL_TankMove.move2(entitylivingbase, vehicle, vehicle.sp, vehicle.turnspeed);
			}else if(vehicle.vehicletype == 1 || vehicle.vehicletype == 4) {
				vehicle.rotation  = entitylivingbase.field_70759_as;
				if(vehicle.getFTMode() != 1){
					PL_AirCraftMove.movefighter(entitylivingbase, vehicle, vehicle.sp, vehicle.turnspeed);
				}
			}else if(vehicle.vehicletype == 2) {
				PL_AirCraftMove.moveheli_NEW(entitylivingbase, vehicle, vehicle.sp, vehicle.turnspeed);
			}else if(vehicle.vehicletype == 5) {
				PL_TankMove.movecar(entitylivingbase, vehicle, vehicle.sp, vehicle.turnspeed);
			}
		}
	}
	
}

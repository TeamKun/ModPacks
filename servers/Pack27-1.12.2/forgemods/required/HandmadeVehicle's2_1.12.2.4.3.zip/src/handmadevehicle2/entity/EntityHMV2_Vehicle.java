package handmadevehicle2.entity;

import java.util.List;
import java.util.Random;
import gvclib.entity.living.EntityVehicleBase;
import gvclib.entity.living.ISoldier;
import gvclib.mod_GVCLib;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import gvclib.world.GVCExplosionBase;
import handmadevehicle2.item.ItemSpawnHMV2;
import handmadevehicle2.mod_HandmadeVehicle2;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;


import javax.annotation.Nullable;

import gvclib.mod_GVCLib;
import gvclib.entity.living.EntityVehicleBase;
import gvclib.entity.living.ISoldier;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import gvclib.world.GVCExplosionBase;
import handmadevehicle2.mod_HandmadeVehicle2;
import handmadevehicle2.item.ItemSpawnHMV2;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;

public class EntityHMV2_Vehicle extends EntityVehicleBase
{
    public EntityHMV2_Vehicle(World worldIn)
    {
        super(worldIn);
        this.func_70105_a(2.5F, 2.3F);
        ridding_roteangle = true;
    }

    protected void func_110147_ax()
    {
        super.func_110147_ax();
        
        this.func_110148_a(SharedMonsterAttributes.field_111266_c).func_111128_a(20D);
    }
    
    
    
    public boolean vacanspawn = false;
    public int spawn_rare = 10;
    
    public ItemStack mainitem = new ItemStack((Item)null);// = nullはだめっぽい
    
    
    
    /**HMV2専用?
     *あとでVehicleBaseに移植するはず*/
    
    public boolean bomber_sighting = false;
    public boolean spg_sighting = false;
   
    
    public int exhaust = 0;
    public float[] exhaust_x = new float[32];
    public float[] exhaust_y = new float[32];
    public float[] exhaust_z = new float[32];
    public boolean exhaust_ab = false;
    
    public int laser_sight = 0;
    public float[] laser_sight_x = new float[32];
    public float[] laser_sight_y = new float[32];
    public float[] laser_sight_z = new float[32];
    public int[] laser_sight_weapon = new int[32];
    public boolean[] rote_laser_sight = new boolean[32];
    
    
    //内部用
    public int weapon_mode = 0;
    boolean reset = false;
    
    
    public void readinformation() {
    	ItemStack itemstack = this.func_184582_a(EntityEquipmentSlot.HEAD);
    	if(itemstack.func_77973_b() instanceof ItemSpawnHMV2 && !itemstack.func_190926_b()) {//item_start
    		
    		mainitem = itemstack;
    		spawn_item = itemstack.func_77973_b();
    		
    		this.modid = mod_HandmadeVehicle2.MOD_ID;
    		ItemSpawnHMV2 head = (ItemSpawnHMV2) itemstack.func_77973_b();
    		//this.setModel(head.model);
    		//this.setTex(head.tex);
    		this.model = head.model;
    		this.tex = head.tex;
    		
    		if(head.exhaust_model != null)this.setModel_exhaust(head.exhaust_model);
    		if(head.exhaust_tex != null)this.setTex_exhaust(head.exhaust_tex);
    		
    		//System.out.println(String.format("handmadevehicle-"));
    		
    		this.vacanspawn = head.vacanspawn;
    		this.spawn_rare = head.spawn_rare;
    		
    		this.bomber_sighting = head.bomber_sighting;
    		this.spg_sighting = head.spg_sighting;
    		this.amphibious = head.amphibious;
    		
    		
    		this.maxhp = head.maxhp;
    		this.field_70138_W = head.stepHeight;
    		//this.setwidth = head.setwidth;
    		
    		if(!reset) {
				this.ridding_roteplayer = head.ridding_roteplayer;
				this.riddng_maximum = head.riddng_maximum;
				for (int w1 = 0; w1 < riddng_maximum; ++w1) {
					this.riddingx[w1] = head.riddingx[w1];
					this.riddingy[w1] = head.riddingy[w1];
					this.riddingz[w1] = head.riddingz[w1];
					this.riddingx_roteplayer[w1] = head.riddingx_roteplayer[w1];
					this.riddingy_roteplayer[w1] = head.riddingy_roteplayer[w1];
					this.riddingz_roteplayer[w1] = head.riddingz_roteplayer[w1];
				}

				this.ridding_view1_x = head.ridding_view1_x;
				this.ridding_view1_y = head.ridding_view1_y;
				this.ridding_view1_z = head.ridding_view1_z;

				this.ridding_view_x = head.ridding_view_x;
				this.ridding_view_y = head.ridding_view_y;
				this.ridding_view_z = head.ridding_view_z;

				this.ridding_view_gunner_x = head.ridding_view_gunner_x;
				this.ridding_view_gunner_y = head.ridding_view_gunner_y;
				this.ridding_view_gunner_z = head.ridding_view_gunner_z;

				this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(maxhp);
				this.func_70606_j((float) head.maxhp);
				this.func_70105_a(head.setwidth, head.setheight);
    		}
    		
    		this.ridding_rote = head.ridding_rote;
    		
    		this.ridding_invisible = head.ridding_invisible;
    		this.ridding_zoom = head.ridding_zoom;
    		this.hud_icon = head.hud_icon;
    		this.render_hud_icon_hori = head.render_hud_icon_hori;
    		this.hud_icon_hori = head.hud_icon_hori;
    		this.renderhud = head.renderhud;
    		
    		this.hud_icon_scope = head.hud_icon_scope;
    		this.render_hud_scope = head.render_hud_scope;
    		this.hud_icon_scope_zoom = head.hud_icon_scope_zoom;
    		this.render_hud_scope_zoom = head.render_hud_scope_zoom;
    		this.render_rader = head.render_rader;
    		
    		this.aarader = head.aarader;
    		
    		this.vehicletype = head.vehicletype;
    		if(head.movesound != null)this.movesound = SoundEvent.field_187505_a.func_82594_a(new ResourceLocation(modid, head.movesound));
    		
    		
    		this.riddng_opentop = head.riddng_opentop;
    		this.antibullet_0 = head.antibullet_0;
    		this.antibullet_1 = head.antibullet_1;
    		this.antibullet_2 = head.antibullet_2;
    		this.antibullet_3 = head.antibullet_3;
    		this.ridding_damege = head.ridding_damege;
    		
    		
    		
    	    this.damage_front = head.damage_front;
    	    this.damage_side = head.damage_side;
    	    this.damage_rear = head.damage_rear;
    	    this.damage_top = head.damage_top;
    	    this.damage_bottom = head.damage_bottom;
    	    this.can_turret = head.can_turret;
    	    this.turret_height = head.turret_height;
    	    this.damage_turret_front = head.damage_turret_front;
    	    this.damage_turret_side = head.damage_turret_side;
    	    this.damage_turret_rear = head.damage_turret_rear;
    		
    	    this.roodbreak = head.roodbreak;
    		
    		this.sp = head.sp;
    		this.turnspeed = head.turnspeed;
    		
    		
    		this.thmax = head.thmax;
    		this.thmin = head.thmin;
    		this.thmaxa = head.thmaxa;
    		this.thmina = head.thmina;
    		
    		this.rotationp_max =   head.rotationp_max;
    		this.rotationp_min =   head.rotationp_min;
    		
    		this.ridding_rotation_lock =   head.ridding_rotation_lock;
    		this.rotation_max =   head.rotation_max;
    		
    		this.model_angle_base_x = head.model_angle_base_x;
    		this.model_angle_base_y = head.model_angle_base_y;
    		this.model_angle_base_z = head.model_angle_base_z;
    		this.model_angle_offset_x = head.model_angle_offset_x;
    		this.model_angle_offset_y = head.model_angle_offset_y;
    		this.model_angle_offset_z = head.model_angle_offset_z;
    		this.model_angle_x = head.model_angle_x;
    		this.model_angle_y = head.model_angle_y;
    		this.model_angle_z = head.model_angle_z;
    		
    		this.mob_min_range = head.mob_min_range;
    		this.mob_max_range = head.mob_max_range;
    		this.mob_min_height = head.mob_min_height;
    		
    		this.turret = head.turret;
    		for(int t1 = 0; t1 < turret; ++t1) {
    			this.turretrote[t1] = head.turretrote[t1];
    			this.arm_x[t1] = head.arm_x[t1];
        		this.arm_y[t1] = head.arm_y[t1];
        		this.arm_z[t1] = head.arm_z[t1];
        	    
        		this.hand_x[t1] = head.hand_x[t1];
        		this.hand_y[t1] = head.hand_y[t1];
        		this.hand_z[t1] = head.hand_z[t1];
        		
        		this.finger_type[t1] = head.finger_type[t1];
    		}
    		
    		this.pera = head.pera;
    		for(int t1 = 0; t1 < pera; ++t1) {
    			this.pera_x[t1] = head.pera_x[t1];
        		this.pera_y[t1] = head.pera_y[t1];
        		this.pera_z[t1] = head.pera_z[t1];
        		this.perarote_x[t1] = head.perarote_x[t1];
        		this.perarote_y[t1] = head.perarote_y[t1];
        		this.perarote_z[t1] = head.perarote_z[t1];
    		}
    		
    		this.cloud = head.cloud;
    		for(int t1 = 0; t1 < cloud; ++t1) {
    			this.cloud_x[t1] = head.cloud_x[t1];
        		this.cloud_y[t1] = head.cloud_y[t1];
        		this.cloud_z[t1] = head.cloud_z[t1];
    		}
    		
    		this.rader = head.rader;
    		for(int t1 = 0; t1 < rader; ++t1) {
    			this.raderturret[t1] = head.raderturret[t1];
    			this.rader_x[t1] = head.rader_x[t1];
        		this.rader_y[t1] = head.rader_y[t1];
        		this.rader_z[t1] = head.rader_z[t1];
        		this.raderrote_x[t1] = head.raderrote_x[t1];
        		this.raderrote_y[t1] = head.raderrote_y[t1];
        		this.raderrote_z[t1] = head.raderrote_z[t1];
    		}
    		
    		this.exhaust = head.exhaust;
    		this.exhaust_ab = head.exhaust_ab;
    		for(int t1 = 0; t1 < exhaust; ++t1) {
    			this.exhaust_x[t1] = head.exhaust_x[t1];
        		this.exhaust_y[t1] = head.exhaust_y[t1];
        		this.exhaust_z[t1] = head.exhaust_z[t1];
    		}
    		
    		this.laser_sight = head.laser_sight;
    		for(int t1 = 0; t1 < laser_sight; ++t1) {
    			this.rote_laser_sight[t1] = head.rote_laser_sight[t1];
    			this.laser_sight_x[t1] = head.laser_sight_x[t1];
        		this.laser_sight_y[t1] = head.laser_sight_y[t1];
        		this.laser_sight_z[t1] = head.laser_sight_z[t1];
        		this.laser_sight_weapon[t1] = head.laser_sight_weapon[t1];
    		}
    		
    		
    		{
    			this.weapon1true = head.weapon1true;
        		this.weapon1key = head.weapon1key;
        		this.w1name = head.w1name;
        		this.w1missile_aam = head.w1missile_aam;
        		this.ammo1 = head.ammo1;
        		this.magazine = head.magazine;
        		this.reload_time1 = head.reload_time1;
        		this.reloadsoundset1 = head.reloadsoundset1;
        		if(head.reloadsound1 != null)this.reloadsound1 = SoundEvent.field_187505_a.func_82594_a(new ResourceLocation(modid, head.reloadsound1));
        		this.w1cycle = head.w1cycle;
        		this.w1barst = head.w1barst;
        		this.weapon1 = head.weapon1;
        		this.w1crossfire = head.w1crossfire;
        		this.w1can_cooldown = head.w1can_cooldown;
        		this.w1kakumax = head.w1kakumax;
        		this.w1kakumin = head.w1kakumin;
        		for(int w1 = 0; w1 < weapon1; ++w1) {
        			this.bullet_type1[w1] = head.bullet_type1[w1];
            		this.bullet_model1[w1] = head.bullet_model1[w1];
            		this.bullet_tex1[w1] = head.bullet_tex1[w1];
            		this.fire_model1[w1]= head.fire_model1[w1];
            		this.fire_tex1[w1] = head.fire_tex1[w1];
            		this.fire_time1[w1] = head.fire_time1[w1];
            		this.sound_fire1[w1] = head.sound_fire1[w1];
            		this.fire_pointx1[w1] = head.fire_pointx1[w1];
            		this.fire_pointy1[w1] = head.fire_pointy1[w1];
            		this.fire_pointz1[w1] = head.fire_pointz1[w1];
            		this.basis_pointx1[w1] = head.basis_pointx1[w1];
            		this.basis_pointy1[w1] = head.basis_pointy1[w1];
            		this.basis_pointz1[w1] = head.basis_pointz1[w1];
            		this.fire_yoffset1[w1] = head.fire_yoffset1[w1];
            		this.rotationfollowing1[w1] = head.rotationfollowing1[w1];
            		this.rotation_player1[w1] = head.rotation_player1[w1];
            		this.rotationfirepoint1[w1] = head.rotationfirepoint1[w1];
            		this.rotation_firepointbxbz1[w1] = head.rotation_firepointbxbz1[w1];
            		this.rotation_lock_pitch_vehicle1[w1] = head.rotation_lock_pitch_vehicle1[w1];
            		this.bullet_damage1[w1] = head.bullet_damage1[w1];
            		this.bullet_speed1[w1] = head.bullet_speed1[w1];
            		this.bullet_bure1[w1] = head.bullet_bure1[w1];
            		this.bullet_expower1[w1] = head.bullet_expower1[w1];
            		if(!mod_HandmadeVehicle2.cfg_block_destroy) {
            			this.bullet_ex1[w1] = false;
            		}else {
            			this.bullet_ex1[w1] = head.bullet_ex1[w1];
            		}
            		this.bullet_kazu1[w1] = head.bullet_kazu1[w1];
            		this.bullet_gravity1[w1] = head.bullet_gravity1[w1];
            		this.bullet_livingtime1[w1] = head.bullet_livingtime1[w1];
            		
        		}
    		}
    		{
    			this.weapon11true = head.weapon11true;
        		this.w11name = head.w11name;
        		this.weapon11 = head.weapon11;
        		for(int w11 = 0; w11 < weapon11; ++w11) {
        			this.bullet_type11[w11] = head.bullet_type11[w11];
            		this.bullet_model11[w11] = head.bullet_model11[w11];
            		this.bullet_tex11[w11] = head.bullet_tex11[w11];
            		this.fire_model11[w11]= head.fire_model11[w11];
            		this.fire_tex11[w11] = head.fire_tex11[w11];
            		this.fire_time11[w11] = head.fire_time11[w11];
            		this.sound_fire11[w11] = head.sound_fire11[w11];
            		this.fire_pointx11[w11] = head.fire_pointx11[w11];
            		this.fire_pointy11[w11] = head.fire_pointy11[w11];
            		this.fire_pointz11[w11] = head.fire_pointz11[w11];
            		this.basis_pointx11[w11] = head.basis_pointx11[w11];
            		this.basis_pointy11[w11] = head.basis_pointy11[w11];
            		this.basis_pointz11[w11] = head.basis_pointz11[w11];
            		this.fire_yoffset11[w11] = head.fire_yoffset11[w11];
            		this.rotationfollowing11[w11] = head.rotationfollowing11[w11];
            		this.rotation_player11[w11] = head.rotation_player11[w11];
            		this.rotationfirepoint11[w11] = head.rotationfirepoint11[w11];
            		this.bullet_damage11[w11] = head.bullet_damage11[w11];
            		this.bullet_speed11[w11] = head.bullet_speed11[w11];
            		this.bullet_bure11[w11] = head.bullet_bure11[w11];
            		this.bullet_expower11[w11] = head.bullet_expower11[w11];
            		if(!mod_HandmadeVehicle2.cfg_block_destroy) {
            			this.bullet_ex11[w11] = false;
            		}else {
            			this.bullet_ex11[w11] = head.bullet_ex11[w11];
            		}
            		this.bullet_kazu11[w11] = head.bullet_kazu11[w11];
            		this.bullet_gravity11[w11] = head.bullet_gravity11[w11];
            		this.bullet_livingtime11[w11] = head.bullet_livingtime11[w11];
            		
        		}
    		}
    		{
    			this.weapon12true = head.weapon12true;
        		this.w12name = head.w12name;
        		this.weapon12 = head.weapon12;
        		for(int w12 = 0; w12 < weapon12; ++w12) {
        			this.bullet_type12[w12] = head.bullet_type12[w12];
            		this.bullet_model12[w12] = head.bullet_model12[w12];
            		this.bullet_tex12[w12] = head.bullet_tex12[w12];
            		this.fire_model12[w12]= head.fire_model12[w12];
            		this.fire_tex12[w12] = head.fire_tex12[w12];
            		this.fire_time12[w12] = head.fire_time12[w12];
            		this.sound_fire12[w12] = head.sound_fire12[w12];
            		this.fire_pointx12[w12] = head.fire_pointx12[w12];
            		this.fire_pointy12[w12] = head.fire_pointy12[w12];
            		this.fire_pointz12[w12] = head.fire_pointz12[w12];
            		this.basis_pointx12[w12] = head.basis_pointx12[w12];
            		this.basis_pointy12[w12] = head.basis_pointy12[w12];
            		this.basis_pointz12[w12] = head.basis_pointz12[w12];
            		this.fire_yoffset12[w12] = head.fire_yoffset12[w12];
            		this.rotationfollowing12[w12] = head.rotationfollowing12[w12];
            		this.rotation_player12[w12] = head.rotation_player12[w12];
            		this.rotationfirepoint12[w12] = head.rotationfirepoint1[w12];
            		this.bullet_damage12[w12] = head.bullet_damage12[w12];
            		this.bullet_speed12[w12] = head.bullet_speed12[w12];
            		this.bullet_bure12[w12] = head.bullet_bure12[w12];
            		this.bullet_expower12[w12] = head.bullet_expower12[w12];
            		if(!mod_HandmadeVehicle2.cfg_block_destroy) {
            			this.bullet_ex12[w12] = false;
            		}else {
            			this.bullet_ex12[w12] = head.bullet_ex12[w12];
            		}
            		this.bullet_kazu12[w12] = head.bullet_kazu12[w12];
            		this.bullet_gravity12[w12] = head.bullet_gravity12[w12];
            		this.bullet_livingtime12[w12] = head.bullet_livingtime12[w12];
            		
        		}
    		}
    		this.mob_w1range = head.mob_w1range;
    		this.mob_w1range_max_y = head.mob_w1range_max_y;
    		this.mob_w1range_min_y = head.mob_w1range_min_y;
    		{
    			this.weapon2true = head.weapon2true;
        		this.weapon2key = head.weapon2key;
        		this.w2name = head.w2name;
        		this.w2missile_aam = head.w2missile_aam;
        		this.ammo2 = head.ammo2;
        		this.magazine2 = head.magazine2;
        		this.reload_time2 = head.reload_time2;
        		this.reloadsoundset2 = head.reloadsoundset2;
        		if(head.reloadsound2 != null)this.reloadsound2 = SoundEvent.field_187505_a.func_82594_a(new ResourceLocation(modid, head.reloadsound2));
        		this.w2cycle = head.w2cycle;
        		this.w2barst = head.w2barst;
        		this.weapon2 = head.weapon2;
        		this.w2crossfire = head.w2crossfire;
        		this.w2can_cooldown = head.w2can_cooldown;
        		this.w2kakumax = head.w2kakumax;
        		this.w2kakumin = head.w2kakumin;
        		for(int w2 = 0; w2 < weapon2; ++w2) {
        			this.bullet_type2[w2] = head.bullet_type2[w2];
            		this.bullet_model2[w2] = head.bullet_model2[w2];
            		this.bullet_tex2[w2] = head.bullet_tex2[w2];
            		this.fire_model2[w2]= head.fire_model2[w2];
            		this.fire_tex2[w2] = head.fire_tex2[w2];
            		this.fire_time2[w2] = head.fire_time2[w2];
            		this.sound_fire2[w2] = head.sound_fire2[w2];
            		this.fire_pointx2[w2] = head.fire_pointx2[w2];
            		this.fire_pointy2[w2] = head.fire_pointy2[w2];
            		this.fire_pointz2[w2] = head.fire_pointz2[w2];
            		this.basis_pointx2[w2] = head.basis_pointx2[w2];
            		this.basis_pointy2[w2] = head.basis_pointy2[w2];
            		this.basis_pointz2[w2] = head.basis_pointz2[w2];
            		this.fire_yoffset2[w2] = head.fire_yoffset2[w2];
            		this.rotationfollowing2[w2] = head.rotationfollowing2[w2];
            		this.rotation_player2[w2] = head.rotation_player2[w2];
            		this.rotationfirepoint2[w2] = head.rotationfirepoint2[w2];
            		this.rotation_firepointbxbz2[w2] = head.rotation_firepointbxbz2[w2];
            		this.rotation_lock_pitch_vehicle2[w2] = head.rotation_lock_pitch_vehicle2[w2];
            		this.bullet_damage2[w2] = head.bullet_damage2[w2];
            		this.bullet_speed2[w2] = head.bullet_speed2[w2];
            		this.bullet_bure2[w2] = head.bullet_bure2[w2];
            		this.bullet_expower2[w2] = head.bullet_expower2[w2];
            		if(!mod_HandmadeVehicle2.cfg_block_destroy) {
            			this.bullet_ex2[w2] = false;
            		}else {
            			this.bullet_ex2[w2] = head.bullet_ex2[w2];
            		}
            		this.bullet_kazu2[w2] = head.bullet_kazu2[w2];
            		this.bullet_gravity2[w2] = head.bullet_gravity2[w2];
            		this.bullet_livingtime2[w2] = head.bullet_livingtime2[w2];
            		
        		}
        		this.mob_w2range = head.mob_w2range;
        		this.mob_w2range_max_y = head.mob_w2range_max_y;
        		this.mob_w2range_min_y = head.mob_w2range_min_y;
    		}
    		{
    			this.weapon3true = head.weapon3true;
        		this.weapon3key = head.weapon3key;
        		this.w3name = head.w3name;
        		this.w3missile_aam = head.w3missile_aam;
        		this.ammo3 = head.ammo3;
        		this.magazine3 = head.magazine3;
        		this.reload_time3 = head.reload_time3;
        		this.reloadsoundset3 = head.reloadsoundset3;
        		if(head.reloadsound3 != null)this.reloadsound3 = SoundEvent.field_187505_a.func_82594_a(new ResourceLocation(modid, head.reloadsound3));
        		this.w3cycle = head.w3cycle;
        		this.w3barst = head.w3barst;
        		this.weapon3 = head.weapon3;
        		this.w3crossfire = head.w3crossfire;
        		this.w3can_cooldown = head.w3can_cooldown;
        		this.w3kakumax = head.w3kakumax;
        		this.w3kakumin = head.w3kakumin;
        		for(int w3 = 0; w3 < weapon3; ++w3) {
        			this.bullet_type3[w3] = head.bullet_type3[w3];
            		this.bullet_model3[w3] = head.bullet_model3[w3];
            		this.bullet_tex3[w3] = head.bullet_tex3[w3];
            		this.fire_model3[w3]= head.fire_model3[w3];
            		this.fire_tex3[w3] = head.fire_tex3[w3];
            		this.fire_time3[w3] = head.fire_time3[w3];
            		this.sound_fire3[w3] = head.sound_fire3[w3];
            		this.fire_pointx3[w3] = head.fire_pointx3[w3];
            		this.fire_pointy3[w3] = head.fire_pointy3[w3];
            		this.fire_pointz3[w3] = head.fire_pointz3[w3];
            		this.basis_pointx3[w3] = head.basis_pointx3[w3];
            		this.basis_pointy3[w3] = head.basis_pointy3[w3];
            		this.basis_pointz3[w3] = head.basis_pointz3[w3];
            		this.fire_yoffset3[w3] = head.fire_yoffset3[w3];
            		this.rotationfollowing3[w3] = head.rotationfollowing3[w3];
            		this.rotation_player3[w3] = head.rotation_player3[w3];
            		this.rotationfirepoint3[w3] = head.rotationfirepoint3[w3];
            		this.rotation_firepointbxbz3[w3] = head.rotation_firepointbxbz3[w3];
            		this.rotation_lock_pitch_vehicle3[w3] = head.rotation_lock_pitch_vehicle3[w3];
            		this.bullet_damage3[w3] = head.bullet_damage3[w3];
            		this.bullet_speed3[w3] = head.bullet_speed3[w3];
            		this.bullet_bure3[w3] = head.bullet_bure3[w3];
            		this.bullet_expower3[w3] = head.bullet_expower3[w3];
            		if(!mod_HandmadeVehicle2.cfg_block_destroy) {
            			this.bullet_ex3[w3] = false;
            		}else {
            			this.bullet_ex3[w3] = head.bullet_ex3[w3];
            		}
            		this.bullet_kazu3[w3] = head.bullet_kazu3[w3];
            		this.bullet_gravity3[w3] = head.bullet_gravity3[w3];
            		this.bullet_livingtime3[w3] = head.bullet_livingtime3[w3];
            		
        		}
        		this.mob_w3range = head.mob_w3range;
        		this.mob_w3range_max_y = head.mob_w3range_max_y;
        		this.mob_w3range_min_y = head.mob_w3range_min_y;
    		}
    		{
    			this.weapon4true = head.weapon4true;
        		this.weapon4key = head.weapon4key;
        		this.w4name = head.w4name;
        		this.w4missile_aam = head.w4missile_aam;
        		this.ammo4 = head.ammo4;
        		this.magazine4 = head.magazine4;
        		this.reload_time4 = head.reload_time4;
        		this.reloadsoundset4 = head.reloadsoundset4;
        		if(head.reloadsound4 != null)this.reloadsound4 = SoundEvent.field_187505_a.func_82594_a(new ResourceLocation(modid, head.reloadsound4));
        		this.w4cycle = head.w4cycle;
        		this.w4barst = head.w4barst;
        		this.weapon4 = head.weapon4;
        		this.w4crossfire = head.w4crossfire;
        		this.w4can_cooldown = head.w4can_cooldown;
        		this.w4kakumax = head.w4kakumax;
        		this.w4kakumin = head.w4kakumin;
        		for(int w4 = 0; w4 < weapon4; ++w4) {
        			this.bullet_type4[w4] = head.bullet_type4[w4];
            		this.bullet_model4[w4] = head.bullet_model4[w4];
            		this.bullet_tex4[w4] = head.bullet_tex4[w4];
            		this.fire_model4[w4]= head.fire_model4[w4];
            		this.fire_tex4[w4] = head.fire_tex4[w4];
            		this.fire_time4[w4] = head.fire_time4[w4];
            		this.sound_fire4[w4] = head.sound_fire4[w4];
            		this.fire_pointx4[w4] = head.fire_pointx4[w4];
            		this.fire_pointy4[w4] = head.fire_pointy4[w4];
            		this.fire_pointz4[w4] = head.fire_pointz4[w4];
            		this.basis_pointx4[w4] = head.basis_pointx4[w4];
            		this.basis_pointy4[w4] = head.basis_pointy4[w4];
            		this.basis_pointz4[w4] = head.basis_pointz4[w4];
            		this.fire_yoffset4[w4] = head.fire_yoffset4[w4];
            		this.rotationfollowing4[w4] = head.rotationfollowing4[w4];
            		this.rotation_player4[w4] = head.rotation_player4[w4];
            		this.rotationfirepoint4[w4] = head.rotationfirepoint4[w4];
            		this.rotation_firepointbxbz4[w4] = head.rotation_firepointbxbz4[w4];
            		this.rotation_lock_pitch_vehicle4[w4] = head.rotation_lock_pitch_vehicle4[w4];
            		this.bullet_damage4[w4] = head.bullet_damage4[w4];
            		this.bullet_speed4[w4] = head.bullet_speed4[w4];
            		this.bullet_bure4[w4] = head.bullet_bure4[w4];
            		this.bullet_expower4[w4] = head.bullet_expower4[w4];
            		if(!mod_HandmadeVehicle2.cfg_block_destroy) {
            			this.bullet_ex4[w4] = false;
            		}else {
            			this.bullet_ex4[w4] = head.bullet_ex4[w4];
            		}
            		this.bullet_kazu4[w4] = head.bullet_kazu4[w4];
            		this.bullet_gravity4[w4] = head.bullet_gravity4[w4];
            		this.bullet_livingtime4[w4] = head.bullet_livingtime4[w4];
            		
        		}
        		this.mob_w4range = head.mob_w4range;
        		this.mob_w4range_max_y = head.mob_w4range_max_y;
        		this.mob_w4range_min_y = head.mob_w4range_min_y;
    		}
    		
    		
    		
    		
    		reset = true;
    	}//item_end
    }
    
    boolean spawn = true;
    
    public void func_70636_d() {
		super.func_70636_d();
		
		AI_EntityVehicle.load(this);
		//何が何でも銃は手放さない
				if (this.func_184187_bx() == null) {// 1
					if( this.func_184582_a(EntityEquipmentSlot.HEAD).func_190926_b()) {
						if(!mainitem.func_190926_b()) {
							this.func_184201_a(EntityEquipmentSlot.HEAD, mainitem);
						}
					}
				}
		
				if (this.func_82171_bF() && this.func_184179_bs() != null && this.func_110143_aJ() > 0.0F)
				{
					if(this.func_184179_bs() instanceof EntityPlayer)
					{
						boolean kv = mod_GVCLib.proxy.keyv();
						boolean kb = mod_GVCLib.proxy.keyb();
						if (kv) {
							GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(20, this.func_145782_y()));
						}
						if (kb) {
							GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(21, this.func_145782_y()));
						}
						if (this.serverb) {
							for(int m = 0; m < this.func_184188_bt().size(); ++m) {
								//if (!this.world.isRemote && this.getPassengers().get(m) != null) {
								if (this.func_184188_bt().get(m) != null) {
									if (this.func_184188_bt().get(m) instanceof EntityLivingBase
											&& !(this.func_184188_bt().get(m) instanceof EntityPlayer)) {
										EntityLivingBase entity = (EntityLivingBase)this.func_184188_bt().get(m);
										entity.func_184210_p();
									}
								}
							}
							this.serverb = false;
						}
						
						if (this.serverv) {
							{
								List<Entity> list = this.field_70170_p.func_72839_b(this,this.func_174813_aQ().func_186662_g(3D));
								if (!list.isEmpty()) {
									for (int j = 0; j < list.size(); ++j) {
										Entity entity = list.get(j);
										if (!entity.func_184196_w(this)) {
											if (this.func_184188_bt().size() < riddng_maximum && !entity.func_184218_aH()
													&& (entity instanceof ISoldier || entity instanceof IAnimals) && !(entity instanceof EntityVehicleBase)) {
												entity.func_184220_m(this);
											} else {
												this.func_70108_f(entity);
											}
										}
									}
								}
							}
							this.serverv = false;
						}
					}
				}
    }
    
    protected void func_70609_aI() {
 		++this.deathTicks;
 		int x = this.field_70170_p.field_73012_v.nextInt(4);
 		int y = this.field_70170_p.field_73012_v.nextInt(5);
 		int z = this.field_70170_p.field_73012_v.nextInt(4);
 		if (this.deathTicks == 1 && !this.field_70170_p.field_72995_K) {
 			GVCExplosionBase.ExplosionKai(this, this, this.field_70165_t + 0, this.field_70163_u + 0, this.field_70161_v + 0, 3, false,  false);
 		}
 		if (this.deathTicks == 200 && !this.field_70170_p.field_72995_K) {
 			this.func_70106_y();
 		}
 	}
    
    public void func_70071_h_()
    {
        super.func_70071_h_();
        if (!this.field_70170_p.field_72995_K && this.field_70170_p.func_175659_aa() == EnumDifficulty.PEACEFUL && this.getcanDespawn() == 0)
        {
            this.func_70106_y();
        }
    }
    
   public void func_70108_f(Entity entityIn)
   {
       if (entityIn instanceof EntityHMV2_Vehicle)
       {
           if (entityIn.func_174813_aQ().field_72338_b < this.func_174813_aQ().field_72337_e)
           {
               super.func_70108_f(entityIn);
           }
       }
       else if (entityIn.func_174813_aQ().field_72338_b <= this.func_174813_aQ().field_72338_b)
       {
           super.func_70108_f(entityIn);
       }
   }
   
   @Nullable
   public IEntityLivingData func_180482_a(DifficultyInstance difficulty, @Nullable IEntityLivingData livingdata)
   {
       livingdata = super.func_180482_a(difficulty, livingdata);
       System.out.println(String.format("spawn"));
      // if(!this.world.isRemote)
       {
    	   EntityHMV2_S entityskeleton = new EntityHMV2_S(this.field_70170_p);
	        entityskeleton.func_70012_b(this.field_70165_t+0.5, this.field_70163_u, this.field_70161_v+0.5, 0, 0.0F);
	        entityskeleton.func_180482_a(difficulty, (IEntityLivingData)null);
	        this.field_70170_p.func_72838_d(entityskeleton);
	        entityskeleton.func_184220_m(this);
       }
       {
    	   Random ra = new Random();
    	   int i = ra.nextInt(mod_HandmadeVehicle2.max_spawn + 1);
    	   ItemStack item = new ItemStack(mod_HandmadeVehicle2.spawn_entity[i]);
    	   System.out.println(String.format("%1$3d", i));
    	   if(!item.func_190926_b()) {
    		   this.func_184201_a(EntityEquipmentSlot.HEAD, item);
    	   }
       }
       return livingdata;
   }
   
   /*
   public boolean CanAttack(Entity entity){
		if (this.getControllingPassenger() instanceof EntityPlayer || this.getControllingPassenger() instanceof ISoldier) {
			if (entity instanceof IMob && ((EntityLivingBase) entity).getHealth() > 0.0F) {
				return true;
			} else {
				return false;
			}
		} else if (this.getControllingPassenger() instanceof IMob) {
			if ((entity instanceof ISoldier || entity instanceof EntityGolem || entity instanceof EntityVillager)
					&& ((EntityLivingBase) entity).getHealth() > 0.0F) {
				return true;
			} else if (entity instanceof EntityPlayer && ((EntityLivingBase) entity).getHealth() > 0.0F) {
				EntityPlayer entityplayer = (EntityPlayer) entity;
				ItemStack itemstack = entityplayer.getItemStackFromSlot(EntityEquipmentSlot.HEAD);
				if (itemstack != null && itemstack.getItem() == Items.GOLDEN_HELMET) {
					return false;
				} else {
					return true;
				}
			} else {
				return false;
		    }
		} else {
			return false;
		}
   }*/
   
   /**
    * Checks to make sure the light is not too bright where the mob is spawning
    */
   protected boolean isValidLightLevel()
   {
       BlockPos blockpos = new BlockPos(this.field_70165_t, this.func_174813_aQ().field_72338_b, this.field_70161_v);

       if (this.field_70170_p.func_175642_b(EnumSkyBlock.SKY, blockpos) > this.field_70146_Z.nextInt(32))
       {
           return false;
       }
       else
       {
           int i = this.field_70170_p.func_175671_l(blockpos);

           if (this.field_70170_p.func_72911_I())
           {
               int j = this.field_70170_p.func_175657_ab();
               this.field_70170_p.func_175692_b(10);
               i = this.field_70170_p.func_175671_l(blockpos);
               this.field_70170_p.func_175692_b(j);
           }

           return i <= this.field_70146_Z.nextInt(8);
       }
   }

   /**
    * Checks if the entity's current position is a valid location to spawn this entity.
    */
   public boolean func_70601_bi()
   {
       return this.field_70170_p.func_175659_aa() != EnumDifficulty.PEACEFUL && this.isValidLightLevel() && super.func_70601_bi();
   }
   
   /**
    * Determines if an entity can be despawned, used on idle far away entities
    */
   protected boolean func_70692_ba()
   {
	   if(this.getcanDespawn() == 1) {
		   return false;
	   }else {
		   return true;
	   }
   }
   
}

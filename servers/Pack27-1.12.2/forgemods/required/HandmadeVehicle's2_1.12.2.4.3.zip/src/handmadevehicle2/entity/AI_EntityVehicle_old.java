package handmadevehicle2.entity;

import java.util.List;
import java.util.Random;
import gvclib.entity.living.AI_AirCraftSet;
import gvclib.entity.living.AI_EntityMoveAirCraft;
import gvclib.entity.living.AI_EntityMoveTank;
import gvclib.entity.living.AI_EntityWeapon;
import gvclib.entity.living.AI_TankSet;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.PL_AirCraftMove;
import gvclib.entity.living.PL_TankMove;
import gvclib.entity.living.cnt.VehicleCNT_Tank_SPG;
import gvclib.event.GVCSoundEvent;
import gvclib.mod_GVCLib;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;


import gvclib.mod_GVCLib;
import gvclib.entity.living.AI_AirCraftSet;
import gvclib.entity.living.AI_EntityMoveAirCraft;
import gvclib.entity.living.AI_EntityMoveTank;
import gvclib.entity.living.AI_EntityWeapon;
import gvclib.entity.living.AI_TankSet;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.ISoldier;
import gvclib.entity.living.PL_AirCraftMove;
import gvclib.entity.living.PL_TankMove;
import gvclib.entity.living.cnt.VehicleCNT_Tank_SPG;
import gvclib.event.GVCSoundEvent;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class AI_EntityVehicle_old {

	public static void load(EntityHMV2_Vehicle vehicle) {

		vehicle.readinformation();
		
		if(vehicle.riddng_maximum > 1){
			vehicle.render_hud_information_5 = "V-KEY:ALLY-Boarding";
			vehicle.render_hud_information_6 = "B-KEY:ALLY-Get off";
		}
		
		
		 if(vehicle.vehicletype == 2) {
			    vehicle.render_hud_information_1 = "Z-KEY:Get off";
	        	vehicle.render_hud_information_2 = "W/S-KEY:Throttle-UP/DWON";
	            vehicle.render_hud_information_3 = "SPEAC/SHIFT-KEY:UP/DWON";
	            vehicle.render_hud_information_4 = "Mouse-UP/DOWN:PICTH-UP/DOWN";
	            
	        }
		 if(vehicle.vehicletype == 3 || vehicle.spg_sighting) {
			    vehicle.render_hud_information_1 = "G-KEY:SPG_MODE";
	            
	        }
		
		if(vehicle.vehicletype == 2) {
			vehicle.ridding_sneakdismount = false;
			if(vehicle.getArmID_S() == 1) {
				vehicle.render_hud_scaleup_text1 = false;
				vehicle.render_hud_scaleup_text2 = true;
			}else {
				vehicle.render_hud_scaleup_text1 = true;
				vehicle.render_hud_scaleup_text2 = false;
			}
		}
		if(vehicle.vehicletype == 5) {
			if (vehicle.field_70170_p
					.func_180495_p(new BlockPos(vehicle.field_70165_t, vehicle.field_70163_u + 0.8, vehicle.field_70161_v))
					.func_185904_a() == Material.field_151586_h) {
				//entity.motionY = 0.05F;
				vehicle.field_70181_x = -vehicle.field_70181_x;
				vehicle.field_70181_x = vehicle.field_70181_x * 0.5F;
			}
		}
		
		
		/*
		if(!vehicle.vacanspawn && vehicle.getcanDespawn() == 0 && !vehicle.world.isRemote) {
			System.out.println(String.format("desspawn"));
			vehicle.setDead();
			if(vehicle.getControllingPassenger() != null)
			{
				vehicle.getControllingPassenger().setDead();
			}
		}
		*/
		if(vehicle.vacanspawn && vehicle.getcanDespawn() == 0 && !vehicle.field_70170_p.field_72995_K && vehicle.spawn) {
			Random ra = new Random();
			int i = ra.nextInt(100 - vehicle.spawn_rare);
			if (i == 0) {
				System.out.println(String.format("desspawn2"));
				vehicle.func_70106_y();
				if (vehicle.func_184179_bs() != null) {
					vehicle.func_184179_bs().func_70106_y();
				}
			}
		}
		vehicle.spawn = false;
		
		float f1 = vehicle.field_70759_as * (2 * (float) Math.PI / 360);
		
		vehicle.roadattack();
		
		if(vehicle.vehicletype == 3) {
			VehicleCNT_Tank_SPG.load(vehicle, vehicle.movesound);
		}else {
			if (vehicle.func_82171_bF() && vehicle.func_184179_bs() != null  && vehicle.func_110143_aJ() > 0.0F)
			{
				if(vehicle.func_184179_bs() instanceof EntityPlayer)
				{
				EntityPlayer entitylivingbase = (EntityPlayer) vehicle.func_184179_bs();
				Vec3d looked = entitylivingbase.func_70040_Z();
				if(vehicle.vehicletype == 0) {
					vehicle.rotation = entitylivingbase.field_70759_as;
					vehicle.rotationp = entitylivingbase.field_70125_A;
					PL_TankMove.move2(entitylivingbase, vehicle, vehicle.sp, vehicle.turnspeed);
				}else if(vehicle.vehicletype == 1 || vehicle.vehicletype == 4) {
					vehicle.rotation  = entitylivingbase.field_70759_as;
					if(vehicle.getFTMode() != 1){
						PL_AirCraftMove.movefighter(entitylivingbase, vehicle, vehicle.sp, vehicle.turnspeed);
					}
				}else if(vehicle.vehicletype == 2) {
					//vehicle.rotation  = entitylivingbase.rotationYawHead;
					//vehicle.rotationp = vehicle.rotationPitch = entitylivingbase.rotationPitch;
					PL_AirCraftMove.moveheli_NEW(entitylivingbase, vehicle, vehicle.sp, vehicle.turnspeed);
				}else if(vehicle.vehicletype == 5) {
					//vehicle.rotation  = entitylivingbase.rotationYawHead;
					//vehicle.rotationp = vehicle.rotationPitch = entitylivingbase.rotationPitch;
					PL_TankMove.movecar(entitylivingbase, vehicle, vehicle.sp, vehicle.turnspeed);
					//PL_TankMove.move2(entitylivingbase, vehicle, vehicle.sp, vehicle.turnspeed);
				}
				
				vehicle.roadattack();
				
				boolean left = mod_GVCLib.proxy.leftclick();
				boolean right = mod_GVCLib.proxy.rightclick();
				boolean jump = mod_GVCLib.proxy.jumped();
				boolean kx = mod_GVCLib.proxy.keyx();
				boolean kg = mod_GVCLib.proxy.keyg();
				boolean kc = mod_GVCLib.proxy.keyc();
				if (left) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(11, vehicle.func_145782_y()));
					vehicle.server1 = true;
				}
				if (right) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(12, vehicle.func_145782_y()));
				}
				if (jump) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(13, vehicle.func_145782_y()));
				}
				if (kx) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(14, vehicle.func_145782_y()));
				}
				if (kg) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(15, vehicle.func_145782_y()));
				}
				if (kc) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(16, vehicle.func_145782_y()));
				}
				
				if(vehicle.vehicletype == 2) {
					if (vehicle.serverx) {
						if(vehicle.cooltime3 >= 5){
							if(vehicle.getArmID_S() == 1) {
								vehicle.setArmID_S(0);
							}else {
								vehicle.setArmID_S(1);
							}
							vehicle.func_184185_a(GVCSoundEvent.reload_shell, 1.0F, 1.0F);
							vehicle.cooltime3 = 0;
						}
						vehicle.serverx = false;
					}
				
				 if (vehicle.server1) {
						if(vehicle.getArmID_S() == 1){
		    				if(vehicle.cooltime2 >= vehicle.ammo2){
		    					vehicle.counter2 = true;
		    					vehicle.cooltime2 = 0;
		    				}
		    				if(vehicle.weapon2true) {
		    					vehicle.weapon2active(looked, entitylivingbase);
		        		    }
		    			}else {
		    				if(vehicle.cooltime >= vehicle.ammo1){
		    					vehicle.counter1 = true;
		    					vehicle.cooltime = 0;
		    				}
		    				if(vehicle.weapon1true) {
		    					vehicle.weapon1active(looked, entitylivingbase);
		        		    }
		    			}
						vehicle.server1 = false;
					}
				}else {
					/*if (vehicle.serverx) {
						if (vehicle.cooltime5 > 1 && vehicle.getRemain_A() > 0) {
							if(vehicle.getArmID_R() == 0 && vehicle.weapon11true){
								vehicle.setArmID_R(1);
							}else if(vehicle.getArmID_R() == 1 && vehicle.weapon12true){
								vehicle.setArmID_R(2);
							}else
							{
								vehicle.setArmID_R(0);
							}
							vehicle.cooltime5 = 0;
							vehicle.setRemain_A(vehicle.getRemain_A() - 1);
							vehicle.playSound(GVCSoundEvent.reload_shell, 1.0F, 1.0F);
						}
						{
							vehicle.serverx = false;
						}
					}
					*/
					/*
					if (vehicle.serverg && vehicle.vehicletype != 0) {
						if (vehicle.cooltime6 > 1 && vehicle.getWeaponChange() > 0) {
							vehicle.world.playSound((EntityPlayer) null, vehicle.posX, vehicle.posY,
									vehicle.posZ, SoundEvents.BLOCK_STONE_BUTTON_CLICK_ON, SoundCategory.NEUTRAL, 1.0F, 1.0F);
							if(vehicle.getFTMode() >= 1){
								vehicle.setFTMode(0);
							}else
							{
								vehicle.setFTMode(1);
							}
							vehicle.cooltime6 = 0;
							vehicle.setWeaponChange(vehicle.getWeaponChange() - 1);
						}
						{
							
							vehicle.serverg = false;
						}
					}*/
					
		    		    if(vehicle.server1)
		    		    {
		    		    	if(vehicle.weapon1key == 0){
			    				if(vehicle.cooltime >= vehicle.ammo1){
			    					vehicle.counter1 = true;
			    					vehicle.cooltime = 0;
			    				}
			    				if(vehicle.weapon1true) {
			    					if(vehicle.getArmID_R() == 1 && vehicle.weapon11true){
			    						vehicle.weapon11active(looked, entitylivingbase);
			    					}else if(vehicle.getArmID_R() == 2 && vehicle.weapon12true){
			    						vehicle.weapon12active(looked, entitylivingbase);
			    					}else {
			    						vehicle.weapon1active(looked, entitylivingbase);
			    					}
			        		    }
			    			}
		    		    	if(vehicle.weapon2key == 0){
			    				if(vehicle.cooltime2 >= vehicle.ammo2){
			    					vehicle.counter2 = true;
			    					vehicle.cooltime2 = 0;
			    				}
			    				if(vehicle.weapon2true) {
			        		    	vehicle.weapon2active(looked, entitylivingbase);
			        		    }
			    			}
		    		    	vehicle.server1 = false;
						}
		    		    
		    		    if(vehicle.server2)
		    		    {
		    		    	if(vehicle.weapon1key == 1){
			    				if(vehicle.cooltime >= vehicle.ammo1){
			    					vehicle.counter1 = true;
			    					vehicle.cooltime = 0;
			    				}
			    				if(vehicle.weapon1true) {
			    					if(vehicle.getArmID_R() == 1 && vehicle.weapon11true){
			    						vehicle.weapon11active(looked, entitylivingbase);
			    					}else if(vehicle.getArmID_R() == 2 && vehicle.weapon12true){
			    						vehicle.weapon12active(looked, entitylivingbase);
			    					}else {
			    						vehicle.weapon1active(looked, entitylivingbase);
			    					}
			        		    }
			    			}
		    		    	
		    		    	if(vehicle.weapon2key == 1){
			    				if(vehicle.cooltime2 >= vehicle.ammo2){
			    					vehicle.counter2 = true;
			    					vehicle. cooltime2 = 0;
			    				}
			    				if(vehicle.weapon2true) {
			        		    	vehicle.weapon2active(looked, entitylivingbase);
			        		    }
			    			}
		    		    	vehicle.server2 = false;
						}
		    		    
		    		    if(vehicle.serverspace)
		    		    {
		    		    	if(vehicle.weapon1key == 2){
			    				if(vehicle.cooltime >= vehicle.ammo1){
			    					vehicle.counter1 = true;
			    					vehicle.cooltime = 0;
			    				}
			    				if(vehicle.weapon1true) {
			    					if(vehicle.getArmID_R() == 1 && vehicle.weapon11true){
			    						vehicle.weapon11active(looked, entitylivingbase);
			    					}else if(vehicle.getArmID_R() == 2 && vehicle.weapon12true){
			    						vehicle.weapon12active(looked, entitylivingbase);
			    					}else {
			    						vehicle.weapon1active(looked, entitylivingbase);
			    					}
			        		    }
			    			}
		    		    	
		    		    	if(vehicle.weapon2key == 2){
			    				if(vehicle.cooltime2 >= vehicle.ammo2){
			    					vehicle.counter2 = true;
			    					vehicle.cooltime2 = 0;
			    				}
			    				if(vehicle.weapon2true) {
			        		    	vehicle.weapon2active(looked, entitylivingbase);
			        		    }
			    			}
		    		    	vehicle.serverspace = false;
						}
				}
				
				
				
				
				
				
				}//player
				else if(vehicle.func_184179_bs() instanceof EntityGVCLivingBase) {
					vehicle.roadattack();
					EntityGVCLivingBase entitylivingbase = (EntityGVCLivingBase) vehicle.func_184179_bs();
					Vec3d looked = entitylivingbase.func_70040_Z();
					if(vehicle.vehicletype == 0) {
						vehicle.rotation = entitylivingbase.field_70759_as;
						vehicle.rotationp = entitylivingbase.field_70125_A;
						AI_EntityMoveTank.move(vehicle, entitylivingbase, f1, vehicle.sp, vehicle.turnspeed, vehicle.mob_min_range, vehicle.mob_max_range);
					}else if(vehicle.vehicletype == 1) {
						AI_EntityMoveAirCraft.movefighter(vehicle, entitylivingbase, f1, vehicle.sp, vehicle.turnspeed, vehicle.mob_min_range, vehicle.mob_max_range, vehicle.mob_min_height);
					}else if(vehicle.vehicletype == 2) {
						AI_EntityMoveAirCraft.moveheli_new(vehicle, entitylivingbase, f1, vehicle.sp, vehicle.turnspeed, vehicle.mob_min_range, vehicle.mob_max_range, vehicle.mob_min_height);
					}
					AI_EntityMoveTank.move(vehicle, entitylivingbase, f1, vehicle.sp, vehicle.turnspeed, vehicle.mob_min_range, vehicle.mob_max_range);
					if(AI_EntityWeapon.getRange(entitylivingbase, vehicle.mob_w1range, vehicle.mob_w1range_max_y, vehicle.mob_w1range_min_y)){
						if(vehicle.cooltime >= vehicle.ammo1 && vehicle.getRemain_L() > 0){
							vehicle.counter1 = true;
							vehicle.cooltime = 0;
						}
						if(vehicle.weapon1true) {
		    		    	vehicle.weapon1activeMob(looked, entitylivingbase, vehicle.vehicletype);
		    		    }
					}
					/*
					if(AI_EntityWeapon.getRange(entitylivingbase, vehicle.mob_w2range, vehicle.mob_w2range_max_y, vehicle.mob_w2range_min_y)){
	    				if(vehicle.cooltime2 >= vehicle.ammo2 && vehicle.getRemain_R() > 0){
	    					vehicle.counter2 = true;
	    					vehicle.cooltime2 = 0;
	    				}
	    				if(vehicle.weapon2true) {
	        		    	vehicle.weapon2activeMob(looked, entitylivingbase, vehicle.vehicletype);
	        		    }
	    			}
	    			*/
				}
			}
			if(vehicle.vehicletype == 0 || vehicle.vehicletype == 5) {
				AI_TankSet.set2(vehicle, vehicle.movesound, f1, vehicle.sp, 0.1F);
			}else if(vehicle.vehicletype == 1 || vehicle.vehicletype == 4) {
				AI_AirCraftSet.setfighter(vehicle, vehicle.movesound, f1, vehicle.sp, 0.1F);
			}else if(vehicle.vehicletype == 2) {
				AI_AirCraftSet.setheli_NEW(vehicle, vehicle.movesound, f1, vehicle.sp, 0.1F);
			}
		}
		
		
		
		
		
		vehicle.catchEntityBiped();
		
		
	}
	
}

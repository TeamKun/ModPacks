package handmadevehicle2.entity;

import gvclib.entity.living.AI_EntityMoveS;
import gvclib.entity.living.AI_EntityWeapon;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.ISoldier;
import gvclib.item.ItemGunBase;
import handmadevehicle2.mod_HandmadeVehicle2;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIFleeSun;
import net.minecraft.entity.ai.EntityAIRestrictSun;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

public class EntityHMV2_S extends EntityGVCLivingBase implements IMob{

	public EntityHMV2_S(World worldIn) {
		super(worldIn);
		this.func_70105_a(0.5F, 1.8F);
	}

	protected void func_184651_r() {
		this.field_70714_bg.func_75776_a(1, new EntityAISwimming(this));
		this.field_70714_bg.func_75776_a(2, new EntityAIRestrictSun(this));
		this.field_70714_bg.func_75776_a(3, new EntityAIFleeSun(this, 1.0D));
		
	}

	protected void func_110147_ax() {
		super.func_110147_ax();
		this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(20D);
		// this.getEntityAttribute(SharedMonsterAttributes.KNOCKBACK_RESISTANCE).setBaseValue(20D);
		this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.25D);
		this.func_110148_a(SharedMonsterAttributes.field_111265_b).func_111128_a(100.0D);
	}

	protected void func_180481_a(DifficultyInstance difficulty) {
		super.func_180481_a(difficulty);
		
	}
	
	public boolean CanAttack(Entity entity){
    	if(!(entity instanceof EntityHMV2_S) && entity instanceof EntityGolem && ((EntityLivingBase) entity).func_110143_aJ() > 0.0F){
    		return true;
    	}else if((entity instanceof ISoldier || entity instanceof EntityGolem || entity instanceof EntityVillager) && ((EntityLivingBase) entity).func_110143_aJ() > 0.0F){
    		return true;
    	}else if(entity instanceof EntityPlayer && ((EntityLivingBase) entity).func_110143_aJ() > 0.0F){
    		EntityPlayer entityplayer = (EntityPlayer) entity;
    		ItemStack itemstack = entityplayer.func_184582_a(EntityEquipmentSlot.HEAD);
    		if(itemstack != null && itemstack.func_77973_b() == Items.field_151169_ag){
    			return false;
    		}else{
    		return true;
    		}
    	}else{
    		return false;
    	}
    }
    
	public void func_70071_h_()
    {
        super.func_70071_h_();
        if (!this.field_70170_p.field_72995_K && this.field_70170_p.func_175659_aa() == EnumDifficulty.PEACEFUL && this.getcanDespawn() == 0)
        {
            this.func_70106_y();
        }
    }
	
	/**
	 * Called frequently so the entity can update its state every tick as
	 * required. For example, zombies and skeletons use this to react to
	 * sunlight and start to burn.
	 */
    int self_ex = 0;
	public void func_70636_d() {
		super.func_70636_d();
		this.biped = true;
		
		float sp = 0.04F;
		Vec3d looked = this.func_70040_Z();
		if (this.func_184187_bx() == null) {// 1
			if( this.func_184582_a(EntityEquipmentSlot.MAINHAND).func_190926_b()) {
				//this.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
				this.func_184201_a(EntityEquipmentSlot.MAINHAND, new ItemStack(mod_HandmadeVehicle2.hmv2_wrench));
			}
		}
		//this.setAIType(0);
		this.func_82168_bl();
		
		AI_EntityWeapon.getTargetEntity(this, 50, 20, 20);
		
		int max = 30;
		int range = 30;
		int range2 = 40;
		ItemStack itemstack = this.func_184614_ca();
		if(!itemstack.func_190926_b()){
			if (itemstack.func_77973_b() instanceof ItemBow) 
	    	{
				AI_EntityWeapon.Biped_Gun(this, itemstack,false);
				if (itemstack.func_77973_b() instanceof ItemGunBase) 
		    	{
					ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
					max = gun.mobmax;
		    		range = (int) (gun.mobrange *0.75D);
		    		range2 = gun.mobrange;
		    	}
				AI_EntityMoveS.newmove(this, 0, sp, 0, max, range, range2);
	    	}
			else if (itemstack.func_77973_b() instanceof ItemSword || itemstack.func_77973_b() instanceof ItemAxe || itemstack.func_77973_b() instanceof ItemSpade) 
	    	{
				max = 2;
				AI_EntityWeapon.Biped_Sword(this, itemstack);
				AI_EntityMoveS.newmove(this, 1, sp, 0, max, range, range2);
	    	}
			
		}
		ItemStack itemstackl = this.func_184592_cb();
		if(!itemstackl.func_190926_b()){
			if (itemstackl.func_77973_b() instanceof ItemBow) 
	    	{
				AI_EntityWeapon.Biped_Gun(this, itemstackl,false);
				if (itemstackl.func_77973_b() instanceof ItemGunBase) 
		    	{
					ItemGunBase gun = (ItemGunBase) itemstackl.func_77973_b();
					max = gun.mobmax;
		    		range = gun.mobrange;
		    	}
				//AI_EntityMoveS.newmove(this, 0, sp, 0, max, range, range2);
	    	}
			
		}
    	
	}
}

package handmadevehicle2;







import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import gvclib.item.ItemWrench;
import handmadevehicle2.add.AddLanguageHMV2;
import handmadevehicle2.add.HMV2ModelRegistry;
import handmadevehicle2.add.HMVAddSounds2;
import handmadevehicle2.add.HMVAddVehicle2;
import handmadevehicle2.block.Block_VehicleCrafter2;
import handmadevehicle2.block.TileEntity_VehicleCrafter2;
import handmadevehicle2.entity.EntityHMV2_S;
import handmadevehicle2.entity.EntityHMV2_Vehicle;
import handmadevehicle2.event.HMVEvents_Ridding;
import handmadevehicle2.gui.GuiHandlerHMV2;
import handmadevehicle2.item.ItemSpawnHMV2;
import handmadevehicle2.network.HMVPacketHandler2;
import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLConstructionEvent;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;


import gvclib.item.ItemWrench;
import handmadevehicle2.add.AddLanguageHMV2;
import handmadevehicle2.add.HMV2ModelRegistry;
import handmadevehicle2.add.HMVAddSounds2;
import handmadevehicle2.add.HMVAddVehicle2;
import handmadevehicle2.block.Block_VehicleCrafter2;
import handmadevehicle2.block.TileEntity_VehicleCrafter2;
import handmadevehicle2.entity.EntityHMV2_S;
import handmadevehicle2.entity.EntityHMV2_Vehicle;
import handmadevehicle2.event.HMVEvents_Ridding;
import handmadevehicle2.gui.GuiHandlerHMV2;
import handmadevehicle2.item.ItemSpawnHMV2;
import handmadevehicle2.network.HMVPacketHandler2;
import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLConstructionEvent;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;




@Mod(
		modid	= mod_HandmadeVehicle2.MOD_ID,
		name	= mod_HandmadeVehicle2.MOD_ID,
		version	= "1.12.2", 
		acceptedMinecraftVersions="[1.12.2]", 
		useMetadata=true
		)
@EventBusSubscriber
public class mod_HandmadeVehicle2 {
	@SidedProxy(clientSide = "handmadevehicle2.ClientProxyHMV2", serverSide = "handmadevehicle2.CommonSideProxyHMV2")
	public static CommonSideProxyHMV2 proxy;
	public static final String MOD_ID = "handmadevehicle2";
	@Mod.Instance(MOD_ID)
	 
    public static mod_HandmadeVehicle2 INSTANCE;
	//public static final KeyBinding Speedreload = new KeyBinding("Key.reload", Keyboard.KEY_R, "GVCGunsPlus");
	
	public static boolean isDebugMessage = true;
	
	public static boolean cfg_exprotion;
	public static boolean cfg_canspawn;
	public static int cfg_probabilityl;
	public static int cfg_spawn_min;
	public static int cfg_spawn_max;
	
	public static boolean cfg_block_destroy;
	
	public static Item hmv2_icon;
	
	public static Item hmv2_wrench;
	public static Item hmv2_tank_s;
	
	
	public static Block hmv2_crafter;
	public static int gun_id = 0;
	public static int[] gun_eme = new int[1024];
	public static int[] gun_iron = new int[1024];
	public static int[] gun_red = new int[1024];
	public static Item[] gun_item = new Item[1024];
	
	public static int gun_model_id = 0;
	public static Item[] gun_model_item = new Item[1024];
	public static String[] gun_model_name = new String[1024];
	
	//public static Item[] guns;
	public static List guns = new ArrayList();
	
	public static int add_pack_id = 0;
	public static String[] add_pack_name = new String[1024];
	
	public static int add_gun_id = 0;
	public static String[] add_gun_name = new String[1024];
	
	public static int add_sound_id = 0;
	public static String[] add_sound_name = new String[1024];
	
	
	//protected static final File optionsDir = new File(Minecraft.getMinecraft().mcDataDir,"config" + File.separatorChar + "handmadeguns");
	

	
	protected static File configFile;
	
	public static final CreativeTabs tabhmv = new HMV2CreativeTab("HMV2Tab");
	
	public static int max_spawn;
	public static Item[] spawn_entity = new Item[256];

	@Mod.EventHandler
    public void construct(FMLConstructionEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
	}
	
	
	//@net.minecraftforge.fml.common.Mod.EventHandler
	@Mod.EventHandler
	public void preInit(FMLPreInitializationEvent pEvent) {
		configFile = pEvent.getSuggestedConfigurationFile();
		Configuration lconf = new Configuration(configFile);
		lconf.load();
		cfg_canspawn	= lconf.get("entity", "cfg_canspawn", true).getBoolean(true);
		cfg_probabilityl	= lconf.get("entity", "cfg_probabilityl", 20).getInt(20);
		cfg_spawn_min	= lconf.get("entity", "cfg_spawn_min", 10).getInt(10);
		cfg_spawn_max	= lconf.get("entity", "cfg_spawn_max", 20).getInt(20);
		
		cfg_block_destroy	= lconf.get("world", "cfg_block_destroy", false).getBoolean(false);
		lconf.save();
	   // ResourceLocation aa = new ResourceLocation("handmadeguns").getResourceDomain();
	    FMLCommonHandler.instance().bus().register(this);
		proxy.ProxyFile();
		
	    {
	    	//AddLanguageHMG2.load(pEvent.getSide().isClient(), MOD_ID, proxy.ProxyFile());
	    
	    HMVFileLoader2.load(this.INSTANCE);
	    	
	    }
	    HMVPacketHandler2.init();
	}
	
	
	@SubscribeEvent
	protected static void IregisterSoundEvents(RegistryEvent.Register<SoundEvent> event) {	
		HMVAddSounds2.load(event);
	}
	@SubscribeEvent
    protected static void registerItems(RegistryEvent.Register<Item> event){
		
		event.getRegistry().register(new ItemBlock(hmv2_crafter).setRegistryName(MOD_ID, "hmv2_crafter"));
		
		hmv2_wrench	= new ItemWrench().func_77655_b("hmv2_wrench").setRegistryName(MOD_ID, "hmv2_wrench")
				.func_77637_a(tabhmv);
		event.getRegistry().register(hmv2_wrench);
		
		hmv2_tank_s	= new ItemSpawnHMV2(1).func_77655_b("hmv2_tank_s").setRegistryName(MOD_ID, "hmv2_tank_s")
				.func_77637_a(tabhmv);
		event.getRegistry().register(hmv2_tank_s);
		
		{
			for(int i0 = 0; i0 < mod_HandmadeVehicle2.add_pack_id; ++i0) {
				for(int i1 = 0; i1 < mod_HandmadeVehicle2.add_gun_id; ++i1) {
					InputStream inputStream = HMVFileLoader2.class.getResourceAsStream("/assets/handmadevehicle2/addvehicle/" 
				+  mod_HandmadeVehicle2.add_pack_name[i0]
				+ "/vehicle/" + mod_HandmadeVehicle2.add_gun_name[i1]);
							if(inputStream != null) {
								HMVAddVehicle2.load(proxy.getClient(), inputStream, mod_HandmadeVehicle2.add_pack_name[i0], event);
							}
				}
			}
		}
		
		hmv2_icon	= new Item().func_77655_b("hmv2_icon")
				.setRegistryName(MOD_ID, "hmv2_icon");
		event.getRegistry().register(hmv2_icon);
		
		    

		    
		    AddLanguageHMV2.load(proxy.getClient(), MOD_ID, proxy.ProxyFile());
	}
	
	@SubscribeEvent
    protected static void registerBlocks(RegistryEvent.Register<Block> event){
		
		hmv2_crafter	= new Block_VehicleCrafter2(false).func_149663_c("hmv2_crafter")
				.setRegistryName(MOD_ID, "hmv2_crafter").func_149647_a(tabhmv);
		event.getRegistry().register(hmv2_crafter);
		
		GameRegistry.registerTileEntity(TileEntity_VehicleCrafter2.class, "TileEntity_VehicleCrafter2");
		
	}
	
	@SubscribeEvent
    @SideOnly(Side.CLIENT)
    public void registerModels(ModelRegistryEvent event) {
		HMV2ModelRegistry.registry(INSTANCE, event);
	}
	
	@EventHandler
	public void init(FMLInitializationEvent pEvent) {
		int D = Short.MAX_VALUE;

		EntityRegistry.registerModEntity(new ResourceLocation("EntityHMV2_Vehicle"),EntityHMV2_Vehicle.class, "EntityHMV2_Vehicle", 0, this, 128, 5, true);
		EntityRegistry.registerModEntity(new ResourceLocation("EntityHMV2_S"),EntityHMV2_S.class, "EntityHMV2_S", 1, this, 128, 5, true);
		
		NetworkRegistry.INSTANCE.registerGuiHandler(this.INSTANCE, new GuiHandlerHMV2());
		FMLCommonHandler.instance().bus().register(this);
		proxy.getClient();
		proxy.reisterRenderers();
		
		if (pEvent.getSide().isClient()) {
			 MinecraftForge.EVENT_BUS.register(new HMVEvents_Ridding());
		}
		
		GameRegistry.addShapedRecipe(new ResourceLocation("hmv2_crafter"),
                new ResourceLocation("handmadevehicle2"),
                new ItemStack(hmv2_crafter, 1), new Object[]{
                		"iri",
                		"rbr",
                		"iri",
    					'i', Blocks.field_150339_S,
    					'r', Blocks.field_150451_bX,
    					'b',Items.field_151166_bC
			 });
		
		
		Biome[] biomeList = null;
		biomeList = new Biome[Short.MAX_VALUE];
		for (int i=0; i<255; i++) biomeList[i] = Biome.field_185377_q.func_148754_a(i);
		for(Biome biome : biomeList)
		{
			if(biome!=null)
			{
				if(cfg_canspawn)
				{
					EntityRegistry.addSpawn(EntityHMV2_Vehicle.class, cfg_probabilityl, cfg_spawn_min, cfg_spawn_max, EnumCreatureType.MONSTER, biome);
				}
			}
		}
	}
	
}

	
	

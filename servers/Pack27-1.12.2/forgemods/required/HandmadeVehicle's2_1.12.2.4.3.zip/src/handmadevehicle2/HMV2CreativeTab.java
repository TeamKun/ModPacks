package handmadevehicle2;
 
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
 
public class HMV2CreativeTab extends CreativeTabs
{
	public HMV2CreativeTab(String label)
	{
		super(label);
	}
 
	@Override
	@SideOnly(Side.CLIENT)
	public ItemStack func_78016_d()
	{
		return new ItemStack(mod_HandmadeVehicle2.hmv2_icon);
	}
 
	@Override
	@SideOnly(Side.CLIENT)
	public String func_78024_c()
	{
		return "HandmadeVehicle2";
	}
 
}

package handmadevehicle2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;

public class HMVFileLoader2 {

	public static void load(mod_HandmadeVehicle2 mod) {

		{
			File directory_sounds = new File(mod.proxy.ProxyFile(),
					"mods" + File.separatorChar + "handmadevehicle2"
							+ File.separatorChar + "assets" + File.separatorChar
							+ "handmadevehicle2" + File.separatorChar +
							"sounds");
			
			directory_sounds.mkdirs();
			System.out.println(String.format("aaaaaaaaaaaaaaaaaaaaa"));
		}

		try {
			InputStream inputStream = HMVFileLoader2.class.getResourceAsStream("/assets/handmadevehicle2/addvehicle/addpack.txt");
			//if (checkBeforeReadfile(file)) 
			{
				BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));

				String str;
				while ((str = br.readLine()) != null) { // 1行ずつ読み込む
					// System.out.println(str);
					String[] type = str.split(",");

					int guntype = 0;

					if (type.length != 0) {// 1
						if (type[0].equals("pack")) {
							mod_HandmadeVehicle2.add_pack_name[mod_HandmadeVehicle2.add_pack_id] = type[1];
							++mod_HandmadeVehicle2.add_pack_id;
							System.out.println(String.format("bbbbbbbbbbbbbbbbbbbbbbbbbbbb"));
						}
						
					}
				}
				br.close(); // ファイルを閉じる
			}
			} catch (FileNotFoundException ex) {
				ex.printStackTrace();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		{
			for(int i0 = 0; i0 < mod_HandmadeVehicle2.add_pack_id; ++i0) {
				try {
					InputStream inputStream = HMVFileLoader2.class.getResourceAsStream("/assets/handmadevehicle2/addvehicle/" 
				+ mod_HandmadeVehicle2.add_pack_name[i0] +"/addlist.txt");
					{
						BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));

						String str;
						while ((str = br.readLine()) != null) { // 1行ずつ読み込む
							String[] type = str.split(",");

							int guntype = 0;

							if (type.length != 0) {// 1
								if (type[0].equals("sound")) {
									mod_HandmadeVehicle2.add_sound_name[mod_HandmadeVehicle2.add_sound_id] = type[1];
									++mod_HandmadeVehicle2.add_sound_id;
									System.out.println(String.format("bbbbbbbbbbbbbbbbbbbbbbbbbbbb"));
								}
								
								if (type[0].equals("vehicle")) {
									mod_HandmadeVehicle2.add_gun_name[mod_HandmadeVehicle2.add_gun_id] = type[1];
									++mod_HandmadeVehicle2.add_gun_id;
								}
							}
						}
						br.close(); // ファイルを閉じる
					}
					} catch (FileNotFoundException ex) {
						ex.printStackTrace();
					} catch (IOException ex) {
						ex.printStackTrace();
					}
			}
		}
		
		{
			for(int i0 = 0; i0 < mod_HandmadeVehicle2.add_pack_id; ++i0) {
				for(int i1 = 0; i1 < mod_HandmadeVehicle2.add_sound_id; ++i1) {
					InputStream inputStream = HMVFileLoader2.class.getResourceAsStream("/assets/handmadevehicle2/addvehicle/" 
				+  mod_HandmadeVehicle2.add_pack_name[i0]
				+ "/addsounds/" + mod_HandmadeVehicle2.add_sound_name[i1]);
							if(inputStream != null) {
								File directory1 = new File(mod.proxy.ProxyFile(),
										"mods" + File.separatorChar + "handmadevehicle2"
												+ File.separatorChar + "assets" + File.separatorChar
												+ "handmadevehicle2" + File.separatorChar +
												"sounds/"+ mod_HandmadeVehicle2.add_sound_name[i1]);
								try {
								    Files.copy(inputStream, directory1.toPath());
								} catch (IOException eeee) {
								    eeee.printStackTrace();
								}
							}
				}
			}
		}

		
		

	}
}

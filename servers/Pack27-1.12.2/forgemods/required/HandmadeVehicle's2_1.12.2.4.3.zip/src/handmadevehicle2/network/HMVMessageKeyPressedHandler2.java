package handmadevehicle2.network;


import handmadevehicle2.mod_HandmadeVehicle2;
import handmadevehicle2.block.TileEntity_VehicleCrafter2;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
 
public class HMVMessageKeyPressedHandler2 implements IMessageHandler<HMVMessageKeyPressed2, IMessage> {
 
    @Override
    public IMessage onMessage(HMVMessageKeyPressed2 message, MessageContext ctx) {
        EntityPlayer entityPlayer = ctx.getServerHandler().field_147369_b;
        if (message.key == 1) {
        	BlockPos pos = new BlockPos(message.posx, message.posy, message.posz);
        	if(pos != null && entityPlayer.field_70170_p.func_175625_s(pos) instanceof TileEntity_VehicleCrafter2) {
        		TileEntity_VehicleCrafter2 tile  = (TileEntity_VehicleCrafter2) entityPlayer.field_70170_p.func_175625_s(pos);
        		 if(tile.sell_id < (mod_HandmadeVehicle2.gun_id - 1)) {
        			 ++tile.sell_id;
        		 }else {
        			 tile.sell_id = 0;
        		 }
        	}
		}
        if (message.key == 2) {
        	BlockPos pos = new BlockPos(message.posx, message.posy, message.posz);
        	if(pos != null && entityPlayer.field_70170_p.func_175625_s(pos) instanceof TileEntity_VehicleCrafter2) {
        		TileEntity_VehicleCrafter2 tile  = (TileEntity_VehicleCrafter2) entityPlayer.field_70170_p.func_175625_s(pos);
				if (tile.sell_id > 0) {
					--tile.sell_id;
				} else {
					tile.sell_id = (mod_HandmadeVehicle2.gun_id - 1);
				}
        	}
		}
        return null;
    }
}

package handmadevehicle2.network;


import handmadeguns2.mod_HandmadeGuns2;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
 
public class HMVMessageKeyPressedHandler2_Client implements IMessageHandler<HMVMessageKeyPressed2_Client, IMessage> {
 
    @Override
    public IMessage onMessage(HMVMessageKeyPressed2_Client message, MessageContext ctx) {
        EntityPlayer entityPlayer = mod_HandmadeGuns2.proxy.getEntityPlayerInstance();
        
        return null;
    }
}

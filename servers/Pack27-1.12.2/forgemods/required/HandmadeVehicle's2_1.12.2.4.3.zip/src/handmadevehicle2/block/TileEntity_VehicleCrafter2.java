package handmadevehicle2.block;

import handmadevehicle2.mod_HandmadeVehicle2;
import handmadevehicle2.gui.BlockContainerInventory_VehicleCrafter2;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntityLockable;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackDataLists;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class TileEntity_VehicleCrafter2 extends TileEntityLockable implements ITickable, ISidedInventory
{
    private static final int[] SLOTS_TOP = new int[] {0};
    private static final int[] SLOTS_BOTTOM = new int[] {2, 1};
    private static final int[] SLOTS_SIDES = new int[] {1};
    /** The ItemStacks that hold the items currently being used in the furnace */
    public NonNullList<ItemStack> furnaceItemStacks = NonNullList.<ItemStack>func_191197_a(8, ItemStack.field_190927_a);
    /** The number of ticks that the furnace will keep burning */
    private int furnaceBurnTime;
    /** The number of ticks that a fresh copy of the currently-burning item would keep the furnace burning for */
    private int currentItemBurnTime;
    private int cookTime;
    private int totalCookTime;
    private String furnaceCustomName;
    
    public static boolean cancraft;
    public static int crafttime;

    /**
     * Returns the number of slots in the inventory.
     */
    public int func_70302_i_()
    {
        return this.furnaceItemStacks.size();
    }

    public boolean func_191420_l()
    {
        for (ItemStack itemstack : this.furnaceItemStacks)
        {
            if (!itemstack.func_190926_b())
            {
                return false;
            }
        }

        return true;
    }

    /**
     * Returns the stack in the given slot.
     */
    public ItemStack func_70301_a(int index)
    {
        return this.furnaceItemStacks.get(index);
    }

    /**
     * Removes up to a specified number of items from an inventory slot and returns them in a new stack.
     */
    public ItemStack func_70298_a(int index, int count)
    {
        return ItemStackHelper.func_188382_a(this.furnaceItemStacks, index, count);
    }

    /**
     * Removes a stack from the given slot and returns it.
     */
    public ItemStack func_70304_b(int index)
    {
        return ItemStackHelper.func_188383_a(this.furnaceItemStacks, index);
    }

    /**
     * Sets the given item stack to the specified slot in the inventory (can be crafting or armor sections).
     */
    public void func_70299_a(int index, ItemStack stack)
    {
        ItemStack itemstack = this.furnaceItemStacks.get(index);
        boolean flag = !stack.func_190926_b() && stack.func_77969_a(itemstack) && ItemStack.func_77970_a(stack, itemstack);
        this.furnaceItemStacks.set(index, stack);

        if (stack.func_190916_E() > this.func_70297_j_())
        {
            stack.func_190920_e(this.func_70297_j_());
        }

        if (index == 0 && !flag)
        {
            this.totalCookTime = this.getCookTime(stack);
            this.cookTime = 0;
            this.func_70296_d();
        }
    }

    /**
     * Get the name of this object. For players this returns their username
     */
    public String func_70005_c_()
    {
        //return this.hasCustomName() ? this.furnaceCustomName : "container.furnace";
    	return this.func_145818_k_() ? this.furnaceCustomName : "Crafting Machine";
    }

    /**
     * Returns true if this thing is named
     */
    public boolean func_145818_k_()
    {
        return this.furnaceCustomName != null && !this.furnaceCustomName.isEmpty();
    }

    public void setCustomInventoryName(String p_145951_1_)
    {
        this.furnaceCustomName = p_145951_1_;
    }

    public static void registerFixesFurnace(DataFixer fixer)
    {
        fixer.func_188258_a(FixTypes.BLOCK_ENTITY, new ItemStackDataLists(TileEntity_VehicleCrafter2.class, new String[] {"Items"}));
    }

    public void func_145839_a(NBTTagCompound compound)
    {
        super.func_145839_a(compound);
        this.furnaceItemStacks = NonNullList.<ItemStack>func_191197_a(this.func_70302_i_(), ItemStack.field_190927_a);
        ItemStackHelper.func_191283_b(compound, this.furnaceItemStacks);
        this.furnaceBurnTime = compound.func_74762_e("BurnTime");
        this.cookTime = compound.func_74762_e("CookTime");
        this.totalCookTime = compound.func_74762_e("CookTimeTotal");
       // this.currentItemBurnTime = getItemBurnTime(this.furnaceItemStacks.get(1));

        this.cancraft = compound.func_74767_n("cancraft");
        this.crafttime = compound.func_74762_e("crafttime");
        
        if (compound.func_150297_b("CustomName", 8))
        {
            this.furnaceCustomName = compound.func_74779_i("CustomName");
        }
    }

    public NBTTagCompound func_189515_b(NBTTagCompound compound)
    {
        super.func_189515_b(compound);
        //compound.setInteger("BurnTime", (short)this.furnaceBurnTime);
        compound.func_74768_a("CookTime", (short)this.cookTime);
        compound.func_74768_a("CookTimeTotal", (short)this.totalCookTime);
        ItemStackHelper.func_191282_a(compound, this.furnaceItemStacks);

        compound.func_74757_a("cancraft", this.cancraft);
        compound.func_74768_a("crafttime", this.crafttime);
        
        if (this.func_145818_k_())
        {
            compound.func_74778_a("CustomName", this.furnaceCustomName);
        }

        return compound;
    }

    /**
     * Returns the maximum stack size for a inventory slot. Seems to always be 64, possibly will be extended.
     */
    public int func_70297_j_()
    {
        return 64;
    }

    /**
     * Furnace isBurning
     */
    public boolean isBurning()
    {
        return this.furnaceBurnTime > 0;
    }

    @SideOnly(Side.CLIENT)
    public static boolean isBurning(IInventory inventory)
    {
        return inventory.func_174887_a_(0) > 0;
    }

    /**
     * Like the old updateEntity(), except more generic.
     */
    
    public int sell_id = 0;
    public boolean cansell = false;
    
    public void func_73660_a()
    {
    	{
    		ItemStack eme = (ItemStack)this.furnaceItemStacks.get(0);
            ItemStack iron = (ItemStack)this.furnaceItemStacks.get(1);
            ItemStack red = (ItemStack)this.furnaceItemStacks.get(2);
            ItemStack output = (ItemStack)this.furnaceItemStacks.get(3);
            
            /*for(int id = 0; id < mod_HandmadeGuns.gun_id; ++id) {
            	
            }*/
            if(mod_HandmadeVehicle2.gun_item[sell_id] != null) {
            	if(!eme.func_190926_b() && eme.func_77973_b() == Items.field_151166_bC
            			&& !iron.func_190926_b() && iron.func_77973_b() == Items.field_151042_j
            			&& !red.func_190926_b() && red.func_77973_b() == Items.field_151137_ax) {
            		if(eme.func_190916_E() >= mod_HandmadeVehicle2.gun_eme[sell_id]
            				&& iron.func_190916_E() >= mod_HandmadeVehicle2.gun_iron[sell_id]
            						&&red.func_190916_E() >= mod_HandmadeVehicle2.gun_red[sell_id]) {
            			if(this.furnaceItemStacks.get(3).func_190926_b() && cansell) {
            				eme.func_190918_g(mod_HandmadeVehicle2.gun_eme[sell_id]);
            				iron.func_190918_g(mod_HandmadeVehicle2.gun_iron[sell_id]);
            				red.func_190918_g(mod_HandmadeVehicle2.gun_red[sell_id]);
            				cansell = false;
            			}else {
            				this.furnaceItemStacks.set(3, new ItemStack(mod_HandmadeVehicle2.gun_item[sell_id], 1));
            				cansell = true;
            			}
            		}else {
            			this.furnaceItemStacks.set(3, output.field_190927_a);
            		}
            	}else {
            		this.furnaceItemStacks.set(3, output.field_190927_a);
            		cansell = false;
            	}
            }
            /*if(cansell) {
            	this.furnaceItemStacks.set(3, output.EMPTY);
            }*/
            
            int ct = 1;
            
    	}
    }

    
    
    public int getCookTime(ItemStack stack)
    {
        return 200;
    }

    

    /**
     * Don't rename this method to canInteractWith due to conflicts with Container
     */
    public boolean func_70300_a(EntityPlayer player)
    {
        if (this.field_145850_b.func_175625_s(this.field_174879_c) != this)
        {
            return false;
        }
        else
        {
            return player.func_70092_e((double)this.field_174879_c.func_177958_n() + 0.5D, (double)this.field_174879_c.func_177956_o() + 0.5D, (double)this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D;
        }
    }

    public void func_174889_b(EntityPlayer player)
    {
    }

    public void func_174886_c(EntityPlayer player)
    {
    }

    /**
     * Returns true if automation is allowed to insert the given stack (ignoring stack size) into the given slot. For
     * guis use Slot.isItemValid
     */
    public boolean func_94041_b(int index, ItemStack stack)
    {
        if (index == 2)
        {
            return false;
        }
        else if (index != 1)
        {
            return true;
        }
        else
        {
            ItemStack itemstack = this.furnaceItemStacks.get(1);
            //return isItemFuel(stack) || SlotFurnaceFuel.isBucket(stack) && itemstack.getItem() != Items.BUCKET;
            return false;
        }
    }

    public int[] func_180463_a(EnumFacing side)
    {
        if (side == EnumFacing.DOWN)
        {
            return SLOTS_BOTTOM;
        }
        else
        {
            return side == EnumFacing.UP ? SLOTS_TOP : SLOTS_SIDES;
        }
    }

    /**
     * Returns true if automation can insert the given item in the given slot from the given side.
     */
    public boolean func_180462_a(int index, ItemStack itemStackIn, EnumFacing direction)
    {
        return this.func_94041_b(index, itemStackIn);
    }

    /**
     * Returns true if automation can extract the given item in the given slot from the given side.
     */
    public boolean func_180461_b(int index, ItemStack stack, EnumFacing direction)
    {
        if (direction == EnumFacing.DOWN && index == 1)
        {
            Item item = stack.func_77973_b();

            if (item != Items.field_151131_as && item != Items.field_151133_ar)
            {
                return false;
            }
        }

        return true;
    }

    public String func_174875_k()
    {
        return "minecraft:furnace";
    }

    public Container func_174876_a(InventoryPlayer playerInventory, EntityPlayer playerIn)
    {
        return new BlockContainerInventory_VehicleCrafter2(playerInventory, this);
    }

    public int func_174887_a_(int id)
    {
        switch (id)
        {
            case 0:
                return this.furnaceBurnTime;
            case 1:
                return this.currentItemBurnTime;
            case 2:
                return this.cookTime;
            case 3:
                return this.totalCookTime;
            default:
                return 0;
        }
    }

    public void func_174885_b(int id, int value)
    {
        switch (id)
        {
            case 0:
                this.furnaceBurnTime = value;
                break;
            case 1:
                this.currentItemBurnTime = value;
                break;
            case 2:
                this.cookTime = value;
                break;
            case 3:
                this.totalCookTime = value;
        }
    }

    public int func_174890_g()
    {
        return 4;
    }

    public void func_174888_l()
    {
        this.furnaceItemStacks.clear();
    }
}

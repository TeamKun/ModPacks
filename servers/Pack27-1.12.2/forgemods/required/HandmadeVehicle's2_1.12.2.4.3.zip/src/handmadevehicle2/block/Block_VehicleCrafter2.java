package handmadevehicle2.block;

import java.util.Random;
import handmadevehicle2.mod_HandmadeVehicle2;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;


import handmadevehicle2.mod_HandmadeVehicle2;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class Block_VehicleCrafter2 extends BlockContainer
{
    //public static final PropertyDirection FACING = BlockHorizontal.FACING;
    //private final boolean isBurning;
    private static boolean keepInventory;

    public Block_VehicleCrafter2(boolean isBurning)
    {
    	 super(Material.field_151573_f);
         this.func_149711_c(5F);
         this.func_149752_b(10.0F);
         this.func_149672_a(SoundType.field_185852_e);
        //this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
       // this.isBurning = isBurning;
    }

    /**
     * Get the Item that this Block should drop when harvested.
     */
    public Item func_180660_a(IBlockState state, Random rand, int fortune)
    {
        return Item.func_150898_a(mod_HandmadeVehicle2.hmv2_crafter);
    }

    /**
     * Called when the block is right clicked by a player.
     */
    public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ)
    {
        if (worldIn.field_72995_K)
        {
            return true;
        }
        else
        {
            TileEntity tileentity = worldIn.func_175625_s(pos);

            if (tileentity instanceof TileEntity_VehicleCrafter2)
            {
                //playerIn.displayGUIChest((TileEntityFurnace)tileentity);
            	//playerIn.openGui(mod_GirlFront.INSTANCE, 2,
        		//		playerIn.world, (int) playerIn.posX, (int) playerIn.posY, (int) playerIn.posZ);
            	int x = pos.func_177958_n();
            	int y = pos.func_177956_o();
            	int z = pos.func_177952_p();
                playerIn.openGui(mod_HandmadeVehicle2.INSTANCE, 0, playerIn.field_70170_p, x, y, z);
                //playerIn.addStat(StatList.FURNACE_INTERACTION);
            }

            return true;
        }
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity func_149915_a(World worldIn, int meta)
    {
        return new TileEntity_VehicleCrafter2();
    }

    /**
     * Called by ItemBlocks after a block is set in the world, to allow post-place logic
     */
    public void func_180633_a(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack)
    {
       // worldIn.setBlockState(pos, state.withProperty(FACING, placer.getHorizontalFacing().getOpposite()), 2);

        if (stack.func_82837_s())
        {
            TileEntity tileentity = worldIn.func_175625_s(pos);

            if (tileentity instanceof TileEntity_VehicleCrafter2)
            {
                ((TileEntity_VehicleCrafter2)tileentity).setCustomInventoryName(stack.func_82833_r());
            }
        }
    }

    /**
     * Called serverside after this block is replaced with another in Chunk, but before the Tile Entity is updated
     */
    public void func_180663_b(World worldIn, BlockPos pos, IBlockState state)
    {
        if (!keepInventory)
        {
            TileEntity tileentity = worldIn.func_175625_s(pos);

            if (tileentity instanceof TileEntity_VehicleCrafter2)
            {
                InventoryHelper.func_180175_a(worldIn, pos, (TileEntity_VehicleCrafter2)tileentity);
                worldIn.func_175666_e(pos, this);
            }
        }

        super.func_180663_b(worldIn, pos, state);
    }

    public boolean func_149740_M(IBlockState state)
    {
        return true;
    }

    public int func_180641_l(IBlockState blockState, World worldIn, BlockPos pos)
    {
        return Container.func_178144_a(worldIn.func_175625_s(pos));
    }

    public ItemStack func_185473_a(World worldIn, BlockPos pos, IBlockState state)
    {
        return new ItemStack(mod_HandmadeVehicle2.hmv2_crafter);
    }

    /**
     * The type of render function called. MODEL for mixed tesr and static model, MODELBLOCK_ANIMATED for TESR-only,
     * LIQUID for vanilla liquids, INVISIBLE to skip all rendering
     */
    public EnumBlockRenderType func_149645_b(IBlockState state)
    {
        return EnumBlockRenderType.MODEL;
    }
}

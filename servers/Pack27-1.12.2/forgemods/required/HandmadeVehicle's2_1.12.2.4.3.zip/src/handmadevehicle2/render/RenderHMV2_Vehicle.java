package handmadevehicle2.render;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import gvclib.mod_GVCLib;
import gvclib.render.RenderBomber_Target;
import gvclib.render.RenderCanMobRidding;
import gvclib.render.RenderExhaust;
import gvclib.render.RenderLaserSight;
import gvclib.render.RenderSPG_Target;
import handmadevehicle2.entity.EntityHMV2_Vehicle;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;


import gvclib.mod_GVCLib;
import gvclib.render.RenderBomber_Target;
import gvclib.render.RenderCanMobRidding;
import gvclib.render.RenderExhaust;
import gvclib.render.RenderLaserSight;
import gvclib.render.RenderSPG_Target;
import handmadevehicle2.entity.EntityHMV2_Vehicle;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderHMV2_Vehicle extends Render<EntityHMV2_Vehicle>
{
    //private static final ResourceLocation boatTextures = new ResourceLocation("mcdungeons:textures/model/tank/tank_l_1.png");
   // private static final IModelCustom tankk= AdvancedModelLoader.loadModel(new ResourceLocation("mcdungeons:textures/model/tank/tank_l_1.mqo"));
    
    //private static final ResourceLocation crawler = new ResourceLocation("mcdungeons:textures/model/tank/_crawler.png");
    /** instance of ModelBoat for rendering */

    public RenderHMV2_Vehicle(RenderManager renderManagerIn)
    {
        super(renderManagerIn);
        this.field_76989_e = 0.5F;
    }

    /**
     * Actually renders the given argument. This is a synthetic bridge method, always casting down its argument and then
     * handing it off to a worker function which does the actual work. In all probabilty, the class Render is generic
     * (Render<T extends Entity>) and this method has signature public void func_76986_a(T entity, double d, double d1,
     * double d2, float f, float f1). But JAD is pre 1.5 so doe
     */
    float iii;
    /*
    float arm_x = 0F;
    float arm_y = 2.0F;
    float arm_z = 0F;
    
    float hand_x = 0F;
    float hand_y = 2.0F;
    float hand_z = 0.6F;
    */
    public void func_76986_a(EntityHMV2_Vehicle entity, double x, double y, double z, float entityYaw, float partialTicks)
    {
        this.func_180548_c(entity);
       /* if(entity.model == null && entity.getModel() != null){
        	boolean mo = false;
        	{
        		entity.model = AdvancedModelLoader
						.loadModel(new ResourceLocation(entity.getModel()));
        	}
			
		}*/
        
        this.field_76989_e = entity.field_70130_N;
        
        if(entity.model != null)
        {

    		GL11.glPushMatrix();//glstart
    		GL11.glTranslatef((float) x, (float) y, (float) z);
    		
    		
    		boolean flag1 = false;
            if ((Minecraft.func_71410_x()).field_71474_y.field_74320_O != 0
                    || (Minecraft.func_71410_x()).field_71439_g.func_184187_bx() != entity) {
                double maxX = (entity.func_174813_aQ()).field_72336_d;
                double minX = (entity.func_174813_aQ()).field_72340_a;
                double maxZ = (entity.func_174813_aQ()).field_72334_f;
                double minZ = (entity.func_174813_aQ()).field_72339_c;
                if (entity.field_70170_p.func_175623_d((new BlockPos(minX, entity.field_70163_u, minZ)).func_177977_b()) 
                		//&& entity.world.getBlockState((new BlockPos(minX, entity.posY, minZ)).down()).getCollisionBoundingBox(entity.world, (new BlockPos(minX, entity.posY, minZ)).down()) != Block.NULL_AABB
                		) {
                    flag1 = true;
                    GlStateManager.func_179114_b(20.0F, -1.0F, 0.0F, 1.0F);
                }
                if (entity.field_70170_p.func_175623_d((new BlockPos(maxX, entity.field_70163_u, minZ)).func_177977_b())
                		//&& entity.world.getBlockState((new BlockPos(maxX, entity.posY, minZ)).down()).getCollisionBoundingBox(entity.world, (new BlockPos(maxX, entity.posY, minZ)).down()) != Block.NULL_AABB
                		) {
                    flag1 = true;
                    GlStateManager.func_179114_b(20.0F, -1.0F, 0.0F, -1.0F);
                }
                if (entity.field_70170_p.func_175623_d((new BlockPos(maxX, entity.field_70163_u, maxZ)).func_177977_b())
                		//&& entity.world.getBlockState((new BlockPos(maxX, entity.posY, maxZ)).down()).getCollisionBoundingBox(entity.world, (new BlockPos(maxX, entity.posY, maxZ)).down()) != Block.NULL_AABB
                		) {
                    flag1 = true;
                    GlStateManager.func_179114_b(20.0F, 1.0F, 0.0F, -1.0F);
                }
                if (entity.field_70170_p.func_175623_d((new BlockPos(minX, entity.field_70163_u, maxZ)).func_177977_b())
                		//&& entity.world.getBlockState((new BlockPos(minX, entity.posY, maxZ)).down()).getCollisionBoundingBox(entity.world, (new BlockPos(minX, entity.posY, maxZ)).down()) != Block.NULL_AABB
                		) {
                    flag1 = true;
                    GlStateManager.func_179114_b(20.0F, 1.0F, 0.0F, 1.0F);
                }
            }
    		
            GL11.glRotatef(180F, 0.0F, 1.0F, 0.0F);
    		GL11.glEnable(GL12.GL_RESCALE_NORMAL);
    		{
    			RenderCanMobRidding.can(entity);
    			Minecraft.func_71410_x().field_71446_o.func_110577_a(entity.tex);
    		}
    		
    		if(entity.func_184179_bs() != null && entity.func_184179_bs() == Minecraft.func_71410_x().field_71439_g && entity.bomber_sighting){
    			float offset = -500 * entity.sp + 20;
    			RenderBomber_Target.can(entity, offset);
    			Minecraft.func_71410_x().field_71446_o.func_110577_a(entity.tex);
    		}
    		
    		if(entity.deathTicks > 0){
    			GL11.glColor4f(0.1F, 0.1F, 0.1F, 1F);
    		}else{
    			GL11.glColor4f(1F, 1F, 1F, 1F);
    		}
    		
    		if(entity.spg_mode && (entity.vehicletype == 3 || entity.spg_sighting))
    		{
    			RenderSPG_Target.can(entity, entity.spg_yaw, (float)(entity.spg_y - entity.field_70163_u), entity.spg_picth);
    			if (entity.func_184179_bs() == null) {
    				Minecraft.func_71410_x().field_71446_o.func_110577_a(entity.tex);
    		   	}else
    		   	{
    		   		Minecraft.func_71410_x().field_71446_o.func_110577_a(entity.tex);
    		   	}
    		}
    		/*if ((entity.canBeSteered() && entity.getControllingPassenger() != null) || (entity.getMobMode() == 0) && entity.getHealth() > 0.0F)
    		{
    			GL11.glRotatef(180.0F - entity.rotation, 0.0F, 1.0F, 0.0F);
    			if(entity.cooltime > 0 && entity.cooltime < 4){
    				GL11.glRotatef(-entity.cooltime * 2, 1.0F, 0.0F, 0.0F);
    			}
    			if(entity.cooltime >= 4 && entity.cooltime < 8){
    				GL11.glRotatef(-6, 1.0F, 0.0F, 0.0F);
    				GL11.glRotatef(entity.cooltime, 1.0F, 0.0F, 0.0F);
    			}
    			GL11.glRotatef(-(180.0F - entity.rotation), 0.0F, 1.0F, 0.0F);
    		}*/
    		GL11.glRotatef(180.0F - entityYaw, 0.0F, 1.0F, 0.0F);
    		
    		
    		//start (2/2)
            if ((Minecraft.func_71410_x()).field_71474_y.field_74320_O != 0
                    || (Minecraft.func_71410_x()).field_71439_g.func_184187_bx() != entity) {
                if (flag1)
                    GlStateManager.func_179109_b(0.0F, -0.4F, 0.0F);
                for (Entity passenger : entity.func_184188_bt()) {
                    if (passenger instanceof net.minecraft.entity.EntityLivingBase) {
                        mod_GVCLib.dontjumpRedner = true;
                        GlStateManager.func_179094_E();
                        GlStateManager.func_179114_b(entityYaw, 0.0F, 1.0F, 0.0F);
                        Minecraft.func_71410_x().func_175598_ae().func_78713_a(passenger).func_76986_a(passenger,
                                passenger.field_70165_t - entity.field_70165_t, passenger.field_70163_u - entity.field_70163_u,
                                passenger.field_70161_v - entity.field_70161_v, 0.0F, partialTicks);
                        GlStateManager.func_179121_F();
                    }
                }
                (Minecraft.func_71410_x()).field_71446_o.func_110577_a(entity.tex);
            }
            //end (2/2)
    		
    		
    		boolean flag = false;
    		if(entity.func_184179_bs() != null && entity.func_184179_bs() == Minecraft.func_71410_x().field_71439_g){
    			boolean right = mod_GVCLib.proxy.rightclick();// 1
    			if(Minecraft.func_71410_x().field_71474_y.field_74320_O == 0 && right  && entity.bomber_sighting){
    				flag = true;
    			}
    			if(Minecraft.func_71410_x().field_71474_y.field_74320_O == 0 && right  && entity.vehicletype == 2 && entity.getFTMode() == 1){
    				flag = true;
    			}
    		}
    		
    		if(!flag) {
    		
    			//entity.model.renderPart("mat1");
    		if(entity.vehicletype == 1 || entity.vehicletype == 2) {
    			GL11.glTranslatef(0, (float)(entity.riddingy[0] + 1.25F), 0F);
    			//GL11.glTranslatef((float)entity.riddingx[0], (float)(entity.riddingy[0] + 1.25F), (float)entity.riddingz[0]);
    			//GL11.glTranslatef(0, ((float)entity.riddingy[0] + 0), 0);
    			//GL11.glTranslatef(entity.model_angle_base_x, entity.model_angle_base_y, entity.model_angle_base_z);
    			if(entity.field_70122_E){
    				//GL11.glRotatef(-7, 1.0F, 0.0F, 0.0F);
    			}else {
    				GL11.glRotatef(entity.field_70125_A, 1.0F, 0.0F, 0.0F);
    				GL11.glRotatef(entity.throte, 0.0F, 0.0F, 1.0F);
    			}
    			//GL11.glTranslatef(-entity.model_angle_base_x, -entity.model_angle_base_y, -entity.model_angle_base_z);
    			//GL11.glTranslatef(-(float)entity.riddingx[0], -(float)(entity.riddingy[0] + 1.25F), -(float)entity.riddingz[0]);
    			GL11.glTranslatef(0, -(float)(entity.riddingy[0] + 1.25F), 0F);
    		}
    		if(entity.field_70122_E){
    			GL11.glTranslatef(entity.model_angle_base_x, entity.model_angle_base_y, entity.model_angle_base_z);
    			GL11.glRotatef(entity.model_angle_x, 1.0F, 0.0F, 0.0F);
    			GL11.glRotatef(entity.model_angle_y, 0.0F, 1.0F, 0.0F);
    			GL11.glRotatef(entity.model_angle_z, 0.0F, 0.0F, 1.0F);
    			GL11.glTranslatef(-entity.model_angle_base_x, -entity.model_angle_base_y, -entity.model_angle_base_z);
    			GL11.glTranslatef(entity.model_angle_offset_x, entity.model_angle_offset_y, entity.model_angle_offset_z);
    			
    			entity.model.renderPart("gear");
    		}
    		entity.model.renderPart("mat1");
    		entity.model.renderPart("mat2");
    		entity.model.renderPart("seat");
    		Minecraft minecraft = Minecraft.func_71410_x();
    		/*{
    			GL11.glPushMatrix();//glstart
        		{
        			minecraft.getTextureManager().bindTexture(crawler);
        		}
        		entity.model.renderPart("crawler_r");
        		//GL11.glDisable(GL11.GL_TEXTURE_2D);
        		GL11.glPopMatrix();//glend
        		GL11.glPushMatrix();//glstart 
        		{
        			minecraft.getTextureManager().bindTexture(crawler);
        		}
        		entity.model.renderPart("crawler_l");
        		GL11.glPopMatrix();//glend
    		}*/
    		for(int t2 = 0; t2 < entity.rader; ++t2){
    			if(entity.raderturret[t2] == 0) {
    				GL11.glPushMatrix();//glstart
        			String tu2 = String.valueOf(t2 + 1);
    				GL11.glTranslatef(entity.rader_x[t2], entity.rader_y[t2], entity.rader_z[t2]);//0,1,2.5
    				GL11.glRotatef((float)mod_GVCLib.proxy.getCilentWorld().func_72820_D()  * 1F, entity.raderrote_x[t2], entity.raderrote_y[t2], entity.raderrote_z[t2]);
    				GL11.glTranslatef(-entity.rader_x[t2], -entity.rader_y[t2], -entity.rader_z[t2]);
    				entity.model.renderPart("rader_" + tu2);
    				GL11.glPopMatrix();//glend
    			}
			}
    		for(int t1 = 0; t1 < entity.pera; ++t1){
    			GL11.glPushMatrix();//glstart
    			String tu1 = String.valueOf(t1 + 1);
				GL11.glTranslatef(entity.pera_x[t1], entity.pera_y[t1], entity.pera_z[t1]);//0,1,2.5
				GL11.glRotatef((float) entity.thpera, entity.perarote_x[t1], entity.perarote_y[t1], entity.perarote_z[t1]);
				GL11.glTranslatef(-entity.pera_x[t1], -entity.pera_y[t1], -entity.pera_z[t1]);
				entity.model.renderPart("pera_" + tu1);
				entity.model.renderPart("wheel_" + tu1);
				GL11.glPopMatrix();//glend
			}
    		
    		for(int t1 = 0; t1 < entity.exhaust; ++t1){
				RenderExhaust.can(entity, entity.exhaust_x[t1], entity.exhaust_y[t1], entity.exhaust_z[t1], 1.0F, entity.exhaust_ab, entity.tex);
			}
    		
    		if(entity.getBoost()) {
    			for(int t1 = 0; t1 < entity.laser_sight; ++t1){
        			if(!entity.rote_laser_sight[t1]) {
        				if(entity.func_184179_bs() != null && entity.func_184179_bs() == Minecraft.func_71410_x().field_71439_g){
        					if(entity.laser_sight_weapon[t1] == 0) {
        						if(entity.getRemain_L() > 0)RenderLaserSight.can(entity, entity.laser_sight_x[t1], entity.laser_sight_y[t1], entity.laser_sight_z[t1], 1.0F, entity.tex);
        					}
        					else if(entity.laser_sight_weapon[t1] == 1) {
        						if(entity.getRemain_R() > 0)RenderLaserSight.can(entity, entity.laser_sight_x[t1], entity.laser_sight_y[t1], entity.laser_sight_z[t1], 1.0F, entity.tex);
        					}
        					else if(entity.laser_sight_weapon[t1] == 2) {
        						if(entity.getRemain_A() > 0)RenderLaserSight.can(entity, entity.laser_sight_x[t1], entity.laser_sight_y[t1], entity.laser_sight_z[t1], 1.0F, entity.tex);
        					}
        					else if(entity.laser_sight_weapon[t1] == 3) {
        						if(entity.getRemain_S() > 0)RenderLaserSight.can(entity, entity.laser_sight_x[t1], entity.laser_sight_y[t1], entity.laser_sight_z[t1], 1.0F, entity.tex);
        					}
            			}
        			}
        		}
    		}
    		
    		
    		
    		this.func_180548_c(entity);
    		{
    			for(int t1 = 0; t1 < entity.turret; ++t1) {
    				GL11.glPushMatrix();//glstart
    				String tu1 = String.valueOf(t1 + 1);
    				float turretrote = 180.0F - entityYaw;
    				if(entity.turretrote[t1]) {
    					turretrote = 180.0F - entityYaw;
    				}
    				GL11.glTranslatef(entity.arm_x[t1], entity.arm_y[t1], entity.arm_z[t1]);
        			GL11.glRotatef(180.0F - entity.rotation - turretrote, 0.0F, 1.0F, 0.0F);
        			GL11.glTranslatef(-entity.arm_x[t1], -entity.arm_y[t1], -entity.arm_z[t1]);
        			entity.model.renderPart("mat4_" + tu1);
        			
        			for(int t2 = 0; t2 < entity.rader; ++t2){
            			if(entity.raderturret[t2] == t1 + 1) {
            				GL11.glPushMatrix();//glstart
                			String tu2 = String.valueOf(t2 + 1);
            				GL11.glTranslatef(entity.rader_x[t2], entity.rader_y[t2], entity.rader_z[t2]);//0,1,2.5
            				GL11.glRotatef((float)mod_GVCLib.proxy.getCilentWorld().func_72820_D()  * 10F, entity.raderrote_x[t2], entity.raderrote_y[t2], entity.raderrote_z[t2]);
            				GL11.glTranslatef(-entity.rader_x[t2], -entity.rader_y[t2], -entity.rader_z[t2]);
            				entity.model.renderPart("rader_" + tu2);
            				GL11.glPopMatrix();//glend
            			}
        			}
        			
        			GL11.glTranslatef(entity.hand_x[t1], entity.hand_y[t1], entity.hand_z[t1]);
        			GL11.glRotatef(entity.rotationp, 1.0F, 0.0F, 0.0F);
        			GL11.glTranslatef(-entity.hand_x[t1], -entity.hand_y[t1], -entity.hand_z[t1]);
        			entity.model.renderPart("mat5_" + tu1);
        			
        			if(entity.getBoost()) {
        				for(int t3 = 0; t3 < entity.laser_sight; ++t3){
                			if(entity.rote_laser_sight[t3]) {
                				if(entity.func_184179_bs() != null && entity.func_184179_bs() == Minecraft.func_71410_x().field_71439_g){
                					if(entity.laser_sight_weapon[t3] == 0) {
                						if(entity.getRemain_L() > 0)RenderLaserSight.can(entity, entity.laser_sight_x[t3], entity.laser_sight_y[t3], entity.laser_sight_z[t3], 1.0F, entity.tex);
                					}
                					else if(entity.laser_sight_weapon[t3] == 1) {
                						if(entity.getRemain_R() > 0)RenderLaserSight.can(entity, entity.laser_sight_x[t3], entity.laser_sight_y[t3], entity.laser_sight_z[t3], 1.0F, entity.tex);
                					}
                					else if(entity.laser_sight_weapon[t3] == 2) {
                						if(entity.getRemain_A() > 0)RenderLaserSight.can(entity, entity.laser_sight_x[t3], entity.laser_sight_y[t3], entity.laser_sight_z[t3], 1.0F, entity.tex);
                					}
                					else if(entity.laser_sight_weapon[t3] == 3) {
                						if(entity.getRemain_S() > 0)RenderLaserSight.can(entity, entity.laser_sight_x[t3], entity.laser_sight_y[t3], entity.laser_sight_z[t3], 1.0F, entity.tex);
                					}
                    			}
                			}
                		}
        			}
        			
        			
        			if(entity.finger_type[t1] == 0) {
        				if(!entity.counter1){
            				if(entity.cooltime >= 0 && entity.cooltime < 4){
            					GL11.glTranslatef(0.0F, 0.0F, -entity.cooltime * 0.4F);
            				}
            				if(entity.cooltime >= 4 && entity.cooltime < 15){
            					GL11.glTranslatef(0.0F, 0.0F, -1.2F);
            					GL11.glTranslatef(0.0F, 0.0F, entity.cooltime * 0.1F);
            				}
            			}
        			}
        			if(entity.finger_type[t1] == 1) {
        				GL11.glTranslatef(entity.hand_x[t1], entity.hand_y[t1], entity.hand_z[t1]);
            			GL11.glRotatef(entity.getRemain_L() * 30, 0.0F, 0.0F, 1.0F);
            			GL11.glTranslatef(-entity.hand_x[t1], -entity.hand_y[t1], -entity.hand_z[t1]);
        			}
        			if(entity.finger_type[t1] == 2) {
        				if(!entity.counter1){
        					if(entity.cooltime >= 0 && entity.cooltime < 1){
        						GL11.glTranslatef(0.0F, 0.0F, -1 * 0.1F);
        					}
        				}
        			}
        			entity.model.renderPart("mat6_" + tu1);
        			GL11.glPopMatrix();//glend
    			}
    		}
    		}
    		GL11.glColor4f(1F, 1F, 1F, 1F);
    		GL11.glDisable(GL12.GL_RESCALE_NORMAL);
    		GL11.glPopMatrix();//glend
        }
		
		
        super.func_76986_a(entity, x, y, z, entityYaw, partialTicks);
    }
    
    /**
     * Returns the location of an entity's texture. Doesn't seem to be called unless you call Render.bindEntityTexture.
     */
    protected ResourceLocation func_110775_a(EntityHMV2_Vehicle entity)
    {
    	/*if(entity.getTex() != null) {
    		return new ResourceLocation(entity.getTex());
    	}else {
    		 return new ResourceLocation("textures/blocks/planks_oak.png");
    	}*/
    	if(entity.tex != null) {
    		return entity.tex;
    	}else {
    		return new ResourceLocation("textures/blocks/planks_oak.png");
    	}
    }
    
    protected void renderLivingAt(EntityHMV2_Vehicle entityLivingBaseIn, double x, double y, double z)
    {
        GlStateManager.func_179109_b((float)x, (float)y, (float)z);
    }
    protected float handleRotationFloat(EntityHMV2_Vehicle livingBase, float partialTicks)
    {
        return (float)livingBase.field_70173_aa + partialTicks;
    }
}

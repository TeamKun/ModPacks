package handmadevehicle2.item;

import javax.annotation.Nullable;
import gvclib.mod_GVCLib;
import handmadevehicle2.entity.EntityHMV2_S;
import handmadevehicle2.entity.EntityHMV2_Vehicle;
import net.minecraft.block.BlockLiquid;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;
import objmodel.IModelCustom;


import gvclib.mod_GVCLib;
import handmadevehicle2.entity.EntityHMV2_S;
import handmadevehicle2.entity.EntityHMV2_Vehicle;
import net.minecraft.block.BlockLiquid;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;
import objmodel.IModelCustom;

public class ItemSpawnHMV2 extends Item
{
	public String modid = mod_GVCLib.MOD_ID;
	public int id = 0;
	
	public boolean vacanspawn = false;
    public int spawn_rare = 10;
	
	//public String model;
	//public String tex;
	
	public IModelCustom model;
	public ResourceLocation tex;
	
	public String exhaust_model;
	public String exhaust_tex;
	
	/**rotationがプレイヤーに追従*/
	public boolean ridding_roteplayer = true;
	public int riddng_maximum = 1;
	public double[] riddingx = new double[32];
	public double[] riddingy = new double[32];
	public double[] riddingz = new double[32];
	
	public double[] riddingx_roteplayer = new double[32];
	public double[] riddingy_roteplayer = new double[32];
	public double[] riddingz_roteplayer = new double[32];
	
	@Deprecated
	public boolean ridding_rote;
	
	public boolean zoom = true;
	public boolean ridding_invisible = false;
	public boolean ridding_f = false;
	public boolean ridding_t = false;
	public float ridding_view1_x = 0F;
	public float ridding_view1_y = 0F;
	public float ridding_view1_z = 0F;
	public float ridding_view_x = 0F;
	public float ridding_view_y = -1F;
	public float ridding_view_z = -2F;
	@Deprecated
	public float ridding_view_gunner_x = 0F;
	@Deprecated
	public float ridding_view_gunner_y = 2F;
	@Deprecated
	public float ridding_view_gunner_z = 1F;
	public boolean biped = false;
	public float ridding_zoom = 2.0F;
	public String hud_icon = "gvclib:textures/hud/cross.png";
	public boolean render_hud_icon_hori = false;
	public String hud_icon_hori = "gvclib:textures/hud/cross.png";
	public boolean render_hud_scope = false;
	public String hud_icon_scope = "gvclib:textures/misc/scope.png";
	public boolean render_hud_scope_zoom = false;
	public String hud_icon_scope_zoom = "gvclib:textures/misc/scope.png";
	public boolean renderhud = false;
	public boolean render_rader = true;
	public boolean riddng_opentop = true;
	public float ridding_damege = 0.25F;
	
	public boolean aarader = false;
	
	
	public int vehicletype = 0;
	public String movesound = null;
	public double maxhp = 200D;
	public float setwidth = 1F;
	public float setheight = 1F;
	public float antibullet_0 = 1;
	public float antibullet_1 = 1;
	public float antibullet_2 = 1;
	public float antibullet_3 = 1;
	public boolean can_turret = false;
    public float turret_height = 0;
    public float damage_front = 0;
    public float damage_side = 0;
    public float damage_rear = 0;
    public float damage_top = 0;
    public float damage_bottom = 0;
    
    public float damage_turret_front = 0;
    public float damage_turret_side = 0;
    public float damage_turret_rear = 0;
	public float sp = 0.025F;
	public float turnspeed = 1.5F;
	public float stepHeight = 1.5F;
	
	/**true時に移動時ブロックを破壊する*/
	public boolean roodbreak = false;
	
	public float thmax = 5F;
	public float thmin = -2F;
	public float thmaxa = 0.2F;
	public float thmina = -0.15F;
	
	public float rotationp_max = -90;
	public float rotationp_min = 90;
	
	public boolean ridding_rotation_lock = false;
	/**ridding_rotation_lockがtrueの時のみ*/
	public float rotation_max = 60;
	
	
	public float model_angle_base_x = 0;
	public float model_angle_base_y = 0;
	public float model_angle_base_z = 0;
	public float model_angle_offset_x = 0;
	public float model_angle_offset_y = 0;
	public float model_angle_offset_z = 0;
	public float model_angle_x = 0;
	public float model_angle_y = 0;
	public float model_angle_z = 0;
	
	public int mob_min_range = 20;
	public int mob_max_range = 60;
	public int mob_min_height = 10;
	
	public boolean weapon1true = true;
	public int weapon1key  = -1;
	public String w1name = "";
	public boolean w1missile_aam = true;
	public int ammo1 = 10;
	public int magazine = 1;
	public int reload_time1 = 80;
	public int reloadsoundset1;
	public String reloadsound1;
	public int w1cycle;
	public int w1barst;
	public int weapon1;//
	public boolean w1crossfire = false;
	public boolean w1can_cooldown = false;
	@Deprecated
	public float w1kakumax = 180;
	@Deprecated
	public float w1kakumin = -180;
	public int[] bullet_type1 = new int[256];
	public String[] bullet_model1 = new String[32];
	public String[] bullet_tex1 = new String[32];
	public String[] fire_model1 = new String[32];
	public String[] fire_tex1 = new String[32];
	public int[] fire_time1 = new int[32];
	public String[] sound_fire1 = new String[32];
	public float[] fire_pointx1 = new float[32];
	public float[] fire_pointy1 = new float[32];
	public float[] fire_pointz1 = new float[32];
	public float[] basis_pointx1 = new float[32];
	public float[] basis_pointy1 = new float[32];
	public float[] basis_pointz1 = new float[32];
	public double[] fire_yoffset1 = new double[32];
	public boolean[] rotationfollowing1 = new boolean[32];
	public boolean[] rotationfirepoint1 = new boolean[32];
	public boolean[] rotation_player1 = new boolean[32];
	/**回転軸中心をarm_x,arm_zに合わせるかどうか
	 * 回転軸が中心にない物に使用*/
	public boolean[] rotation_firepointbxbz1 = new boolean[32];
	/**ピッチ方向(rotationpitch)をthisに合わせる(航空機のpitchがサーバーに適応されないため、爆撃の処置)*/
	public boolean[] rotation_lock_pitch_vehicle1 = new boolean[32];
	public int[] bullet_damage1 = new int[32];
	public float[] bullet_speed1 = new float[32];
	public float[] bullet_bure1 = new float[32];
	public float[] bullet_expower1 = new float[32];
	public boolean[] bullet_ex1 = new boolean[32];
	public int[] bullet_kazu1 = new int[32];
	public double[] bullet_gravity1 = new double[32];
	public int[] bullet_livingtime1 = new int[32];
	
	public boolean weapon11true = false;
	public String w11name;
	public int weapon11;
	public int[] bullet_type11 = new int[32];
	public String[] bullet_model11 = new String[32];
	public String[] bullet_tex11 = new String[32];
	public String[] fire_model11 = new String[32];
	public String[] fire_tex11 = new String[32];
	public int[] fire_time11 = new int[32];
	public String[] sound_fire11 = new String[32];
	public float[] fire_pointx11 = new float[32];
	public float[] fire_pointy11 = new float[32];
	public float[] fire_pointz11 = new float[32];
	public float[] basis_pointx11 = new float[32];
	public float[] basis_pointy11 = new float[32];
	public float[] basis_pointz11 = new float[32];
	public double[] fire_yoffset11 = new double[32];
	public boolean[] rotationfollowing11 = new boolean[32];
	public boolean[] rotationfirepoint11 = new boolean[32];
	public boolean[] rotation_player11 = new boolean[32];
	public int[] bullet_damage11 = new int[32];
	public float[] bullet_speed11 = new float[32];
	public float[] bullet_bure11 = new float[32];
	public float[] bullet_expower11 = new float[32];
	public boolean[] bullet_ex11 = new boolean[32];
	public int[] bullet_kazu11 = new int[32];
	public double[] bullet_gravity11 = new double[32];
	public int[] bullet_livingtime11 = new int[32];
	
	public boolean weapon12true = false;
	public String w12name;
	public int weapon12;
	public int[] bullet_type12 = new int[32];
	public String[] bullet_model12 = new String[32];
	public String[] bullet_tex12 = new String[32];
	public String[] fire_model12 = new String[32];
	public String[] fire_tex12 = new String[32];
	public int[] fire_time12 = new int[32];
	public String[] sound_fire12 = new String[32];
	public float[] fire_pointx12 = new float[32];
	public float[] fire_pointy12 = new float[32];
	public float[] fire_pointz12 = new float[32];
	public float[] basis_pointx12 = new float[32];
	public float[] basis_pointy12 = new float[32];
	public float[] basis_pointz12 = new float[32];
	public double[] fire_yoffset12 = new double[32];
	public boolean[] rotationfollowing12 = new boolean[32];
	public boolean[] rotationfirepoint12 = new boolean[32];
	public boolean[] rotation_player12 = new boolean[32];
	public int[] bullet_damage12 = new int[32];
	public float[] bullet_speed12 = new float[32];
	public float[] bullet_bure12 = new float[32];
	public float[] bullet_expower12 = new float[32];
	public boolean[] bullet_ex12 = new boolean[32];
	public int[] bullet_kazu12 = new int[32];
	public double[] bullet_gravity12 = new double[32];
	public int[] bullet_livingtime12 = new int[32];
	
	
	public int mob_w1range = 50;
	public int mob_w1range_max_y = 20;
	public int mob_w1range_min_y = 3;
	
	
	
	public boolean weapon2true = true;
	public int weapon2key  = -1;
	public String w2name = "";
	public boolean w2missile_aam = true;
	public int ammo2 = 20;
	public int magazine2 = 2;
	public int reload_time2 = 80;
	public int reloadsoundset2;
	public String reloadsound2;
	public int w2cycle;
	public int w2barst;
	public int weapon2;//
	public boolean w2crossfire = false;
	public boolean w2can_cooldown = false;
	public float w2kakumax = 180;
	public float w2kakumin = -180;
	public int[] bullet_type2 = new int[256];
	public String[] bullet_model2 = new String[32];
	public String[] bullet_tex2 = new String[32];
	public String[] fire_model2 = new String[32];
	public String[] fire_tex2 = new String[32];
	public int[] fire_time2 = new int[32];
	public String[] sound_fire2 = new String[32];
	public float[] fire_pointx2 = new float[32];
	public float[] fire_pointy2 = new float[32];
	public float[] fire_pointz2 = new float[32];
	public float[] basis_pointx2 = new float[32];
	public float[] basis_pointy2 = new float[32];
	public float[] basis_pointz2 = new float[32];
	public double[] fire_yoffset2 = new double[32];
	public boolean[] rotationfollowing2 = new boolean[32];
	public boolean[] rotationfirepoint2 = new boolean[32];
	public boolean[] rotation_player2 = new boolean[32];
	/**回転軸中心をarm_x,arm_zに合わせるかどうか
	 * 回転軸が中心にない物に使用*/
	public boolean[] rotation_firepointbxbz2 = new boolean[32];
	/**ピッチ方向(rotationpitch)をthisに合わせる(航空機のpitchがサーバーに適応されないため、爆撃の処置)*/
	public boolean[] rotation_lock_pitch_vehicle2 = new boolean[32];
	public int[] bullet_damage2 = new int[32];
	public float[] bullet_speed2 = new float[32];
	public float[] bullet_bure2 = new float[32];
	public float[] bullet_expower2 = new float[32];
	public boolean[] bullet_ex2 = new boolean[32];
	public int[] bullet_kazu2 = new int[32];
	public double[] bullet_gravity2 = new double[32];
	public int[] bullet_livingtime2 = new int[32];
	
	public int mob_w2range = 50;
	public int mob_w2range_max_y = 20;
	public int mob_w2range_min_y = 3;
	
	public boolean weapon3true;
	public String w3name = "";
	public boolean w3missile_aam = true;
	public int ammo3 = 0;
	public int magazine3 = 0;
	public int reload_time3 = 0;
	public int reloadsoundset3;
	public String reloadsound3;
	public int w3cycle;
	public int w3barst;
	public int weapon3key = 0;
	public int weapon3;
	public int weapon3type = 0;
	public boolean w3crossfire = false;
	public boolean w3can_cooldown = false;
	public float w3kakumax = 180;
	public float w3kakumin = -180;
	public int[] bullet_type3 = new int[33];
	public String[] bullet_model3 = new String[33];
	public String[] bullet_tex3 = new String[33];
	public String[] fire_model3 = new String[33];
	public String[] fire_tex3 = new String[33];
	public int[] fire_time3 = new int[33];
	public String[] sound_fire3 = new String[33];
	public float[] fire_pointx3 = new float[33];
	public float[] fire_pointy3 = new float[33];
	public float[] fire_pointz3 = new float[33];
	public float[] basis_pointx3 = new float[33];
	public float[] basis_pointy3 = new float[33];
	public float[] basis_pointz3 = new float[33];
	public double[] fire_yoffset3 = new double[33];
	public boolean[] rotationfollowing3 = new boolean[33];
	public boolean[] rotationfirepoint3 = new boolean[33];
	public boolean[] rotation_player3 = new boolean[33];
	/**回転軸中心をarm_x,arm_zに合わせるかどうか
	 * 回転軸が中心にない物に使用*/
	public boolean[] rotation_firepointbxbz3 = new boolean[32];
	/**ピッチ方向(rotationpitch)をthisに合わせる(航空機のpitchがサーバーに適応されないため、爆撃の処置)*/
	public boolean[] rotation_lock_pitch_vehicle3 = new boolean[32];
	public int[] bullet_damage3 = new int[33];
	public float[] bullet_speed3 = new float[33];
	public float[] bullet_bure3 = new float[33];
	public float[] bullet_expower3 = new float[33];
	public boolean[] bullet_ex3 = new boolean[33];
	public int[] bullet_kazu3 = new int[33];
	public double[] bullet_gravity3 = new double[33];
	public int[] bullet_livingtime3 = new int[33];
	
	public int mob_w3range = 50;
	public int mob_w3range_max_y = 30;
	public int mob_w3range_min_y = 3;
	
	public boolean weapon4true;
	public String w4name = "";
	public boolean w4missile_aam = true;
	public int ammo4 = 0;
	public int magazine4 = 0;
	public int reload_time4 = 0;
	public int reloadsoundset4;
	public String reloadsound4;
	public int w4cycle;
	public int w4barst;
	public int weapon4key = 0;
	public int weapon4;
	public int weapon4type = 0;
	public boolean w4crossfire = false;
	public boolean w4can_cooldown = false;
	public float w4kakumax = 180;
	public float w4kakumin = -180;
	public int[] bullet_type4 = new int[34];
	public String[] bullet_model4 = new String[34];
	public String[] bullet_tex4 = new String[34];
	public String[] fire_model4 = new String[34];
	public String[] fire_tex4 = new String[34];
	public int[] fire_time4 = new int[34];
	public String[] sound_fire4 = new String[34];
	public float[] fire_pointx4 = new float[34];
	public float[] fire_pointy4 = new float[34];
	public float[] fire_pointz4 = new float[34];
	public float[] basis_pointx4 = new float[34];
	public float[] basis_pointy4 = new float[34];
	public float[] basis_pointz4 = new float[34];
	public double[] fire_yoffset4 = new double[34];
	public boolean[] rotationfollowing4 = new boolean[34];
	public boolean[] rotationfirepoint4 = new boolean[34];
	public boolean[] rotation_player4 = new boolean[34];
	/**回転軸中心をarm_x,arm_zに合わせるかどうか
	 * 回転軸が中心にない物に使用*/
	public boolean[] rotation_firepointbxbz4 = new boolean[32];
	/**ピッチ方向(rotationpitch)をthisに合わせる(航空機のpitchがサーバーに適応されないため、爆撃の処置)*/
	public boolean[] rotation_lock_pitch_vehicle4 = new boolean[32];
	public int[] bullet_damage4 = new int[34];
	public float[] bullet_speed4 = new float[34];
	public float[] bullet_bure4 = new float[34];
	public float[] bullet_expower4 = new float[34];
	public boolean[] bullet_ex4 = new boolean[34];
	public int[] bullet_kazu4 = new int[34];
	public double[] bullet_gravity4 = new double[34];
	public int[] bullet_livingtime4 = new int[34];
	
	public int mob_w4range = 50;
	public int mob_w4range_max_y = 40;
	public int mob_w4range_min_y = 3;
	
	
	public int turret;
	public boolean[] turretrote = new boolean[32];
	public float[] arm_x = new float[32];
	public float[] arm_y = new float[32];
	public float[] arm_z = new float[32];
    
	public float[] hand_x = new float[32];
	public float[] hand_y = new float[32];
	public float[] hand_z = new float[32];
	
	/**mat6*/
	public int[] finger_type = new int[32];
	
	public int pera;
	public float[] pera_x = new float[32];
	public float[] pera_y = new float[32];
	public float[] pera_z = new float[32];
	public float[] perarote_x = new float[32];
	public float[] perarote_y = new float[32];
	public float[] perarote_z = new float[32];
	
	public int cloud;
	public double[] cloud_x = new double[32];
	public double[] cloud_y = new double[32];
	public double[] cloud_z = new double[32];
	
	public int rader;
	public int[] raderturret = new int[32];
	public float[] rader_x = new float[32];
	public float[] rader_y = new float[32];
	public float[] rader_z = new float[32];
	public float[] raderrote_x = new float[32];
	public float[] raderrote_y = new float[32];
	public float[] raderrote_z = new float[32];
	
	
	
	public boolean bomber_sighting = false;
    public boolean spg_sighting = false;
    /**水陸両用*/
    public boolean amphibious = false;
	
    public int exhaust = 0;
    public float[] exhaust_x = new float[32];
    public float[] exhaust_y = new float[32];
    public float[] exhaust_z = new float[32];
    public boolean exhaust_ab = false;
    
    public int laser_sight = 0;
    public float[] laser_sight_x = new float[32];
    public float[] laser_sight_y = new float[32];
    public float[] laser_sight_z = new float[32];
    public int[] laser_sight_weapon = new int[32];
    public boolean[] rote_laser_sight = new boolean[32];
	
	
    public ItemSpawnHMV2(int i)
    {
    	id = i;
        this.field_77777_bU = 1;
    }
    
    @Nullable
    public void spawnCreature(ItemStack stack, World worldIn, EntityPlayer playerIn, double par4, double par5, double par6)
    {
    	if(this.id == 0){
			++par5;
			int var12 = MathHelper.func_76128_c((double) (playerIn.field_70177_z * 4.0F / 360.0F) + 0.5D) & 3;
			EntityHMV2_Vehicle entityskeleton = new EntityHMV2_Vehicle(worldIn);
			entityskeleton.func_70012_b(par4 + 0.5, par5, par6 + 0.5, var12, 0.0F);
			entityskeleton.func_184201_a(EntityEquipmentSlot.HEAD, new ItemStack(this));
			entityskeleton.setcanDespawn(1);
			worldIn.func_72838_d(entityskeleton);
		}
    	else if (this.id == 1) {
    		++par5;
			int var12 = MathHelper.func_76128_c((double) (playerIn.field_70177_z * 4.0F / 360.0F) + 0.5D) & 3;
			EntityHMV2_S entityskeleton = new EntityHMV2_S(worldIn);
			entityskeleton.func_70012_b(par4 + 0.5, par5, par6 + 0.5, var12, 0.0F);
			entityskeleton.setcanDespawn(1);
			worldIn.func_72838_d(entityskeleton);
		}
    	else if (this.id == 2) {
    		
		}
    	
    }
	
    public EnumActionResult func_180614_a(EntityPlayer playerIn, World worldIn, BlockPos pos, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ)
    {
    	ItemStack stack = playerIn.func_184586_b(hand);
		int par4 = pos.func_177958_n();
		int par5 = pos.func_177956_o();
		int par6 = pos.func_177952_p();
		
		if (worldIn.field_72995_K)
        {
			return EnumActionResult.PASS;
        }
        else
		{
        	spawnCreature(stack, worldIn, playerIn, (double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p());
        	if (!playerIn.field_71075_bZ.field_75098_d)
            {
        		stack.func_190918_g(1);
            }
        	
        	
        	return EnumActionResult.PASS;
        }
    }
	
    public ActionResult<ItemStack> func_77659_a(World worldIn, EntityPlayer playerIn, EnumHand handIn)
    {
    	ItemStack itemStackIn = playerIn.func_184586_b(handIn);
        if (worldIn.field_72995_K)
        {
            return new ActionResult(EnumActionResult.PASS, itemStackIn);
        }
        else
        {
            RayTraceResult raytraceresult = this.func_77621_a(worldIn, playerIn, true);

            if (raytraceresult != null && raytraceresult.field_72313_a == RayTraceResult.Type.BLOCK)
            {
                BlockPos blockpos = raytraceresult.func_178782_a();

                if (!(worldIn.func_180495_p(blockpos).func_177230_c() instanceof BlockLiquid))
                {
                    return new ActionResult(EnumActionResult.PASS, itemStackIn);
                }
                else if (worldIn.func_175660_a(playerIn, blockpos) && playerIn.func_175151_a(blockpos, raytraceresult.field_178784_b, itemStackIn))
                {
                    spawnCreature(itemStackIn, worldIn, playerIn, (double)blockpos.func_177958_n(), (double)blockpos.func_177956_o(), (double)blockpos.func_177952_p());
                    {

                        if (!playerIn.field_71075_bZ.field_75098_d)
                        {
                        	itemStackIn.func_190918_g(1);
                        }

                        playerIn.func_71029_a(StatList.func_188057_b(this));
                        return new ActionResult(EnumActionResult.SUCCESS, itemStackIn);
                    }
                }
                else
                {
                    return new ActionResult(EnumActionResult.FAIL, itemStackIn);
                }
            }
            else
            {
                return new ActionResult(EnumActionResult.PASS, itemStackIn);
            }
        }
    }
	
	
	
    
}

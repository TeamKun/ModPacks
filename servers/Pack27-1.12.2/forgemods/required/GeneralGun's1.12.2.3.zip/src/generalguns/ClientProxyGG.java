package generalguns;


import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderSnowball;
//import net.java.games.input.Keyboard;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.client.MinecraftForgeClient;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.registry.VillagerRegistry;
public class ClientProxyGG extends CommonSideProxyGG {
    //�L�[��UnlocalizedName�A�o�C���h����L�[�̑Ή������l�iKeyboard�N���X�Q�Ƃ̂��Ɓj�A�J�e�S���[��
    //public static final KeyBinding Speedreload = new KeyBinding("Key.reloadGL", Keyboard.KEY_L, "GunLancePlus");
    //public static final KeyBinding GrenadeKey = new KeyBinding("Key.Grenade", Keyboard.KEY_G, "GVCGunsPlus");
	//private static final IItemRenderer ItemRenderAK74 = new GVCRenderItemAK74();
    //public static final EntityPlayer player = FMLClientHandler.instance().getClient().thePlayer;
    
    
    @Override
	public World getCilentWorld(){
		return FMLClientHandler.instance().getClient().theWorld;
		}
    
    @Override
    public void registerClientInfo() {
        //ClientRegistry.registerKeyBinding(Speedreload);
    }
    
    @Override
	public void reisterRenderers(){
    	Minecraft mc = FMLClientHandler.instance().getClient();
    	RenderManager rendermanager = new RenderManager(mc.renderEngine, mc.getRenderItem());
    	RenderItem renderitem = mc.getRenderItem();
    	RenderingRegistry.registerEntityRenderingHandler(GGEntityBullet.class, new GGRenderBullet(rendermanager));
    }
    
    @Override
    public void registerTileEntity() {
    	//GameRegistry.registerTileEntity(GVCTileEntityItemG36.class, "GVCTileEntitysample");
    }
    
    @Override
    public void InitRendering()
    {
    	//ClientRegistry.bindTileEntitySpecialRenderer(GVCTileEntityItemG36.class, new GVCRenderItemG36());
    }

    
    
 
}
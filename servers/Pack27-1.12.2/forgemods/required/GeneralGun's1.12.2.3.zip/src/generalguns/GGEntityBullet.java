package generalguns;

import littleMaidMobX.LMM_EntityLittleMaid;
import littleMaidMobX.LMM_EntityLittleMaidAvatar;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

public class GGEntityBullet extends EntityGBBase
{
	private int xTile = -1;
    private int yTile = -1;
    private int zTile = -1;
    private Block inTile;
    protected boolean inGround;
    public int throwableShake;
    /** The entity that threw this throwable item. */
    private EntityLivingBase thrower;
    private String throwerName;
    private int ticksInGround;
    private int ticksInAir;
    /***/
    public Entity field_184539_c;
    private int field_184540_av;
	
	
	private int Bdamege;
	private float Bspeed;
	private float Bure;
	
    
    //int i = mod_IFN_GuerrillaVsCommandGuns.RPGExplosiontime;
	@Override
	protected void entityInit() {
		if (worldObj != null) {
			isImmuneToFire = !worldObj.isRemote;
		}
		
	}

	public GGEntityBullet(World par1World)
    {
        super(par1World);
        //this.fuse = 30;
    }

    public GGEntityBullet(World par1World, EntityLivingBase par2EntityLivingBase, int damege, float bspeed, float bure)
    {
    	
    	super(par1World, par2EntityLivingBase);
        //this.setThrowableHeading(this.motionX, this.motionY, this.motionZ, this.func_70182_d(), 1.0F);
        //this.fuse = 30;
        this.Bdamege = damege;
        //this.Bspeed = bspeed;
        //this.Bure = bure;
        this.setThrowableHeading(this.motionX, this.motionY, this.motionZ, bspeed, bure);
    }

    public GGEntityBullet(World par1World, double par2, double par4, double par6)
    {
    	
        super(par1World, par2, par4, par6);
        //this.fuse = 30;
    }
    
    /**
     * Called when this EntityThrowable hits a block or entity.
     */
    protected void onImpact(RayTraceResult var1)
    {
        if (var1.entityHit != null)
        {
            int var2 = this.Bdamege;

            if(mod_GeneralGuns.cfg_FriendFireLMM == true){
             if (var1.entityHit instanceof LMM_EntityLittleMaid)
             {
                var2 = 0;
             }
             if (var1.entityHit instanceof LMM_EntityLittleMaidAvatar)
             {
                var2 = 0;
             }
            }
            var1.entityHit.hurtResistantTime = 0;

            var1.entityHit.attackEntityFrom(DamageSource.causeThrownDamage(this, this.getThrower()), (float)var2);
            
			if (!this.worldObj.isRemote)
	        {
	            this.setDead();
	            //this.explode();
	        }
        }else {
        	
			if (!this.worldObj.isRemote)
	        {
	            this.setDead();
	            //this.explode();
	        }
			}
    }
}

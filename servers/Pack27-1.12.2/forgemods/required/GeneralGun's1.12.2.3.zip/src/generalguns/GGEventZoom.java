package generalguns;


import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.VertexBuffer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.client.GuiIngameForge;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;
//import net.minecraftforge.fml.common.registry.LanguageRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class GGEventZoom {

	public String ads;
	
	@SideOnly(Side.CLIENT)
    @SubscribeEvent
	  public void renderfov(FOVUpdateEvent event)
	  {
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		EntityPlayer entityplayer = minecraft.thePlayer;
		ItemStack itemstack = ((EntityPlayer) (entityplayer)).getHeldItemMainhand();
		if(itemstack != null && itemstack.getItem() == mod_GeneralGuns.gg_sr){
			if (entityplayer.isSneaking()) {
				{
					event.setNewfov(event.getFov() / 4);
				}
			}
		}//item
	  }
	
	public boolean zoomtype;
	
	  @SideOnly(Side.CLIENT)
	  @SubscribeEvent
	  public void onEvent(RenderGameOverlayEvent.Pre event)
	  {
		  Minecraft minecraft = FMLClientHandler.instance().getClient();
		  World world = FMLClientHandler.instance().getWorldClient();
		  ScaledResolution scaledresolution = new ScaledResolution(minecraft);
	        int i = scaledresolution.getScaledWidth();
	        int j = scaledresolution.getScaledHeight();
			//Entity entity = minecraft.pointedEntity;
			EntityPlayer entityplayer = minecraft.thePlayer;
			//EntityPlayer entityplayer = event.player;
			ItemStack itemstack = ((EntityPlayer)(entityplayer)).getHeldItemMainhand();
			FontRenderer fontrenderer = minecraft.fontRendererObj;
	        minecraft.entityRenderer.setupOverlayRendering();
	        //OpenGlHelper.
	        
	        GL11.glEnable(GL11.GL_BLEND);
            if(FMLCommonHandler.instance().getSide() == Side.CLIENT) 
    		{
			if(itemstack != null && itemstack.getItem() instanceof GGItemGunBase){
				if(entityplayer.isSneaking()){
				if(itemstack != null && itemstack.getItem() == mod_GeneralGuns.gg_sr){
				    ads = "generalguns:textures/misc/scope.png";
				    GuiIngameForge.renderCrosshairs = false;
				    this.renderPumpkinBlur(minecraft,scaledresolution,ads );
				}
				else if(itemstack != null && itemstack.getItem() instanceof Item){
				}
				
				
				}else{
					GuiIngameForge.renderCrosshairs = true;
				}
				GuiIngameForge.renderCrosshairs = true;
				this.zoomtype = true;
			}else{
				if(this.zoomtype == true){
				GuiIngameForge.renderCrosshairs = true;
				this.zoomtype = false;
				}
				
			}
    		}
	  }

	  @SideOnly(Side.CLIENT)
	  protected void renderPumpkinBlur(Minecraft minecraft, ScaledResolution scaledRes, String adss)
	    {
		  /*GlStateManager.disableDepth();
	        GlStateManager.depthMask(false);
	        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
	        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
	        GlStateManager.disableAlpha();
	        minecraft.getTextureManager().bindTexture(new ResourceLocation(adss));
	        Tessellator tessellator = Tessellator.getInstance();
	        WorldRenderer worldrenderer = tessellator.getWorldRenderer();
	        worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
	        worldrenderer.pos(0.0D, (double)p_180476_1_.getScaledHeight(), -90.0D).tex(0.0D, 1.0D).endVertex();
	        worldrenderer.pos((double)p_180476_1_.getScaledWidth(), (double)p_180476_1_.getScaledHeight(), -90.0D).tex(1.0D, 1.0D).endVertex();
	        worldrenderer.pos((double)p_180476_1_.getScaledWidth(), 0.0D, -90.0D).tex(1.0D, 0.0D).endVertex();
	        worldrenderer.pos(0.0D, 0.0D, -90.0D).tex(0.0D, 0.0D).endVertex();
	        tessellator.draw();
	        GlStateManager.depthMask(true);
	        GlStateManager.enableDepth();
	        GlStateManager.enableAlpha();
	        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);*/
		  GlStateManager.disableDepth();
	        GlStateManager.depthMask(false);
	        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
	        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
	        GlStateManager.disableAlpha();
	        minecraft.getTextureManager().bindTexture(new ResourceLocation(adss));
	        Tessellator tessellator = Tessellator.getInstance();
	        VertexBuffer vertexbuffer = tessellator.getBuffer();
	        vertexbuffer.begin(7, DefaultVertexFormats.POSITION_TEX);
	        vertexbuffer.pos(0.0D, (double)scaledRes.getScaledHeight(), -90.0D).tex(0.0D, 1.0D).endVertex();
	        vertexbuffer.pos((double)scaledRes.getScaledWidth(), (double)scaledRes.getScaledHeight(), -90.0D).tex(1.0D, 1.0D).endVertex();
	        vertexbuffer.pos((double)scaledRes.getScaledWidth(), 0.0D, -90.0D).tex(1.0D, 0.0D).endVertex();
	        vertexbuffer.pos(0.0D, 0.0D, -90.0D).tex(0.0D, 0.0D).endVertex();
	        tessellator.draw();
	        GlStateManager.depthMask(true);
	        GlStateManager.enableDepth();
	        GlStateManager.enableAlpha();
	        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
	    }
	
}

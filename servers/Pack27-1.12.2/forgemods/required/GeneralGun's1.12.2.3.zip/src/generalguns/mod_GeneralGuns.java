package generalguns;







import java.io.File;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;



import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.entity.RenderSnowball;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.model.b3d.B3DLoader;
import net.minecraftforge.client.model.obj.OBJLoader;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;
//import net.minecraftforge.fml.common.registry.LanguageRegistry;
import net.minecraftforge.fml.relauncher.Side;


@Mod(
		modid	= "GeneralGuns",
		name	= "GeneralGuns",
		version	= "1.7.x-srg-1"
		)
public class mod_GeneralGuns {
	@SidedProxy(clientSide = "generalguns.ClientProxyGG", serverSide = "generalguns.CommonSideProxyGG")
	public static CommonSideProxyGG proxy;
	public static final String MOD_ID = "GeneralGuns";
	@Mod.Instance("GeneralGuns")
	 
    public static mod_GeneralGuns INSTANCE;
	//public static final KeyBinding Speedreload = new KeyBinding("Key.reload", Keyboard.KEY_R, "GVCGunsPlus");
	
	public static boolean isDebugMessage = true;
	
	public static boolean cfg_exprotion = true;
	public static boolean cfg_FriendFireLMM;
	
	public static int cfg_zoomnomal;
	public static int cfg_zoom;
	
	public static Item gg_bullet;
	public static Item gg_hundgun;
	public static Item gg_rev;
	public static Item gg_ar;
	public static Item gg_shotgun;
	public static Item gg_sr;
	
	
	public static Item gg_shield;
	
	
	//public static GGEntityBullet bullet;
	//public static GGEntityBullettest bullet;
	
	protected static File configFile;
	
	public static final CreativeTabs tabgg = new GGCreativeTab("GGTab");
	
	


	public static void Debug(String pText, Object... pData) {
		if (isDebugMessage) {
			System.out.println(String.format("GeneralGuns-" + pText, pData));
		}
	}

	@net.minecraftforge.fml.common.Mod.EventHandler
	public void preInit(net.minecraftforge.fml.common.event.FMLPreInitializationEvent pEvent) {
		configFile = pEvent.getSuggestedConfigurationFile();
		Configuration lconf = new Configuration(configFile);
		lconf.load();
		cfg_FriendFireLMM	= lconf.get("RefinedMilitaryShovelReplica", "cfg_FriendFireLMM", false).getBoolean(false);
		cfg_zoomnomal	= lconf.get("Zoom", "cfg_ZoomNomal", 70).getInt(70);
		cfg_zoom	= lconf.get("Zoom", "cfg_Zoom", 4).getInt(4);
		lconf.save();
		
		
		
		gg_bullet	= new GGItemBullet().setUnlocalizedName("bullet").setCreativeTab(tabgg);
	    GameRegistry.registerItem(gg_bullet, "bullet");
		
	    /*
		 * int power
		 * float speed
		 * float bure
		 * double recoil
		 * int reload
		 * float bayonet
		 * float zoom
		 */
	    
		gg_hundgun	    = new GGItemGun_HG(5,3f,5f,1.5d,30,2.0f,1.0f).setUnlocalizedName("hundgun")
				.setMaxDamage(12).setCreativeTab(tabgg);
		GameRegistry.registerItem(gg_hundgun, "hundgun");
		gg_rev	    = new GGItemGun_HG(8,3f,5f,2.5d,30,2.0f,1.0f).setUnlocalizedName("rev")
				.setMaxDamage(6).setCreativeTab(tabgg);
		GameRegistry.registerItem(gg_rev, "rev");
		gg_ar	    = new GGItemGun_AR(8,4f,1f,1.2d,50,2.0f,1.0f).setUnlocalizedName("ar")
				.setMaxDamage(30).setCreativeTab(tabgg);
		GameRegistry.registerItem(gg_ar, "ar");
		gg_shotgun	    = new GGItemGun_SG(3,3f,50f,2.0d,50,2.0f,1.0f).setUnlocalizedName("shotgun")
				.setMaxDamage(8).setCreativeTab(tabgg);
		GameRegistry.registerItem(gg_shotgun, "shotgun");
		gg_sr	    = new GGItemGun_HG(16,4f,1f,1.2d,50,2.0f,1.0f).setUnlocalizedName("sr")
				.setMaxDamage(5).setCreativeTab(tabgg);
		GameRegistry.registerItem(gg_sr, "sr");
		
		/*
		gg_shield	= new GGItemShield().setUnlocalizedName("shield").setCreativeTab(tabgg);
	    GameRegistry.registerItem(gg_shield, "shield");
		*/
		
		if (pEvent.getSide().isClient()) {
			ModelLoader.setCustomModelResourceLocation(gg_bullet, 0, new ModelResourceLocation("GeneralGuns:bullet", "inventory"));
			ModelLoader.setCustomModelResourceLocation(gg_hundgun, 0, new ModelResourceLocation("GeneralGuns:hundgun", "inventory"));
			ModelLoader.setCustomModelResourceLocation(gg_rev, 0, new ModelResourceLocation("GeneralGuns:rev", "inventory"));
			ModelLoader.setCustomModelResourceLocation(gg_ar, 0, new ModelResourceLocation("GeneralGuns:ar", "inventory"));
			ModelLoader.setCustomModelResourceLocation(gg_shotgun, 0, new ModelResourceLocation("GeneralGuns:shotgun", "inventory"));
			ModelLoader.setCustomModelResourceLocation(gg_sr, 0, new ModelResourceLocation("GeneralGuns:sr", "inventory"));
			
			//ModelLoader.setCustomModelResourceLocation(gg_shield, 0, new ModelResourceLocation("GeneralGuns:shield", "inventory"));
			
		}
		
	//	B3DLoader.instance.addDomain("GeneralGuns");
	//	OBJLoader.instance.addDomain("GeneralGuns");
		GGSoundEvent.registerSounds();
	}
	
	@EventHandler
	public void init(FMLInitializationEvent pEvent) {
		int D = Short.MAX_VALUE;
		GameRegistry.addRecipe(new ItemStack(Items.GUNPOWDER, 1),
				"dd",
				"dd", 
				'd', Blocks.DIRT
			);
		
		GameRegistry.addRecipe(new ItemStack(gg_bullet, 3),
				"ig", 
				'i', Items.IRON_INGOT,
				'g', Items.GUNPOWDER
			);
		GameRegistry.addRecipe(new ItemStack(gg_bullet, 1),
				"ig", 
				'i', Items.FLINT,
				'g', Items.GUNPOWDER
			);
		GameRegistry.addRecipe(new ItemStack(gg_hundgun, 1),
				"ii", 
				"bi",
				'i', Items.IRON_INGOT,
				'b', this.gg_bullet
			);
		GameRegistry.addRecipe(new ItemStack(gg_rev, 1),
				"ii", 
				"bl",
				'i', Items.IRON_INGOT,
				'l', new ItemStack(Blocks.LOG, 1, D),
				'b', this.gg_bullet
			);
		GameRegistry.addRecipe(new ItemStack(gg_ar, 1),
				"iii", 
				" bi",
				'i', Items.IRON_INGOT,
				'b', this.gg_bullet
			);
		GameRegistry.addRecipe(new ItemStack(gg_shotgun, 1),
				"iii", 
				"bwi",
				'i', Items.IRON_INGOT,
				'w',new ItemStack(Blocks.PLANKS, 1, D),
				'b', this.gg_bullet
			);
		GameRegistry.addRecipe(new ItemStack(gg_sr, 1),
				" ii",
				"iii", 
				" bi",
				'i', Items.IRON_INGOT,
				'b', this.gg_bullet
			);
		
		//EntityRegistry.registerModEntity(HGEntityBullet.class, "BulletHG", 150, this, 128, 5, true);
		EntityRegistry.registerModEntity(GGEntityBullet.class, "Bullet", 180, this, 128, 5, true);
		
		MinecraftForge.EVENT_BUS.register(new GGEventZoom());
		
		FMLCommonHandler.instance().bus().register(this);
		proxy.reisterRenderers();
		proxy.registerTileEntity();
		proxy.InitRendering();
		
		//MinecraftForge.EVENT_BUS.register(new GGSoundEvents());
		
	}
	
}

	
	

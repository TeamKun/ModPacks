package generalguns;


import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

/**
 * Registers this mod's {@link SoundEvent}s.
 *
 * @author Choonster
 */
//@SuppressWarnings("WeakerAccess")
public class GGSoundEvent {
	public static SoundEvent Fire_Bullet;
	public static SoundEvent Fire_BulletHG;
	public static SoundEvent Reload;

	/**
	 * Register the {@link SoundEvent}s.
	 */
	public static void registerSounds() {
		Fire_Bullet = registerSound("generalguns.fire");
		Fire_BulletHG = registerSound("generalguns.firehg");
		Reload = registerSound("generalguns.reload");
	}

	/**
	 * Register a {@link SoundEvent}.
	 *
	 * @param soundName The SoundEvent's name without the testmod3 prefix
	 * @return The SoundEvent
	 */
	private static SoundEvent registerSound(String soundName) {
		final ResourceLocation soundID = new ResourceLocation(mod_GeneralGuns.MOD_ID, soundName);
		return GameRegistry.register(new SoundEvent(soundID).setRegistryName(soundID));
	}
}
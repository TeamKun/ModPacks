package generalguns;

import java.util.List;

import org.lwjgl.opengl.GL11;

import com.google.common.collect.Multimap;

import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.SidedProxy;



import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArrow;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.stats.StatList;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.World;
import net.minecraft.inventory.Slot;
import net.minecraftforge.client.GuiIngameForge;


	public class GGItemGun_HG extends GGItemGunBase {
		private float attackDamage;
		public static String ads;
		
		public GGItemGun_HG(int p, float s, float b, double r, int rt, float at, float cz) {
			super();
			
			
			this.maxStackSize = 1;
	        this.attackDamage = at;
	        //this.retime = 30;
	        this.powor = p;
	        this.speed = s;
	        this.bure = b;
	        this.recoil = r;
	        this.bureads = b/5;
	        this.recoilads = r/2;
	        this.reloadtime = rt;
	        this.scopezoom = cz;
		}
		

		public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4)
		  {
			String powor = String.valueOf(this.powor + EnchantmentHelper.getEnchantmentLevel(Enchantments.POWER, par1ItemStack));
			String speed = String.valueOf(this.speed);
			String bure = String.valueOf(this.bure);
			String recoil = String.valueOf(this.recoil);
			String retime = String.valueOf(this.reloadtime);
            String nokori = String.valueOf(getMaxDamage() - par1ItemStack.getItemDamage());
			
			par3List.add(TextFormatting.RED + "RemainingBullet " + I18n.translateToLocal(nokori));
		    par3List.add(TextFormatting.WHITE + "FireDamege " + "+" + I18n.translateToLocal(powor));
		    par3List.add(TextFormatting.WHITE + "BlletSpeed " + "+" + I18n.translateToLocal(speed));
		    par3List.add(TextFormatting.WHITE + "BlletSpread "+ "+" + I18n.translateToLocal(bure));
		    par3List.add(TextFormatting.WHITE + "Recoil " + "+" + I18n.translateToLocal(recoil));
		    par3List.add(TextFormatting.YELLOW + "ReloadTime " + "+" + I18n.translateToLocal(retime));
		   // par3List.add(EnumChatFormatting.YELLOW + "MagazimeType " + StatCollector.translateToLocal("ARMagazine"));
		    if(!(this.scopezoom == 1.0f)){
				String scopezoom = String.valueOf(this.scopezoom);
				par3List.add(TextFormatting.WHITE + "ScopeZoom " + "x" + I18n.translateToLocal(scopezoom));
			}
		   // par3List.add(TextFormatting.WHITE + "FirePowor " + I18n.translateToLocal("600"));
		  }
		
		
		
		public void onUpdate(ItemStack itemstack, World world, Entity entity, int i, boolean flag)
	    {
			EntityPlayer entityplayer = (EntityPlayer)entity;
			int s;
			int li = getMaxDamage() - itemstack.getItemDamage();
			boolean lflag = cycleBolt(itemstack);
			boolean var5 = entityplayer.capabilities.isCreativeMode || EnchantmentHelper.getEnchantmentLevel(Enchantments.INFINITY, itemstack) > 0;
			Item item = itemstack.getItem();
			ItemStack item_m = entityplayer.getHeldItemMainhand();
			ItemStack item_o = entityplayer.getHeldItemOffhand();
			
			NBTTagCompound nbt = itemstack.getTagCompound();
			boolean recoiled = nbt.getBoolean("Recoiled");
			int recoiledtime = nbt.getInteger("RecoiledTime");
			{
				if(!recoiled){
					++recoiledtime;
					nbt.setInteger("RecoiledTime", recoiledtime);
					if(recoiledtime > 0){
						nbt.setInteger("RecoiledTime", 0);
						nbt.setBoolean("Recoiled", true);
					}
				}
			}
			
			{
				GGItemGunBase gun = (GGItemGunBase) itemstack.getItem();
				if (itemstack.getItemDamage() == itemstack.getMaxDamage() && flag 
						&& entityplayer.inventory.hasItemStack(new ItemStack(mod_GeneralGuns.gg_bullet))) {
						if (entity != null && entity instanceof EntityPlayer) {
							if (itemstack == entityplayer.getHeldItemMainhand()) {
								int reloadti = nbt.getInteger("RloadTime");
								{
									gun.retime = reloadti;
									++reloadti;
									if (reloadti == gun.reloadtime) {
										gun.retime = reloadti = 0;
										nbt.setInteger("RloadTime", 0);
										{
										getReload(itemstack, world, entityplayer);
										}
									}else{
										nbt.setInteger("RloadTime", reloadti);
									}
								}
							}
						}
				}
			}
			
			super.onUpdate(itemstack, world, entity, i, flag);
	    }
		
		@Override
	    public byte getCycleCount(ItemStack pItemstack)
	    {
	        return 1;
	    }
		
		public void onPlayerStoppedUsing(ItemStack par1ItemStack, World par2World, EntityLivingBase par3EntityPlayer, int par4){
        	EntityPlayer entityplayer = (EntityPlayer)par3EntityPlayer;
			int s;
			int li = getMaxDamage() - par1ItemStack.getItemDamage();
			boolean lflag = cycleBolt(par1ItemStack);
			boolean var5 = entityplayer.capabilities.isCreativeMode || EnchantmentHelper.getEnchantmentLevel(Enchantments.INFINITY, par1ItemStack) > 0;
			Item item = par1ItemStack.getItem();
			NBTTagCompound nbt = par1ItemStack.getTagCompound();
			boolean cocking = nbt.getBoolean("Cocking");;
			
			//if (var5 || par3EntityPlayer.inventory.hasItemStack(new ItemStack(mod_GeneralGuns.gg_bullet)))
	        {
	         if(par1ItemStack.getItemDamage() == this.getMaxDamage())
			 {
	        	 //this.isreload = 1;
	        	 //par2World.playSoundAtEntity(par3EntityPlayer, "gvcguns:gvcguns.reload", 1.0F, 1.0F);
			 }
	        	else	 
			 {
						FireBullet(par1ItemStack,par2World,(EntityPlayer) par3EntityPlayer);
						nbt.setBoolean("Cocking", false);
						nbt.setBoolean("Recoiled", false);
						entityplayer.addStat(StatList.getObjectUseStats(this));
			  }
			}
			
        }
		
		/*public ActionResult<ItemStack> onItemRightClick(ItemStack itemStackIn, World worldIn, EntityPlayer playerIn, EnumHand hand)
	    {
	        //boolean flag = this.func_185060_a(playerIn) != null;

	        //ActionResult<ItemStack> ret = net.minecraftforge.event.ForgeEventFactory.onArrowNock(itemStackIn, worldIn, playerIn, hand, flag);
	        //if (ret != null) return ret;

	        if (!playerIn.capabilities.isCreativeMode || playerIn.inventory.hasItemStack(new ItemStack(mod_GeneralGuns.gg_bullet)))
	        {
	            return  new ActionResult(EnumActionResult.FAIL, itemStackIn) ; 
	        }
	        else
	        {
	            playerIn.setActiveHand(hand);
	            return new ActionResult(EnumActionResult.SUCCESS, itemStackIn);
	        }
	    }*/
		
		public boolean onEntitySwing(EntityLivingBase entity, ItemStack par1ItemStack) {
			EntityPlayer playerIn = (EntityPlayer) entity;
			boolean var5 = playerIn.capabilities.isCreativeMode
					|| EnchantmentHelper.getEnchantmentLevel(Enchantments.INFINITY, par1ItemStack) > 0;
			boolean flag = this.func_185060_a(playerIn) != null;
			Item item = par1ItemStack.getItem();
			ItemStack iitem = playerIn.getHeldItemOffhand();
			
			if (flag && !(iitem.getItemDamage() == iitem.getMaxDamage()))
	        {
				FireBullet(iitem,playerIn.worldObj,(EntityPlayer) playerIn);
				playerIn.addStat(StatList.getObjectUseStats(this));
			return true;
	        }else{
	        	return false;
	        }
		}
		
		public ActionResult<ItemStack> onItemRightClick(ItemStack itemStackIn, World worldIn, EntityPlayer playerIn, EnumHand hand)
	    {
			int li = getMaxDamage() - itemStackIn.getItemDamage();
			boolean flag = this.func_185060_a(playerIn) != null;

	        ActionResult<ItemStack> ret = net.minecraftforge.event.ForgeEventFactory.onArrowNock(itemStackIn, worldIn, playerIn, hand, flag);
	        if (ret != null) return ret;

	        if (!playerIn.capabilities.isCreativeMode && !flag && !(itemStackIn.getItemDamage() == this.getMaxDamage()))
	        {
	            return !flag ? new ActionResult(EnumActionResult.FAIL, itemStackIn) : new ActionResult(EnumActionResult.PASS, itemStackIn);
	        }
	        else
	        {
	            playerIn.setActiveHand(hand);
	            return new ActionResult(EnumActionResult.SUCCESS, itemStackIn);
	        }
	    }

		public void FireBullet(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) 
		{
		//	par2World.playSoundAtEntity(par3EntityPlayer, "generalguns:generalguns.firehg", 1.0F, 1.0F);
			par2World.playSound((EntityPlayer)null, par3EntityPlayer.posX, par3EntityPlayer.posY, par3EntityPlayer.posZ,
        			GGSoundEvent.Fire_Bullet, SoundCategory.NEUTRAL, 1.0F, 1.0F);

			/*worldIn.playSound((EntityPlayer)null, playerIn.posX, playerIn.posY, playerIn.posZ,
					SoundEvents.entity_snowball_throw, SoundCategory.NEUTRAL, 0.5F, 0.4F / (itemRand.nextFloat() * 0.4F + 0.8F));*/
			
            par1ItemStack.damageItem(1, par3EntityPlayer);
            
            int pluspower = EnchantmentHelper.getEnchantmentLevel(Enchantments.POWER, par1ItemStack);
            GGEntityBullet var8 = new GGEntityBullet(par2World,(EntityLivingBase) par3EntityPlayer, this.powor+pluspower, this.speed, this.bure);
            var8.setAim(par3EntityPlayer, par3EntityPlayer.rotationPitch, par3EntityPlayer.rotationYaw, 0.0F, this.speed, this.bure);
            par3EntityPlayer.rotationPitch += (itemRand.nextFloat() * -3F) * this.recoil;
            
               if (!par2World.isRemote)
               {
                par2World.spawnEntityInWorld(var8);
               }
            
		}
		
		public void getReload(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) 
		{
			par2World.playSound((EntityPlayer)null, par3EntityPlayer.posX, par3EntityPlayer.posY, par3EntityPlayer.posZ,
        			GGSoundEvent.Reload, SoundCategory.NEUTRAL, 1.0F, 1.0F);
			
			int li = getMaxDamage() - par1ItemStack.getItemDamage();
			boolean linfinity = EnchantmentHelper.getEnchantmentLevel(Enchantments.INFINITY, par1ItemStack) > 0;
			//ItemStack item = par3EntityPlayer.inventory.(new ItemStack(mod_GeneralGuns.gg_bullet))
			ItemStack item = this.func_185060_a(par3EntityPlayer);
			if(!par3EntityPlayer.capabilities.isCreativeMode || par3EntityPlayer.inventory.hasItemStack(new ItemStack(mod_GeneralGuns.gg_bullet))){
			        par1ItemStack.damageItem(li, par3EntityPlayer);
					setDamage(par1ItemStack, -this.getMaxDamage());
					if (!linfinity) {
						--item.stackSize;
						InventoryPlayer playerInv = par3EntityPlayer.inventory;
						for(int is = 0; is < playerInv.mainInventory.length; ++is){
							if(playerInv.mainInventory[is] == item){
								if(item.stackSize <= 0){
									playerInv.mainInventory[is] = null;
								}
							}
						}
					}
			}
		}
    
		public Multimap<String, AttributeModifier> getItemAttributeModifiers(EntityEquipmentSlot equipmentSlot)
	    {
	        Multimap<String, AttributeModifier> multimap = super.getItemAttributeModifiers(equipmentSlot);

	        if (equipmentSlot == EntityEquipmentSlot.MAINHAND)
	        {
	            multimap.put(SharedMonsterAttributes.ATTACK_DAMAGE.getAttributeUnlocalizedName(), new AttributeModifier(ATTACK_DAMAGE_MODIFIER, "Weapon modifier", (double)this.attackDamage, 0));
	            multimap.put(SharedMonsterAttributes.ATTACK_SPEED.getAttributeUnlocalizedName(), new AttributeModifier(ATTACK_SPEED_MODIFIER, "Weapon modifier", -2.4000000953674316D, 0));
	        }

	        return multimap;
	    }
}

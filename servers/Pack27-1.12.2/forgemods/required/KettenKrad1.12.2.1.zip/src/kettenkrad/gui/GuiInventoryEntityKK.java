package kettenkrad.gui;

import org.lwjgl.opengl.GL11;

import kettenkrad.entity.EntityBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class GuiInventoryEntityKK extends GuiContainer
{
	private static final ResourceLocation texture = new ResourceLocation("textures/gui/container/generic_54.png");
	//private static final ResourceLocation texture = new ResourceLocation("gvcrbattlemachine:textures/gui/gui.png");
	//private static final ResourceLocation texturepara = new ResourceLocation("gvcrbattlemachine:textures/gui/robogui_para.png");
    private IInventory field_147030_v;
    private IInventory field_147029_w;
    private EntityBase field_147034_x;
    private int inventoryRows;
    private static final String __OBFID = "CL_00000760";
    private boolean tex = false;
    
    /** The old x position of the mouse pointer */
    private float oldMouseX;
    /** The old y position of the mouse pointer */
    private float oldMouseY;

    public GuiInventoryEntityKK(IInventory p_i1093_1_, EntityBase p_i1093_3_, EntityPlayer player)
    {
        super(new ContainerInventoryEntityKK(p_i1093_1_, p_i1093_3_, Minecraft.func_71410_x().field_71439_g));
        this.field_147030_v = p_i1093_1_;
        //this.field_147029_w = p_i1093_2_;
        this.field_147034_x = p_i1093_3_;
        this.field_146291_p = false;
        /*short short1 = 222;
        int i = short1 - 108;
        this.inventoryRows = p_i1093_2_.getSizeInventory() / 9;
        this.ySize = i + this.inventoryRows * 18;*/
        this.field_147000_g = 222;
    }

    public void func_73866_w_() {
    	super.func_73866_w_();
    	int i = field_146294_l  - field_146999_f >> 1;
		int j = field_146295_m - field_147000_g >> 1;
        //this.buttonList.add(new GuiButton(0, i + 175, j + 0, 50, 20 , "Parameters"));
		//this.buttonList.add(new GuiButton(0, i + 175, j + 0, 50, 20 , "battlemachine:bm.parameters"));
        //this.buttonList.add(new GuiButton(1, i + 210, j + 10, 30, 20 , "Button 1"));
    }
    
    /**
     * Draw the foreground layer for the GuiContainer (everything in front of the items)
     */
    protected void func_146979_b(int p_146979_1_, int p_146979_2_)
    {
    	int k = (this.field_146294_l - this.field_146999_f) / 2;
        int l = (this.field_146295_m - this.field_147000_g) / 2;
        
       
    }

    protected void func_146976_a(float p_146976_1_, int p_146976_2_, int p_146976_3_)
    {
    	GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        this.field_146297_k.func_110434_K().func_110577_a(texture);
        int k = (this.field_146294_l - this.field_146999_f) / 2;
        int l = (this.field_146295_m - this.field_147000_g) / 2;
        this.func_73729_b(k, l, 0, 0, this.field_146999_f, this.field_147000_g);
        
        GL11.glPushMatrix();//glstart
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.func_179152_a(0.75F, 0.75F, 0.75F);
        int i = this.field_147003_i;
        int j = this.field_147009_r;
       // drawEntityOnScreen(i + 110, j + 170, 30, (float)(i + 51) - this.oldMouseX, (float)(j + 75 - 50) - this.oldMouseY, field_147034_x);
        GL11.glPopMatrix();//glend
    }
    
    
    @Override
    protected void func_146284_a(GuiButton button) {

    }
    
    /**
     * Draws an entity on the screen looking toward the cursor.
     */
    public static void drawEntityOnScreen(int posX, int posY, int scale, float mouseX, float mouseY, EntityLivingBase ent)
    {
        GlStateManager.func_179142_g();
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)posX, (float)posY, 50.0F);
        GlStateManager.func_179152_a((float)(-scale), (float)scale, (float)scale);
        GlStateManager.func_179114_b(180.0F, 0.0F, 0.0F, 1.0F);
        float f = ent.field_70761_aq;
        float f1 = ent.field_70177_z;
        float f2 = ent.field_70125_A;
        float f3 = ent.field_70758_at;
        float f4 = ent.field_70759_as;
        GlStateManager.func_179114_b(135.0F, 0.0F, 1.0F, 0.0F);
        RenderHelper.func_74519_b();
        GlStateManager.func_179114_b(-135.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.func_179114_b(-((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
        ent.field_70761_aq = (float)Math.atan((double)(mouseX / 40.0F)) * 20.0F;
        ent.field_70177_z = (float)Math.atan((double)(mouseX / 40.0F)) * 40.0F;
        ent.field_70125_A = -((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F;
        ent.field_70759_as = ent.field_70177_z;
        ent.field_70758_at = ent.field_70177_z;
        GlStateManager.func_179109_b(0.0F, 0.0F, 0.0F);
        RenderManager rendermanager = Minecraft.func_71410_x().func_175598_ae();
        rendermanager.func_178631_a(180.0F);
        rendermanager.func_178633_a(false);
        rendermanager.func_188391_a(ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F, false);
        rendermanager.func_178633_a(true);
        ent.field_70761_aq = f;
        ent.field_70177_z = f1;
        ent.field_70125_A = f2;
        ent.field_70758_at = f3;
        ent.field_70759_as = f4;
        GlStateManager.func_179121_F();
        RenderHelper.func_74518_a();
        GlStateManager.func_179101_C();
        GlStateManager.func_179138_g(OpenGlHelper.field_77476_b);
        GlStateManager.func_179090_x();
        GlStateManager.func_179138_g(OpenGlHelper.field_77478_a);
    }
}

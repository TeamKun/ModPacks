package kettenkrad.gui;

import kettenkrad.entity.EntityBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

public class GuiHandlerKK implements IGuiHandler {
	/*
	 * ServerでGUIが開かれたときに呼ばれる 通常はContainerを生成する。
	 */
	@Override
	public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
		// ItemStack itemstack = player.getCurrentEquippedItem();
		Entity entity = player.func_184187_bx();
		if (entity instanceof EntityBase && entity != null && player != null) {
			EntityBase en = (EntityBase) entity;
			if (ID == 0 && entity != null) {
				return new ContainerInventoryEntityKK(player.field_71071_by, en, player);
		//		return new SampleContainer(x, y, z);
			}
		}
		/*if (ID == 0) {
			return new SampleContainer(x, y, z);
		}*/
		return null;
	}

	/*
	 * ClientでGUIが開かれたときに呼ばれる 通常はGUIを生成する
	 */
	@Override
	public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
		// ItemStack itemstack = player.getCurrentEquippedItem();
		Entity entity = player.func_184187_bx();
		if (entity instanceof EntityBase && player != null) {
			EntityBase en = (EntityBase) entity;
			if (ID == 0) {
				 return new GuiInventoryEntityKK(player.field_71071_by, en,player);
		//		return new SampleGuiContainer(x, y, z);
			}
		}
		/*if (ID == 0) {
			return new SampleGuiContainer(x, y, z);
		}*/
		return null;
	}
}

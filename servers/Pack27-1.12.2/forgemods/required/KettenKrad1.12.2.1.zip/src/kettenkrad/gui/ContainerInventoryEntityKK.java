package kettenkrad.gui;

import kettenkrad.entity.EntityBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class ContainerInventoryEntityKK extends Container
{
    private IInventory field_111243_a;
    private EntityBase theHorse;
    private IInventory lowerChestInventory;
    private int numRows;
    private static final String __OBFID = "CL_00001742";

    public ContainerInventoryEntityKK(IInventory p_i1817_1_, final EntityBase p_i1817_3_, EntityPlayer player)
    {
    	//this.field_111243_a = p_i1817_2_;
    	this.lowerChestInventory = p_i1817_3_;
        //this.numRows = p_i1817_2_.getSizeInventory() / 9;
        //p_i1817_2_.openInventory(player);
        //p_i1817_2_.openInventory(player);
    	p_i1817_3_.func_174889_b(player);
    	int i = (this.numRows - 4) * 18;

        for (int j = 0; j < this.numRows; ++j)
        {
            for (int k = 0; k < 9; ++k)
            {
                this.func_75146_a(new Slot(p_i1817_3_, k + j * 9, 8 + k * 18, 18 + j * 18));
            }
        }

        for (int l = 0; l < 3; ++l)
        {
            for (int j1 = 0; j1 < 9; ++j1)
            {
                this.func_75146_a(new Slot(p_i1817_1_, j1 + l * 9 + 9, 8 + j1 * 18, 103 + l * 18 + i));
            }
        }

        for (int i1 = 0; i1 < 9; ++i1)
        {
            this.func_75146_a(new Slot(p_i1817_1_, i1, 8 + i1 * 18, 161 + i));
        }
    }

    /**
     * Determines whether supplied player can use this container
     */
    public boolean func_75145_c(EntityPlayer playerIn)
    {
        return this.lowerChestInventory.func_70300_a(playerIn);
    }

    /**
     * Handle when the stack in slot {@code index} is shift-clicked. Normally this moves the stack between the player
     * inventory and the other inventory(s).
     */
    public ItemStack func_82846_b(EntityPlayer playerIn, int index)
    {
        ItemStack itemstack = ItemStack.field_190927_a;
        Slot slot = this.field_75151_b.get(index);

        if (slot != null && slot.func_75216_d())
        {
            ItemStack itemstack1 = slot.func_75211_c();
            itemstack = itemstack1.func_77946_l();

            if (index < this.numRows * 9)
            {
                if (!this.func_75135_a(itemstack1, this.numRows * 9, this.field_75151_b.size(), true))
                {
                    return ItemStack.field_190927_a;
                }
            }
            else if (!this.func_75135_a(itemstack1, 0, this.numRows * 9, false))
            {
                return ItemStack.field_190927_a;
            }

            if (itemstack1.func_190926_b())
            {
                slot.func_75215_d(ItemStack.field_190927_a);
            }
            else
            {
                slot.func_75218_e();
            }
        }

        return itemstack;
    }

    /**
     * Called when the container is closed.
     */
    public void func_75134_a(EntityPlayer playerIn)
    {
        super.func_75134_a(playerIn);
        this.lowerChestInventory.func_174886_c(playerIn);
    }

    /**
     * Return this chest container's lower chest inventory.
     */
    public IInventory getLowerChestInventory()
    {
        return this.lowerChestInventory;
    }
}

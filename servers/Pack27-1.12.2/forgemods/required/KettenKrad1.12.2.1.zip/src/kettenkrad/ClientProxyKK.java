package kettenkrad;


import kettenkrad.entity.EntityKettenkrad;
import kettenkrad.entity.KKEntityBullet;
import kettenkrad.event.LayerKKGunBase;
import kettenkrad.render.KKRenderBullet;
import kettenkrad.render.RenderKettenkrad;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.world.World;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
public class ClientProxyKK extends CommonSideProxyKK {
    //�L�[��UnlocalizedName�A�o�C���h����L�[�̑Ή������l�iKeyboard�N���X�Q�Ƃ̂��Ɓj�A�J�e�S���[��
    //public static final KeyBinding Speedreload = new KeyBinding("Key.reloadGL", Keyboard.KEY_L, "GunLancePlus");
    //public static final KeyBinding GrenadeKey = new KeyBinding("Key.Grenade", Keyboard.KEY_G, "GVCGunsPlus");
	//private static final IItemRenderer ItemRenderAK74 = new GVCRenderItemAK74();
    //public static final EntityPlayer player = FMLClientHandler.instance().getClient().thePlayer;
    
    
    @Override
	public World getCilentWorld(){
		return FMLClientHandler.instance().getClient().field_71441_e;
		}
    
    @Override
    public void registerClientInfo() {
        //ClientRegistry.registerKeyBinding(Speedreload);
    }
    
    @Override
	public void reisterRenderers(){
    	Minecraft mc = FMLClientHandler.instance().getClient();
    	RenderManager rendermanager = new RenderManager(mc.field_71446_o, mc.func_175599_af());
    	RenderItem renderitem = mc.func_175599_af();
    	RenderingRegistry.registerEntityRenderingHandler(KKEntityBullet.class, new KKRenderBullet(rendermanager));
    	RenderingRegistry.registerEntityRenderingHandler(EntityKettenkrad.class, new RenderKettenkrad(rendermanager));
    	for (RenderPlayer playerRender : Minecraft.func_71410_x().func_175598_ae().getSkinMap().values()) {
			playerRender.func_177094_a(new LayerKKGunBase(playerRender));
		}
    }
    
    @Override
	public void reisterModel(){
    	/*for (RenderPlayer playerRender : Minecraft.getMinecraft().getRenderManager().getSkinMap().values()) {
			playerRender.addLayer(new LayerGunBase(playerRender));
		}
        for (Render render : Minecraft.getMinecraft().getRenderManager().entityRenderMap.values()) {
          if ((render instanceof RenderLivingBase))
          {
            RenderLivingBase rle = (RenderLivingBase)render;
            if ((rle.getMainModel() instanceof ModelBiped))
            {
              rle.addLayer(new LayerGunBase(rle));
            }
          }
        }/**/
    }
    
    @Override
    public void registerTileEntity() {
    	//GameRegistry.registerTileEntity(GVCTileEntityItemG36.class, "GVCTileEntitysample");
    }
    
    @Override
    public void InitRendering()
    {
    	//ClientRegistry.bindTileEntitySpecialRenderer(GVCTileEntityItemG36.class, new GVCRenderItemG36());
    }

    
    
 
}

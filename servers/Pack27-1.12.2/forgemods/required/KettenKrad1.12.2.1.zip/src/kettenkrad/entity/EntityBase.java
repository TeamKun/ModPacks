package kettenkrad.entity;

import javax.annotation.Nullable;

import kettenkrad.gui.ContainerInventoryEntityKK;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.World;

public abstract class EntityBase extends EntityBaseContainer implements IAnimals
{
	private static final DataParameter<Integer> mobmode = EntityDataManager.<Integer>func_187226_a(EntityBase.class, DataSerializers.field_187192_b);
	
	public float rotation;
	public float rotationp;
	public int angletime;
	public int cooltime;
	public int cooltime2;
	
	public int deathTicks;
	public boolean settnt;
	
	public boolean server1 = false;
	public float cooltimeC;
	public float cooltime2C;
	
	
	private static final DataParameter<Integer> CTC = EntityDataManager.<Integer>func_187226_a(EntityBase.class, DataSerializers.field_187192_b);
	
    public EntityBase(World worldIn)
    {
        super(worldIn);
    }

    protected void func_70088_a()
    {
        super.func_70088_a();
        this.field_70180_af.func_187214_a(CTC, Integer.valueOf(0));
        this.field_70180_af.func_187214_a(mobmode, Integer.valueOf(0));
    }
    
    public void func_70037_a(NBTTagCompound compound)
    {
        super.func_70037_a(compound);
        this.setCTC(compound.func_74762_e("CTC"));
        this.setMobMode(compound.func_74762_e("mobmode"));
        
    }

    public void func_70014_b(NBTTagCompound compound)
    {
        super.func_70014_b(compound);
        compound.func_74768_a("CTC", getCTC());
        compound.func_74768_a("mobmode", getMobMode());
    }
    
    public int getMobMode() {
		return ((this.field_70180_af.func_187225_a(mobmode)).intValue());
	}

	public void setMobMode(int stack) {
		this.field_70180_af.func_187227_b(mobmode, Integer.valueOf(stack));
	}
    
    public int getCTC() {
    		return ((this.field_70180_af.func_187225_a(CTC)).intValue());
    	}
    public void setCTC(int stack) {
    		this.field_70180_af.func_187227_b(CTC, Integer.valueOf(stack));
    }
    
    
    public void func_180430_e(float distance, float damageMultiplier)
    {
    }

    public boolean func_82171_bF()
    {
        Entity entity = this.func_184179_bs();
        return entity instanceof EntityLivingBase;
    }
    @Nullable
    public Entity func_184179_bs()
    {
        return this.func_184188_bt().isEmpty() ? null : (Entity)this.func_184188_bt().get(0);
    }
    
    @Nullable
    protected SoundEvent func_184639_G()
    {
        return null;
    }

    @Nullable
    protected SoundEvent getHurtSound()
    {
        return null;
    }

    @Nullable
    protected SoundEvent func_184615_bR()
    {
        return null;
    }

    /**
     * Get number of ticks, at least during which the living entity will be silent.
     */
    public int func_70627_aG()
    {
        return 120;
    }

    /**
     * Determines if an entity can be despawned, used on idle far away entities
     */
    protected boolean func_70692_ba()
    {
        return false;
    }
    
    public int func_70302_i_()
    {
        return 27;
    }

    public String func_174875_k()
    {
        return "minecraft:chest";
    }

    public Container func_174876_a(InventoryPlayer playerInventory, EntityPlayer playerIn)
    {
        this.addLoot(playerIn);
        return new ContainerInventoryEntityKK(playerInventory, this, playerIn);
    }
}

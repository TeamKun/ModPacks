package kettenkrad.entity;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

public class KKEntityBullet extends EntityBuBase
{
	private int xTile = -1;
    private int yTile = -1;
    private int zTile = -1;
    private Block inTile;
    protected boolean inGround;
    public int throwableShake;
    /** The entity that threw this throwable item. */
    private EntityLivingBase thrower;
    private String throwerName;
    private int ticksInGround;
    private int ticksInAir;
    /***/
    public Entity field_184539_c;
    private int field_184540_av;
	
	
	private int Bdamege;
	private float Bspeed;
	private float Bure;
	public EntityLivingBase friend;
	
    
    //int i = mod_IFN_GuerrillaVsCommandGuns.RPGExplosiontime;
	@Override
	protected void func_70088_a() {
		if (field_70170_p != null) {
			field_70178_ae = !field_70170_p.field_72995_K;
		}
		
	}

	public KKEntityBullet(World par1World)
    {
        super(par1World);
        //this.fuse = 30;
    }

    public KKEntityBullet(World par1World, EntityLivingBase par2EntityLivingBase, int damege, float bspeed, float bure)
    {
    	
    	super(par1World, par2EntityLivingBase);
    	this.thrower = par2EntityLivingBase;
        //this.setThrowableHeading(this.motionX, this.motionY, this.motionZ, this.func_70182_d(), 1.0F);
        //this.fuse = 30;
        this.Bdamege = damege;
        //this.Bspeed = bspeed;
        //this.Bure = bure;
        this.setThrowableHeading(this.field_70159_w, this.field_70181_x, this.field_70179_y, bspeed, bure);
    }

    public KKEntityBullet(World par1World, double par2, double par4, double par6)
    {
    	
        super(par1World, par2, par4, par6);
        //this.fuse = 30;
    }
    
    public void func_70071_h_()
    {
        super.func_70071_h_();
        {
        	this.field_70170_p.func_175688_a(EnumParticleTypes.CRIT, this.field_70165_t, this.field_70163_u + 0D, this.field_70161_v, 0.0D, 0.0D, 0.0D, new int[0]);
        }
    }
    
    /**
     * Called when this EntityThrowable hits a block or entity.
     */
    protected void onImpact(RayTraceResult result)
    {
        Entity entity = result.field_72308_g;
		if (entity != null){
			boolean ap = false;
			if (result.field_72308_g != null && result.field_72308_g != this.friend && result.field_72308_g != this.getThrower()) {
				int i = Bdamege;
				if (this.muteki) {
					result.field_72308_g.field_70172_ad = 0;
				}
				result.field_72308_g.func_70097_a(DamageSource.func_76356_a(this, this.getThrower()), (float) i);
			}else{
		//		this.onBreak(result);
			}
			
			this.field_70170_p.func_175688_a(EnumParticleTypes.CLOUD, this.field_70165_t, this.field_70163_u + 0D, this.field_70161_v, 0.0D, 0.0D, 0.0D, new int[0]);

			if (!this.field_70170_p.field_72995_K && !ap) {
		//		this.onBreak(result);
				this.func_70106_y();
				
			}
			if(this.bulletDameID == 4 || this.exlevel >= 1) {
				if (!this.field_70170_p.field_72995_K) {
					this.field_70170_p.func_72876_a(this, this.field_70165_t + 0, this.field_70163_u + 0, this.field_70161_v + 0, this.exlevel, false);
				}
			}
		}else {
			{
				if(!this.inGround) {
					if(this.bulletDameID == 4 || this.exlevel >= 1) {
						if (!this.field_70170_p.field_72995_K) {
							this.field_70170_p.func_72876_a(this, this.field_70165_t + 0, this.field_70163_u + 0, this.field_70161_v + 0, this.exlevel, false);
						}
					}
				}
	            BlockPos blockpos = result.func_178782_a();
	            this.xTile = blockpos.func_177958_n();
	            this.yTile = blockpos.func_177956_o();
	            this.zTile = blockpos.func_177952_p();
	            IBlockState iblockstate = this.field_70170_p.func_180495_p(blockpos);
	            this.inTile = iblockstate.func_177230_c();
	            this.inData = this.inTile.func_176201_c(iblockstate);
	            this.field_70159_w = (double)((float)(result.field_72307_f.field_72450_a - this.field_70165_t));
	            this.field_70181_x = (double)((float)(result.field_72307_f.field_72448_b - this.field_70163_u));
	            this.field_70179_y = (double)((float)(result.field_72307_f.field_72449_c - this.field_70161_v));
	            float f2 = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70181_x * this.field_70181_x + this.field_70179_y * this.field_70179_y);
	            this.field_70165_t -= this.field_70159_w / (double)f2 * 0.05000000074505806D;
	            this.field_70163_u -= this.field_70181_x / (double)f2 * 0.05000000074505806D;
	            this.field_70161_v -= this.field_70179_y / (double)f2 * 0.05000000074505806D;
	            this.func_184185_a(SoundEvents.field_187731_t, 1.0F, 1.2F / (this.field_70146_Z.nextFloat() * 0.2F + 0.9F));
	            this.inGround = true;
	           // this.arrowShake = 7;
	           // this.setIsCritical(false);

	            if (iblockstate.func_185904_a() != Material.field_151579_a)
	            {
	                this.inTile.func_180634_a(this.field_70170_p, blockpos, iblockstate, this);
	            	/*if (!this.world.isRemote) {
	            				this.setDead();
	            	}*/
	            }
	        }
		}
    }

	@Override
	public void func_70186_c(double x, double y, double z, float velocity, float inaccuracy) {
		// TODO 自動生成されたメソッド・スタブ
		
	}
}

package kettenkrad.entity;

import java.util.List;
import java.util.UUID;

import javax.annotation.Nullable;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IProjectile;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public abstract class EntityBuBase extends Entity implements IProjectile
{
	private static final Predicate<Entity> ARROW_TARGETS = Predicates.and(EntitySelectors.field_180132_d, EntitySelectors.field_94557_a, new Predicate<Entity>()
    {
        public boolean apply(@Nullable Entity p_apply_1_)
        {
            return p_apply_1_.func_70067_L();
        }
    });
	
    private static final UUID BABY_SPEED_BOOST_ID = UUID.fromString("B9766B59-9566-4402-BC1F-2EE2A276D836");
    
    protected int xTile;
    protected int yTile;
    protected int zTile;
    protected Block inTile;
    protected int inData;
    protected boolean inGround;
    public int throwableShake;
    /** The entity that threw this throwable item. */
    private EntityLivingBase thrower;
    private String throwerName;
    protected int ticksInGround;
    protected int ticksInAir;
    public Entity ignoreEntity;
    protected int ignoreTime;
    
    public EntityLivingBase friend;
    public double gra = 0.029;//
    public int Bdamege = 5;
    public boolean muteki = false;
    
    public int time;
    public int timemax = 200;
    public boolean smoke = false;
    public boolean ex =false;
    public float exlevel = 0.0F;
    
    public int extime = 80;
    public boolean exinground = false;
    
    public int bulletDameID = 0;
    public int P_ID = 0;
    public int P_LEVEL = 5;
    public int P_TIME = 200;
    
    public double startposX = 0;
    public double startposY = 0;
    public double startposZ = 0;
    
    //0916
    public EntityLivingBase mitarget = null;
	private int timeInGround;
	private int arrowShake;

    public EntityBuBase(World worldIn)
    {
        super(worldIn);
        this.xTile = -1;
        this.yTile = -1;
        this.zTile = -1;
        this.func_70105_a(0.25F, 0.25F);
    }

    public EntityBuBase(World worldIn, double x, double y, double z)
    {
        this(worldIn);
        this.func_70107_b(x, y, z);
    }

    public EntityBuBase(World worldIn, EntityLivingBase throwerIn)
    {
        this(worldIn, throwerIn.field_70165_t, throwerIn.field_70163_u + (double)throwerIn.func_70047_e() - 0.10000000149011612D, throwerIn.field_70161_v);
        this.thrower = throwerIn;
    }

    /**
     * Checks if the entity is in range to render.
     */
    @SideOnly(Side.CLIENT)
    public boolean func_70112_a(double distance)
    {
        double d0 = this.func_174813_aQ().func_72320_b() * 4.0D;

        if (Double.isNaN(d0))
        {
            d0 = 4.0D;
        }

        d0 = d0 * 64.0D;
        return distance < d0 * d0;
    }

    /**
     * Sets throwable heading based on an entity that's throwing it
     */
    public void setHeadingFromThrower(Entity entityThrower, float rotationPitchIn, float rotationYawIn, float pitchOffset, float velocity, float inaccuracy)
    {
        float f = -MathHelper.func_76126_a(rotationYawIn * 0.017453292F) * MathHelper.func_76134_b(rotationPitchIn * 0.017453292F);
        float f1 = -MathHelper.func_76126_a((rotationPitchIn + pitchOffset) * 0.017453292F);
        float f2 = MathHelper.func_76134_b(rotationYawIn * 0.017453292F) * MathHelper.func_76134_b(rotationPitchIn * 0.017453292F);
        this.setThrowableHeading((double)f, (double)f1, (double)f2, velocity, inaccuracy);
        this.field_70159_w += entityThrower.field_70159_w;
        this.field_70179_y += entityThrower.field_70179_y;

        if (!entityThrower.field_70122_E)
        {
            this.field_70181_x += entityThrower.field_70181_x;
        }
    }

    /**
     * Similar to setArrowHeading, it's point the throwable entity to a x, y, z direction.
     */
    public void setThrowableHeading(double x, double y, double z, float velocity, float inaccuracy)
    {
        float f = MathHelper.func_76133_a(x * x + y * y + z * z);
        x = x / (double)f;
        y = y / (double)f;
        z = z / (double)f;
        x = x + this.field_70146_Z.nextGaussian() * 0.007499999832361937D * (double)inaccuracy;
        y = y + this.field_70146_Z.nextGaussian() * 0.007499999832361937D * (double)inaccuracy;
        z = z + this.field_70146_Z.nextGaussian() * 0.007499999832361937D * (double)inaccuracy;
        x = x * (double)velocity;
        y = y * (double)velocity;
        z = z * (double)velocity;
        this.field_70159_w = x;
        this.field_70181_x = y;
        this.field_70179_y = z;
        float f1 = MathHelper.func_76133_a(x * x + z * z);
        this.field_70177_z = (float)(MathHelper.func_181159_b(x, z) * (180D / Math.PI));
        this.field_70125_A = (float)(MathHelper.func_181159_b(y, (double)f1) * (180D / Math.PI));
        this.field_70126_B = this.field_70177_z;
        this.field_70127_C = this.field_70125_A;
        this.ticksInGround = 0;
    }

    /**
     * Updates the velocity of the entity to a new value.
     */
    @SideOnly(Side.CLIENT)
    public void func_70016_h(double x, double y, double z)
    {
        this.field_70159_w = x;
        this.field_70181_x = y;
        this.field_70179_y = z;

        if (this.field_70127_C == 0.0F && this.field_70126_B == 0.0F)
        {
            float f = MathHelper.func_76133_a(x * x + z * z);
            this.field_70177_z = (float)(MathHelper.func_181159_b(x, z) * (180D / Math.PI));
            this.field_70125_A = (float)(MathHelper.func_181159_b(y, (double)f) * (180D / Math.PI));
            this.field_70126_B = this.field_70177_z;
            this.field_70127_C = this.field_70125_A;
        }
    }

    @SideOnly(Side.CLIENT)
    public int getBrightnessForRender(float partialTicks)
    {
        return 15728880;
    }

    /**
     * Gets how bright this entity is.
     */
    public float getBrightness(float partialTicks)
    {
        return 1.0F;
    }
    /**
     * Checks to make sure the light is not too bright where the mob is spawning
     */
    protected boolean isValidLightLevel()
    {
        return true;
    }
    
    /**
     * Called to update the entity's position/logic.
     */
    public void func_70071_h_()
    {
    	if (this.field_70127_C == 0.0F && this.field_70126_B == 0.0F)
        {
            float f = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70179_y * this.field_70179_y);
            this.field_70177_z = (float)(MathHelper.func_181159_b(this.field_70159_w, this.field_70179_y) * (180D / Math.PI));
            this.field_70125_A = (float)(MathHelper.func_181159_b(this.field_70181_x, (double)f) * (180D / Math.PI));
            this.field_70126_B = this.field_70177_z;
            this.field_70127_C = this.field_70125_A;
        }

        BlockPos blockpos = new BlockPos(this.xTile, this.yTile, this.zTile);
        IBlockState iblockstate = this.field_70170_p.func_180495_p(blockpos);
        Block block = iblockstate.func_177230_c();

        if (iblockstate.func_185904_a() != Material.field_151579_a)
        {
            AxisAlignedBB axisalignedbb = iblockstate.func_185890_d(this.field_70170_p, blockpos);

            if (axisalignedbb != Block.field_185506_k && axisalignedbb.func_186670_a(blockpos).func_72318_a(new Vec3d(this.field_70165_t, this.field_70163_u, this.field_70161_v)))
            {
                this.inGround = true;
            }
        }

        if (this.arrowShake > 0)
        {
            --this.arrowShake;
        }

        if (this.inGround)
        {
            int j = block.func_176201_c(iblockstate);

            if ((block != this.inTile || j != this.inData) && !this.field_70170_p.func_184143_b(this.func_174813_aQ().func_186662_g(0.05D)))
            {
                this.inGround = false;
                this.field_70159_w *= (double)(this.field_70146_Z.nextFloat() * 0.2F);
                this.field_70181_x *= (double)(this.field_70146_Z.nextFloat() * 0.2F);
                this.field_70179_y *= (double)(this.field_70146_Z.nextFloat() * 0.2F);
                this.ticksInGround = 0;
                this.ticksInAir = 0;
            }
            else
            {
                ++this.ticksInGround;

                if (this.ticksInGround >= timemax/2)
                {
                    this.func_70106_y();
                }
            }

            ++this.timeInGround;
        }
        else
        {
            this.timeInGround = 0;
            ++this.ticksInAir;
            Vec3d vec3d1 = new Vec3d(this.field_70165_t, this.field_70163_u, this.field_70161_v);
            Vec3d vec3d = new Vec3d(this.field_70165_t + this.field_70159_w, this.field_70163_u + this.field_70181_x, this.field_70161_v + this.field_70179_y);
            RayTraceResult raytraceresult = this.field_70170_p.func_147447_a(vec3d1, vec3d, false, true, false);
            vec3d1 = new Vec3d(this.field_70165_t, this.field_70163_u, this.field_70161_v);
            vec3d = new Vec3d(this.field_70165_t + this.field_70159_w, this.field_70163_u + this.field_70181_x, this.field_70161_v + this.field_70179_y);

            if (raytraceresult != null)
            {
                vec3d = new Vec3d(raytraceresult.field_72307_f.field_72450_a, raytraceresult.field_72307_f.field_72448_b, raytraceresult.field_72307_f.field_72449_c);
            }

            Entity entity = this.findEntityOnPath(vec3d1, vec3d);

            if (entity != null && entity != this.friend)
            {
                raytraceresult = new RayTraceResult(entity);
            }

            if (raytraceresult != null && raytraceresult.field_72308_g instanceof EntityPlayer)
            {
                EntityPlayer entityplayer = (EntityPlayer)raytraceresult.field_72308_g;

                if (this.getThrower() instanceof EntityPlayer && !((EntityPlayer)this.getThrower()).func_96122_a(entityplayer))
                {
                    raytraceresult = null;
                }
            }

            if (raytraceresult != null)
            {
            	this.onImpact(raytraceresult);
            }

            

            this.field_70165_t += this.field_70159_w;
            this.field_70163_u += this.field_70181_x;
            this.field_70161_v += this.field_70179_y;
            float f4 = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70179_y * this.field_70179_y);
            this.field_70177_z = (float)(MathHelper.func_181159_b(this.field_70159_w, this.field_70179_y) * (180D / Math.PI));

            for (this.field_70125_A = (float)(MathHelper.func_181159_b(this.field_70181_x, (double)f4) * (180D / Math.PI)); this.field_70125_A - this.field_70127_C < -180.0F; this.field_70127_C -= 360.0F)
            {
                ;
            }

            while (this.field_70125_A - this.field_70127_C >= 180.0F)
            {
                this.field_70127_C += 360.0F;
            }

            while (this.field_70177_z - this.field_70126_B < -180.0F)
            {
                this.field_70126_B -= 360.0F;
            }

            while (this.field_70177_z - this.field_70126_B >= 180.0F)
            {
                this.field_70126_B += 360.0F;
            }

            this.field_70125_A = this.field_70127_C + (this.field_70125_A - this.field_70127_C) * 0.2F;
            this.field_70177_z = this.field_70126_B + (this.field_70177_z - this.field_70126_B) * 0.2F;
            float f1 = 0.999F;
            float f2 = this.getGravityVelocity();

            if (this.func_70090_H())
            {
                for (int i = 0; i < 4; ++i)
                {
                    float f3 = 0.25F;
                    this.field_70170_p.func_175688_a(EnumParticleTypes.WATER_BUBBLE, this.field_70165_t - this.field_70159_w * 0.25D, this.field_70163_u - this.field_70181_x * 0.25D, this.field_70161_v - this.field_70179_y * 0.25D, this.field_70159_w, this.field_70181_x, this.field_70179_y);
                }

                f1 = 0.6F;
            }

            if (this.func_70026_G())
            {
                this.func_70066_B();
            }

            this.field_70159_w *= (double)f1;
            this.field_70181_x *= (double)f1;
            this.field_70179_y *= (double)f1;

            if (!this.func_189652_ae())
            {
               // this.motionY -= 0.05000000074505806D;
            	this.field_70181_x -= (double)f2 - this.gra;
            }

            this.func_70107_b(this.field_70165_t, this.field_70163_u, this.field_70161_v);
            this.func_145775_I();
        
        
        this.func_145775_I();
       
        }
        ++time;
        if(time > timemax){
        	if(!this.field_70170_p.field_72995_K){
        		//System.out.println(String.format("dead"));
        	this.func_70106_y();
        	}
        }
        double ddx = Math.abs(field_70159_w);
        double ddz = Math.abs(field_70179_y);
        if(ddx < 0.2 && ddz < 0.2){
        	if(!this.field_70170_p.field_72995_K){
        	this.func_70106_y();
        	}
        }
    }

    /**
     * Gets the amount of gravity to apply to the thrown entity with each tick.
     */
    protected float getGravityVelocity()
    {
        return 0.03F;
    }

    @Nullable
    protected Entity findEntityOnPath(Vec3d start, Vec3d end)
    {
        Entity entity = null;
        List<Entity> list = this.field_70170_p.func_175674_a(this, this.func_174813_aQ().func_72321_a(this.field_70159_w, this.field_70181_x, this.field_70179_y).func_186662_g(1.0D), ARROW_TARGETS);
        double d0 = 0.0D;

        for (int i = 0; i < list.size(); ++i)
        {
            Entity entity1 = list.get(i);

            if (entity1 != this.getThrower() || this.ticksInAir >= 5)
            {
                AxisAlignedBB axisalignedbb = entity1.func_174813_aQ().func_186662_g(0.30000001192092896D);
                RayTraceResult raytraceresult = axisalignedbb.func_72327_a(start, end);

                if (raytraceresult != null)
                {
                    double d1 = start.func_72436_e(raytraceresult.field_72307_f);

                    if (d1 < d0 || d0 == 0.0D)
                    {
                        entity = entity1;
                        d0 = d1;
                    }
                }
            }
        }

        return entity;
    }
    
    /**
     * Called when this EntityThrowable hits a block or entity.
     */
    protected abstract void onImpact(RayTraceResult result);

    public static void func_189661_a(DataFixer p_189661_0_, String p_189661_1_)
    {
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void func_70014_b(NBTTagCompound compound)
    {
        compound.func_74768_a("xTile", this.xTile);
        compound.func_74768_a("yTile", this.yTile);
        compound.func_74768_a("zTile", this.zTile);
        ResourceLocation resourcelocation = (ResourceLocation)Block.field_149771_c.func_177774_c(this.inTile);
        compound.func_74778_a("inTile", resourcelocation == null ? "" : resourcelocation.toString());
        compound.func_74774_a("shake", (byte)this.throwableShake);
        compound.func_74774_a("inGround", (byte)(this.inGround ? 1 : 0));

        if ((this.throwerName == null || this.throwerName.isEmpty()) && this.thrower instanceof EntityPlayer)
        {
            this.throwerName = this.thrower.func_70005_c_();
        }

        compound.func_74778_a("ownerName", this.throwerName == null ? "" : this.throwerName);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void func_70037_a(NBTTagCompound compound)
    {
        this.xTile = compound.func_74762_e("xTile");
        this.yTile = compound.func_74762_e("yTile");
        this.zTile = compound.func_74762_e("zTile");

        if (compound.func_150297_b("inTile", 8))
        {
            this.inTile = Block.func_149684_b(compound.func_74779_i("inTile"));
        }
        else
        {
            this.inTile = Block.func_149729_e(compound.func_74771_c("inTile") & 255);
        }

        this.throwableShake = compound.func_74771_c("shake") & 255;
        this.inGround = compound.func_74771_c("inGround") == 1;
        this.thrower = null;
        this.throwerName = compound.func_74779_i("ownerName");

        if (this.throwerName != null && this.throwerName.isEmpty())
        {
            this.throwerName = null;
        }

        this.thrower = this.getThrower();
    }

   
    
    @Nullable
    public EntityLivingBase getThrower()
    {
        if (this.thrower == null && this.throwerName != null && !this.throwerName.isEmpty())
        {
            this.thrower = this.field_70170_p.func_72924_a(this.throwerName);

            if (this.thrower == null && this.field_70170_p instanceof WorldServer)
            {
                try
                {
                    Entity entity = ((WorldServer)this.field_70170_p).func_175733_a(UUID.fromString(this.throwerName));

                    if (entity instanceof EntityLivingBase)
                    {
                        this.thrower = (EntityLivingBase)entity;
                    }
                }
                catch (Throwable var2)
                {
                    this.thrower = null;
                }
            }
        }

        return this.thrower;
    }
    
    /** 指定した座礁のブロックをChunkLoaderとして起動する */
    /*public static boolean setBlockTicket(World world, int x, int y, int z) {
        return false;
    }
    
    /**
     * ChunkLoaderに実装するinterface<br>
     * worldがロードされた時に呼ばれる。trueを返すとChunkLoaderが始まる。
     * */
    /*public interface IChunkLoaderBlock {

        public boolean canLoad(World world, int x, int y, int z);

    }*/
}

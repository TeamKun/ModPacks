package kettenkrad.entity;

import java.util.List;

import javax.annotation.Nullable;

import kettenkrad.mod_Kettenkrad;
import kettenkrad.event.KKSoundEvent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityWaterMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class EntityKettenkrad extends EntityBase
{
    public EntityKettenkrad(World worldIn)
    {
        super(worldIn);
        this.func_70105_a(2F, 1.4F);
    }

    protected void func_110147_ax()
    {
        super.func_110147_ax();
        this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(100D);
        this.func_110148_a(SharedMonsterAttributes.field_111266_c).func_111128_a(20D);
    }
    
    
    public double func_70042_X() {
		return 0.4D;//0.12D
	}
    
    public boolean func_184645_a(EntityPlayer player, EnumHand hand)
    {
    	ItemStack itemstack = player.func_184586_b(hand);
        boolean flag = !itemstack.func_190926_b();
        //if (player.isSneaking())
        {
            //return super.processInteract(player, hand);
        }
        //else
        {
        	if(flag){
        		if(itemstack != null && itemstack.func_77973_b() == Items.field_151045_i)
        		{
        			if (!player.field_71075_bZ.field_75098_d)
                    {
                        itemstack.func_190918_g(1);
                    }
        			this.setMobMode(1);
        		}
        		if (!this.field_70170_p.field_72995_K)
                {
                    player.func_184220_m(this);
                }
        	}else{
        		if(player.func_70093_af()) {
        			//if (this.getControllingPassenger() == null) 
        			{
        				
            			List<Entity> list = this.field_70170_p.func_175674_a(this, 
            					//this.getEntityBoundingBox().grow(0.20000000298023224D, -0.009999999776482582D, 0.20000000298023224D), 
            					this.func_174813_aQ().func_72314_b(0.20000000298023224D * 3, -0.009999999776482582D * 3, 0.20000000298023224D * 3), 
            					EntitySelectors.func_188442_a(this));

            	        if (!list.isEmpty())
            	        {
            	            boolean flag1 = !this.field_70170_p.field_72995_K && !(this.func_184179_bs() instanceof EntityPlayer);

            	            for (int j = 0; j < list.size(); ++j)
            	            {
            	                Entity entity = list.get(j);

            	                if (!entity.func_184196_w(this))
            	                {
            	                    if (flag1 && this.func_184188_bt().size() < 2 
            	                    		&& !entity.func_184218_aH() && entity.field_70130_N < this.field_70130_N
            	                    		&& entity instanceof EntityLivingBase && !(entity instanceof EntityWaterMob) && !(entity instanceof EntityPlayer))
            	                    {
            	                        entity.func_184220_m(this);
            	                    }
            	                    else
            	                    {
            	                        this.func_70108_f(entity);
            	                    }
            	                }
            	            }
            	        }
        			}
        		}else {
        			if(player.func_184218_aH()){
            			if (!this.field_70170_p.field_72995_K)
                        {
            				//player.openGui(mod_Kettenkrad.INSTANCE, 0, player.world, (int)player.posX, (int)player.posY, (int)player.posZ);
                        }
            		}
            		{
            			if (!this.field_70170_p.field_72995_K)
                        {
                            player.func_184220_m(this);
                        }
            		}
        		}
        		
                
        	}
            return true;
        }
    }
    
    public boolean func_70097_a(DamageSource source, float par2)
    {
    	Entity entity;
    	entity = source.func_76364_f();
    	
		if(entity != null){
			if(entity instanceof EntityPlayer && entity.func_70093_af()) {
				if (!this.field_70170_p.field_72995_K && this.func_184179_bs() != null)
				{
					this.func_184179_bs().func_184210_p();
				}
		        return false;
			}
			else {
				return super.func_70097_a(source, par2);
			}
		}else {
			return super.func_70097_a(source, par2);
		}
    }
    
    public float tro = 0;
    public int ontick = 0;
    
    public void func_70071_h_() {
		super.func_70071_h_();
		++ontick;
    	if(ontick >= 20){
    		ontick = 0;
    	}
		float f1 = this.field_70759_as * (2 * (float) Math.PI / 360);
		float sp = 0.02F;
		
		this.field_70138_W = 1.5F;
		/*if(this.onGround){
			this.motionX -= MathHelper.sin(f1) * sp * tro* 0.05;
			this.motionZ += MathHelper.cos(f1) * sp * tro* 0.05;
		}else{
			this.motionX -= MathHelper.sin(f1) * sp * tro * 1;
			this.motionZ += MathHelper.cos(f1) * sp * tro * 1;
		}
		if(this.world.isRemote) {
			this.move(MoverType.PLAYER, motionX, motionY, motionZ);
		}*/
		double x = 0;
		double y = 0;
		double z = 0;
		//if(entity.throttle >= 0.1F) 
		{
			if (this.field_70122_E) {
				x -= MathHelper.func_76126_a(f1) * sp * tro;
				z += MathHelper.func_76134_b(f1) * sp * tro;
			} else {
				x -= MathHelper.func_76126_a(f1) * sp * tro;
				z += MathHelper.func_76134_b(f1) * sp * tro;
			}
		}
		{
			this.field_70159_w = x;
			this.field_70179_y = z;
			//entity.motionY = y;
			this.func_70091_d(MoverType.PLAYER, this.field_70159_w, this.field_70181_x, this.field_70179_y);
		}
		if(tro != 0){
			if(tro > 0){
				tro = tro - 0.1F;
			}
			if(tro < 0){
				tro = tro + 0.1F;
			}
		}
		
		if(this.field_70759_as > 360F || this.field_70759_as < -360F){
			this.rotation = 0;
			this.rotationp = 0;
			this.field_70759_as = 0;
			this.field_70177_z = 0;
			this.field_70126_B = 0;
			this.field_70758_at = 0;
			this.field_70761_aq = 0;
		}
		if(this.field_70759_as > 180F){
			this.rotation = -179F;
			this.rotationp = -179F;
			this.field_70759_as = -179F;
			this.field_70177_z = -179F;
			this.field_70126_B = -179F;
			this.field_70758_at = -179F;
			this.field_70761_aq = -179F;
		}
		if(this.field_70759_as < -180F){
			this.rotation = 179F;
			this.rotationp = 179F;
			this.field_70759_as = 179F;
			this.field_70177_z = 179F;
			this.field_70126_B = 179F;
			this.field_70758_at = 179F;
			this.field_70761_aq = 179F;
		}
		
		if ((this.func_82171_bF() && this.func_184179_bs() != null) && this.func_110143_aJ() > 0.0F && mod_Kettenkrad.cfg_sound)
		{
			if(this.ontick % 5 == 0 && (this.field_70165_t != this.field_70169_q || this.field_70161_v != this.field_70166_s)){
				this.func_184185_a(KKSoundEvent.TANK, 3.0F,1F);
			}
		}
		if(tro < -1 || tro > 1){
	//		this.playSound(KKSoundEvent.TANK, 5.0F,1F);
		}
		
		if (this.func_82171_bF() && this.func_184179_bs() != null)
		{
			if(this.func_184179_bs() instanceof EntityPlayer)
			{
			EntityPlayer entitylivingbase = (EntityPlayer) this.func_184179_bs();
			this.rotation = entitylivingbase.field_70759_as;
			this.rotationp = entitylivingbase.field_70125_A;
			if(entitylivingbase.field_70759_as > 360F || entitylivingbase.field_70759_as < -360F){
				entitylivingbase.field_70759_as = 0;
				entitylivingbase.field_70177_z = 0;
				entitylivingbase.field_70126_B = 0;
				entitylivingbase.field_70758_at = 0;
				entitylivingbase.field_70761_aq = 0;
			}
			if(entitylivingbase.field_70759_as > 180F){
				entitylivingbase.field_70759_as = -179F;
				entitylivingbase.field_70177_z = -179F;
				entitylivingbase.field_70126_B = -179F;
				entitylivingbase.field_70758_at = -179F;
				entitylivingbase.field_70761_aq = -179F;
			}
			if(entitylivingbase.field_70759_as < -180F){
				entitylivingbase.field_70759_as = 179F;
				entitylivingbase.field_70177_z = 179F;
				entitylivingbase.field_70126_B = 179F;
				entitylivingbase.field_70758_at = 179F;
				entitylivingbase.field_70761_aq = 179F;
			}
			float turnspeed = 2;
			if (entitylivingbase.field_191988_bg > 0.0F) {
				if(tro < 5F){
					tro = tro + 0.2F;
				}
			}
			if (entitylivingbase.field_191988_bg < 0.0F) {
				if(tro > -2F){
					tro = tro - 0.15F;
				}
			}
			//if(tro != 0)
			{
				if (entitylivingbase.field_70702_br < 0.0F) {
					this.field_70759_as = this.field_70759_as + turnspeed;
					this.field_70177_z = this.field_70177_z + turnspeed;
					this.field_70126_B = this.field_70126_B + turnspeed;
					this.field_70758_at = this.field_70758_at + turnspeed;
				}
				if (entitylivingbase.field_70702_br > 0.0F) {
					this.field_70759_as = this.field_70759_as - turnspeed;
					this.field_70177_z = this.field_70177_z - turnspeed;
					this.field_70126_B = this.field_70126_B - turnspeed;
					this.field_70758_at = this.field_70758_at - turnspeed;
				}
			}
			
			if(this.getMobMode() == 1)
			{
				if(entitylivingbase.field_70733_aJ > 0){
					{
						this.server1 = true;
					}
				}
				{
					++cooltime;
			    }
				
				if(server1){
					if(cooltime >= 1){
						{
							this.field_70170_p.func_184148_a((EntityPlayer)null, entitylivingbase.field_70165_t, entitylivingbase.field_70163_u, entitylivingbase.field_70161_v,
				        			KKSoundEvent.Fire_Bullet, SoundCategory.NEUTRAL, 1.0F, 1.0F);
							double ix = 0;
				    		double iz = 0;
							float f11 = this.field_70759_as * (2 * (float) Math.PI / 360);
				    		float f21 = this.field_70125_A * (2 * (float) Math.PI / 360);
				    			ix -= MathHelper.func_76126_a(f11) * -0.6;
				    			iz += MathHelper.func_76134_b(f11) * -0.6;
				    			ix -= MathHelper.func_76126_a(f11-1.3F) * -0.5;
				    			iz += MathHelper.func_76134_b(f11-1.3F) * -0.5;
				    			Vec3d looked = entitylivingbase.func_70040_Z();
				    		    double yy = looked.field_72448_b * 1.5;
							KKEntityBullet entitysnowball = new KKEntityBullet(this.field_70170_p, entitylivingbase,8,4,10);
							entitysnowball.friend = this;
							entitysnowball.func_70012_b(this.field_70165_t + ix, this.field_70163_u + 1.8D, this.field_70161_v + iz, 
									entitylivingbase.field_70177_z, entitylivingbase.field_70125_A);
							{
								entitysnowball.setHeadingFromThrower(entitylivingbase, entitylivingbase.field_70125_A - 5F, entitylivingbase.field_70177_z, 0.0F, 2.5F, 2.0F);
							}
				            
				            if (!this.field_70170_p.field_72995_K)
					        {
				               this.field_70170_p.func_72838_d(entitysnowball);
				            }
				            //this.world.spawnParticle(EnumParticleTypes.CLOUD,this.posX + ix, this.posY + yy +2.5, this.posZ + iz, 0.0D, 0.0D, 0.0D, new int[0]);
						}
			            cooltime = 0;
					}
					this.server1 = false;
				}
			}
			
			
			}//player
		}
		
		
    }
   public void func_70108_f(Entity entityIn)
   {
       if (entityIn instanceof EntityKettenkrad)
       {
           if (entityIn.func_174813_aQ().field_72338_b < this.func_174813_aQ().field_72337_e)
           {
               super.func_70108_f(entityIn);
           }
       }
       else if (entityIn.func_174813_aQ().field_72338_b <= this.func_174813_aQ().field_72338_b)
       {
           super.func_70108_f(entityIn);
       }
   }
   
   protected boolean func_184219_q(Entity passenger)
   {
       return this.func_184188_bt().size() < 2;
   }
   
   public void func_184232_k(Entity passenger)
   {
       if (this.func_184196_w(passenger))
       {
           float f = 0.0F;
           float f1 = (float)((this.field_70128_L ? 0.009999999776482582D : this.func_70042_X()) + passenger.func_70033_W());

           if (this.func_184188_bt().size() > 1)
           {
               int i = this.func_184188_bt().indexOf(passenger);

               if (i == 0)
               {
                   f = 0.2F;
               }
               else
               {
                   f = -1.2F;
               }

               if (passenger instanceof EntityAnimal)
               {
                   f = (float)((double)f + 0.2D);
               }
           }

           Vec3d vec3d = (new Vec3d((double)f, 0.0D, 0.0D)).func_178785_b(-this.field_70177_z * 0.017453292F - ((float)Math.PI / 2F));
           passenger.func_70107_b(this.field_70165_t + vec3d.field_72450_a, this.field_70163_u + (double)f1, this.field_70161_v + vec3d.field_72449_c);
         //  passenger.rotationYaw += this.rotationYaw;
          // passenger.setRotationYawHead(passenger.getRotationYawHead() + this.rotationYaw);
           this.applyYawToEntity(passenger);

           if (passenger instanceof EntityAnimal && this.func_184188_bt().size() > 1)
           {
               int j = passenger.func_145782_y() % 2 == 0 ? 90 : 270;
               passenger.func_181013_g(((EntityAnimal)passenger).field_70761_aq + (float)j);
               passenger.func_70034_d(passenger.func_70079_am() + (float)j);
           }
       }
   }

   /**
    * Applies this boat's yaw to the given entity. Used to update the orientation of its passenger.
    */
   protected void applyYawToEntity(Entity entityToUpdate)
   {
       entityToUpdate.func_181013_g(this.field_70177_z);
       float f = MathHelper.func_76142_g(entityToUpdate.field_70177_z - this.field_70177_z);
       float f1 = MathHelper.func_76131_a(f, -105.0F, 105.0F);
       entityToUpdate.field_70126_B += f1 - f;
       entityToUpdate.field_70177_z += f1 - f;
       entityToUpdate.func_70034_d(entityToUpdate.field_70177_z);
   }

    @Nullable
    protected SoundEvent func_184639_G()
    {
        return null;
    }

    @Nullable
    protected SoundEvent getHurtSound()
    {
        return null;
    }

    @Nullable
    protected SoundEvent func_184615_bR()
    {
        return null;
    }
    
}

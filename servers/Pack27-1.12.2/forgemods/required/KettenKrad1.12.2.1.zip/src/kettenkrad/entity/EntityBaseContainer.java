package kettenkrad.entity;

import java.util.Random;

import javax.annotation.Nullable;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackDataLists;
import net.minecraft.world.ILockableContainer;
import net.minecraft.world.LockCode;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.storage.loot.ILootContainer;
import net.minecraft.world.storage.loot.LootContext;
import net.minecraft.world.storage.loot.LootTable;

public abstract class EntityBaseContainer extends EntityCreature implements ILockableContainer, ILootContainer, IAnimals
{
    private NonNullList<ItemStack> minecartContainerItems = NonNullList.<ItemStack>func_191197_a(36, ItemStack.field_190927_a);
    /**
     * When set to true, the minecart will drop all items when setDead() is called. When false (such as when travelling
     * dimensions) it preserves its contents.
     */
    public boolean dropContentsWhenDead = true;
    private ResourceLocation lootTable;
    private long lootTableSeed;

    public EntityBaseContainer(World worldIn)
    {
        super(worldIn);
    }

    public EntityBaseContainer(World worldIn, double x, double y, double z)
    {
        super(worldIn);
    }

    public void killMinecart(DamageSource source)
    {
        //super.killMinecart(source);

        if (this.field_70170_p.func_82736_K().func_82766_b("doEntityDrops"))
        {
            InventoryHelper.func_180176_a(this.field_70170_p, this, this);
        }
    }

    public boolean func_191420_l()
    {
        for (ItemStack itemstack : this.minecartContainerItems)
        {
            if (!itemstack.func_190926_b())
            {
                return false;
            }
        }

        return true;
    }

    /**
     * Returns the stack in the given slot.
     */
    public ItemStack func_70301_a(int index)
    {
        this.addLoot((EntityPlayer)null);
        return this.minecartContainerItems.get(index);
    }

    /**
     * Removes up to a specified number of items from an inventory slot and returns them in a new stack.
     */
    public ItemStack func_70298_a(int index, int count)
    {
        this.addLoot((EntityPlayer)null);
        return ItemStackHelper.func_188382_a(this.minecartContainerItems, index, count);
    }

    /**
     * Removes a stack from the given slot and returns it.
     */
    public ItemStack func_70304_b(int index)
    {
        this.addLoot((EntityPlayer)null);
        ItemStack itemstack = this.minecartContainerItems.get(index);

        if (itemstack.func_190926_b())
        {
            return ItemStack.field_190927_a;
        }
        else
        {
            this.minecartContainerItems.set(index, ItemStack.field_190927_a);
            return itemstack;
        }
    }

    /**
     * Sets the given item stack to the specified slot in the inventory (can be crafting or armor sections).
     */
    public void func_70299_a(int index, ItemStack stack)
    {
        this.addLoot((EntityPlayer)null);
        this.minecartContainerItems.set(index, stack);

        if (!stack.func_190926_b() && stack.func_190916_E() > this.func_70297_j_())
        {
            stack.func_190920_e(this.func_70297_j_());
        }
    }

    /**
     * For tile entities, ensures the chunk containing the tile entity is saved to disk later - the game won't think it
     * hasn't changed and skip it.
     */
    public void func_70296_d()
    {
    }

    /**
     * Don't rename this method to canInteractWith due to conflicts with Container
     */
    public boolean func_70300_a(EntityPlayer player)
    {
        if (this.field_70128_L)
        {
            return false;
        }
        else
        {
            return player.func_70032_d(this) <= 64.0D;
        }
    }

    public void func_174889_b(EntityPlayer player)
    {
    }

    public void func_174886_c(EntityPlayer player)
    {
    }

    /**
     * Returns true if automation is allowed to insert the given stack (ignoring stack size) into the given slot. For
     * guis use Slot.isItemValid
     */
    public boolean func_94041_b(int index, ItemStack stack)
    {
        return true;
    }

    /**
     * Returns the maximum stack size for a inventory slot. Seems to always be 64, possibly will be extended.
     */
    public int func_70297_j_()
    {
        return 64;
    }

    @Nullable
    public Entity func_184204_a(int dimensionIn)
    {
        this.dropContentsWhenDead = false;
        return super.func_184204_a(dimensionIn);
    }

    /**
     * Will get destroyed next tick.
     */
    public void func_70106_y()
    {
        if (this.dropContentsWhenDead)
        {
            InventoryHelper.func_180176_a(this.field_70170_p, this, this);
        }

        super.func_70106_y();
    }

    /**
     * Sets whether this entity should drop its items when setDead() is called. This applies to container minecarts.
     */
    public void func_184174_b(boolean dropWhenDead)
    {
        this.dropContentsWhenDead = dropWhenDead;
    }

    public static void addDataFixers(DataFixer p_190574_0_, Class<?> p_190574_1_)
    {
        p_190574_0_.func_188258_a(FixTypes.ENTITY, new ItemStackDataLists(p_190574_1_, new String[] {"Items"}));
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void func_70014_b(NBTTagCompound compound)
    {
        super.func_70014_b(compound);

        if (this.lootTable != null)
        {
            compound.func_74778_a("LootTable", this.lootTable.toString());

            if (this.lootTableSeed != 0L)
            {
                compound.func_74772_a("LootTableSeed", this.lootTableSeed);
            }
        }
        else
        {
            ItemStackHelper.func_191282_a(compound, this.minecartContainerItems);
        }
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void func_70037_a(NBTTagCompound compound)
    {
        super.func_70037_a(compound);
        this.minecartContainerItems = NonNullList.<ItemStack>func_191197_a(this.func_70302_i_(), ItemStack.field_190927_a);

        if (compound.func_150297_b("LootTable", 8))
        {
            this.lootTable = new ResourceLocation(compound.func_74779_i("LootTable"));
            this.lootTableSeed = compound.func_74763_f("LootTableSeed");
        }
        else
        {
            ItemStackHelper.func_191283_b(compound, this.minecartContainerItems);
        }
    }

    protected void applyDrag()
    {
        float f = 0.98F;

        if (this.lootTable == null)
        {
            int i = 15 - Container.func_94526_b(this);
            f += (float)i * 0.001F;
        }

        this.field_70159_w *= (double)f;
        this.field_70181_x *= 0.0D;
        this.field_70179_y *= (double)f;
    }

    public int func_174887_a_(int id)
    {
        return 0;
    }

    public void func_174885_b(int id, int value)
    {
    }

    public int func_174890_g()
    {
        return 0;
    }

    public boolean func_174893_q_()
    {
        return false;
    }

    public void func_174892_a(LockCode code)
    {
    }

    public LockCode func_174891_i()
    {
        return LockCode.field_180162_a;
    }

    /**
     * Adds loot to the minecart's contents.
     */
    public void addLoot(@Nullable EntityPlayer player)
    {
        if (this.lootTable != null)
        {
            LootTable loottable = this.field_70170_p.func_184146_ak().func_186521_a(this.lootTable);
            this.lootTable = null;
            Random random;

            if (this.lootTableSeed == 0L)
            {
                random = new Random();
            }
            else
            {
                random = new Random(this.lootTableSeed);
            }

            LootContext.Builder lootcontext$builder = new LootContext.Builder((WorldServer)this.field_70170_p);

            if (player != null)
            {
                lootcontext$builder.func_186469_a(player.func_184817_da());
            }

            loottable.func_186460_a(this, random, lootcontext$builder.func_186471_a());
        }
    }

    public net.minecraftforge.items.IItemHandler itemHandler = new net.minecraftforge.items.wrapper.InvWrapper(this);

    @Override
    @Nullable
    public <T> T getCapability(net.minecraftforge.common.capabilities.Capability<T> capability, @Nullable net.minecraft.util.EnumFacing facing)
    {
        if (capability == net.minecraftforge.items.CapabilityItemHandler.ITEM_HANDLER_CAPABILITY)
        {
            return (T) itemHandler;
        }
        return super.getCapability(capability, facing);
    }

    @Override
    public boolean hasCapability(net.minecraftforge.common.capabilities.Capability<?> capability, @Nullable net.minecraft.util.EnumFacing facing)
    {
        return capability == net.minecraftforge.items.CapabilityItemHandler.ITEM_HANDLER_CAPABILITY || super.hasCapability(capability, facing);
    }

    public void func_174888_l()
    {
        this.addLoot((EntityPlayer)null);
        this.minecartContainerItems.clear();
    }

    public void setLootTable(ResourceLocation lootTableIn, long lootTableSeedIn)
    {
        this.lootTable = lootTableIn;
        this.lootTableSeed = lootTableSeedIn;
    }

    public ResourceLocation func_184647_J()
    {
        return this.lootTable;
    }
}

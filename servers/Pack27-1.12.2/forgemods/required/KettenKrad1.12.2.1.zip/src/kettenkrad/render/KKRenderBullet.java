package kettenkrad.render;

import kettenkrad.entity.KKEntityBullet;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class KKRenderBullet extends Render<KKEntityBullet>
{
    private static final ResourceLocation arrowTextures = new ResourceLocation("kettenkrad:textures/entity/bullet.png");
    private static final String __OBFID = "CL_00000978";
    //private static final ResourceLocation skeletonTexturesz = new ResourceLocation("battlemachine:textures/model/mbm01.png");
    //private static final IModelCustom tankk = AdvancedModelLoader.loadModel(new ResourceLocation("battlemachine:textures/model/mbm01.obj"));

    public KKRenderBullet(RenderManager renderManagerIn)
    {
        super(renderManagerIn);
    }

    /**
     * Actually renders the given argument. This is a synthetic bridge method, always casting down its argument and then
     * handing it off to a worker function which does the actual work. In all probabilty, the class Render is generic
     * (Render<T extends Entity>) and this method has signature public void func_76986_a(T entity, double d, double d1,
     * double d2, float f, float f1). But JAD is pre 1.5 so doe
     *  
     * @param entityYaw The yaw rotation of the passed entity
     */
    public void func_76986_a(KKEntityBullet entity, double x, double y, double z, float entityYaw, float partialTicks)
    {
        this.func_180548_c(entity);
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)x, (float)y, (float)z);
        GlStateManager.func_179114_b(entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * partialTicks - 90.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.func_179114_b(entity.field_70127_C + (entity.field_70125_A - entity.field_70127_C) * partialTicks, 0.0F, 0.0F, 1.0F);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferbuilder = tessellator.func_178180_c();
        int i = 0;
        float f = 0.0F;
        float f1 = 0.5F;
        float f2 = (float)(0 + i * 10) / 32.0F;
        float f3 = (float)(5 + i * 10) / 32.0F;
        float f4 = 0.0F;
        float f5 = 0.15625F;
        float f6 = (float)(5 + i * 10) / 32.0F;
        float f7 = (float)(10 + i * 10) / 32.0F;
        float f8 = 0.05625F;
        GlStateManager.func_179091_B();
        //float f9 = (float)entity.arrowShake - partialTicks;

        /*if (f9 > 0.0F)
        {
            float f10 = -MathHelper.sin(f9 * 3.0F) * f9;
            GlStateManager.rotate(f10, 0.0F, 0.0F, 1.0F);
        }*/

        GlStateManager.func_179114_b(45.0F, 1.0F, 0.0F, 0.0F);
        GlStateManager.func_179152_a(f8, f8, f8);
        GlStateManager.func_179109_b(-4.0F, 0.0F, 0.0F);
        GlStateManager.func_187432_a(f8, 0.0F, 0.0F);
        bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferbuilder.func_181662_b(-7.0D, -2.0D, -2.0D).func_187315_a(0.0D, 0.15625D).func_181675_d();
        bufferbuilder.func_181662_b(-7.0D, -2.0D, 2.0D).func_187315_a(0.15625D, 0.15625D).func_181675_d();
        bufferbuilder.func_181662_b(-7.0D, 2.0D, 2.0D).func_187315_a(0.15625D, 0.3125D).func_181675_d();
        bufferbuilder.func_181662_b(-7.0D, 2.0D, -2.0D).func_187315_a(0.0D, 0.3125D).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_187432_a(-f8, 0.0F, 0.0F);
        bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferbuilder.func_181662_b(-7.0D, 2.0D, -2.0D).func_187315_a(0.0D, 0.15625D).func_181675_d();
        bufferbuilder.func_181662_b(-7.0D, 2.0D, 2.0D).func_187315_a(0.15625D, 0.15625D).func_181675_d();
        bufferbuilder.func_181662_b(-7.0D, -2.0D, 2.0D).func_187315_a(0.15625D, 0.3125D).func_181675_d();
        bufferbuilder.func_181662_b(-7.0D, -2.0D, -2.0D).func_187315_a(0.0D, 0.3125D).func_181675_d();
        tessellator.func_78381_a();

        for (int j = 0; j < 4; ++j)
        {
        	GlStateManager.func_179114_b(90.0F, 1.0F, 0.0F, 0.0F);
            GlStateManager.func_187432_a(0.0F, 0.0F, f8);
            bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
            bufferbuilder.func_181662_b(-8.0D, -2.0D, 0.0D).func_187315_a(0.0D, 0.0D).func_181675_d();
            bufferbuilder.func_181662_b(8.0D, -2.0D, 0.0D).func_187315_a(0.5D, 0.0D).func_181675_d();
            bufferbuilder.func_181662_b(8.0D, 2.0D, 0.0D).func_187315_a(0.5D, 0.15625D).func_181675_d();
            bufferbuilder.func_181662_b(-8.0D, 2.0D, 0.0D).func_187315_a(0.0D, 0.15625D).func_181675_d();
            tessellator.func_78381_a();
        }

        if (this.field_188301_f)
        {
            GlStateManager.func_187417_n();
            GlStateManager.func_179119_h();
        }

        GlStateManager.func_179101_C();
        GlStateManager.func_179145_e();
        GlStateManager.func_179121_F();
        super.func_76986_a(entity, x, y, z, entityYaw, partialTicks);
        
        /*GL11.glPushMatrix();//glstart
        GlStateManager.translate((float)x, (float)y, (float)z);
		GL11.glRotatef(180F, 0.0F, 1.0F, 0.0F);
		GL11.glEnable(GL12.GL_RESCALE_NORMAL);
			tankk.renderPart("mat1");
			tankk.renderPart("mat4");
		GL11.glDisable(GL12.GL_RESCALE_NORMAL);
		GL11.glPopMatrix();//glend*/
    }

    /**
     * Returns the location of an entity's texture. Doesn't seem to be called unless you call Render.bindEntityTexture.
     */
    protected ResourceLocation func_110775_a(KKEntityBullet entity)
    {
        return arrowTextures;
    }

}

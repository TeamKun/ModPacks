package kettenkrad.render;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

import kettenkrad.entity.EntityKettenkrad;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;

@SideOnly(Side.CLIENT)
public class RenderKettenkrad extends Render<EntityKettenkrad>
{
    private static final ResourceLocation boatTextures = new ResourceLocation("kettenkrad:textures/entity/kettenkrad.png");
    private static final IModelCustom tankk = AdvancedModelLoader.loadModel(new ResourceLocation("kettenkrad:textures/entity/kettenkrad.mqo"));
    /** instance of ModelBoat for rendering */

    public RenderKettenkrad(RenderManager renderManagerIn)
    {
        super(renderManagerIn);
        this.field_76989_e = 0.5F;
    }

    /**
     * Actually renders the given argument. This is a synthetic bridge method, always casting down its argument and then
     * handing it off to a worker function which does the actual work. In all probabilty, the class Render is generic
     * (Render<T extends Entity>) and this method has signature public void func_76986_a(T entity, double d, double d1,
     * double d2, float f, float f1). But JAD is pre 1.5 so doe
     */
    float iii;
    public void func_76986_a(EntityKettenkrad entity, double x, double y, double z, float entityYaw, float partialTicks)
    {
        this.func_180548_c(entity);
		
		
		GL11.glPushMatrix();//glstart
		GL11.glTranslatef((float) x, (float) y, (float) z);
		GL11.glRotatef(180F, 0.0F, 1.0F, 0.0F);
		GL11.glEnable(GL12.GL_RESCALE_NORMAL);
		if(entity.deathTicks > 0){
			GL11.glColor4f(0.1F, 0.1F, 0.1F, 1F);
		}else{
			GL11.glColor4f(1F, 1F, 1F, 1F);
		}
		GL11.glRotatef(180.0F - entityYaw, 0.0F, 1.0F, 0.0F);
			//tankk.renderPart("mat1");
		tankk.renderPart("body");
		if(entity.getMobMode() == 1){
			tankk.renderPart("gun1");
		}
		{
			GL11.glPushMatrix();//glstart
			GL11.glTranslatef(0, 0.9F, 0.9F);
			float rote = entity.field_70759_as / ((float) Math.PI);
			float rote_p = entity.rotation / ((float) Math.PI);
			/*if(entity.rotation - entity.rotationYawHead > 60){
				GL11.glRotatef(60 - (180.0F - entityYaw), 0.0F, 1.0F, 0.0F);
			}else if(entity.rotation - entity.rotationYawHead < -60){
				GL11.glRotatef(180.0F - (entity.rotation) - (180.0F - entityYaw), 0.0F, 1.0F, 0.0F);
			}else{
				GL11.glRotatef(180.0F - entity.rotation - (180.0F - entityYaw), 0.0F, 1.0F, 0.0F);
			}*/
			if (entity.func_82171_bF() && entity.func_184179_bs() != null)
			{
				if(entity.func_184179_bs() instanceof EntityPlayer)
				{
					EntityPlayer entitylivingbase = (EntityPlayer) entity.func_184179_bs();
					if (entitylivingbase.field_70702_br < 0.0F) {
						GL11.glRotatef((180.0F - entity.field_70177_z - 30) - (180.0F - entityYaw), 0.0F, 1.0F, 0.0F);
					}
					if (entitylivingbase.field_70702_br > 0.0F) {
						GL11.glRotatef((180.0F - entity.field_70177_z + 30) - (180.0F - entityYaw), 0.0F, 1.0F, 0.0F);
					}
					
				}
			}
			GL11.glTranslatef(-0, -0.9F, -0.9F);
			tankk.renderPart("hand");
			GL11.glPopMatrix();//glend
			
			GL11.glPushMatrix();//glstart
			GL11.glTranslatef(-0.5F, 1.8F, -0.6F);
			GL11.glRotatef(180.0F - entity.rotation - (180.0F - entityYaw), 0.0F, 1.0F, 0.0F);
			GL11.glRotatef(entity.rotationp, 1.0F, 0.0F, 0.0F);
			GL11.glTranslatef(0.5F, -1.8F, 0.6F);
			if(entity.getMobMode() == 1){
				tankk.renderPart("gun");
			}
			GL11.glPopMatrix();//glend
		}
		//tankk.renderPart("obj1");
		GL11.glDisable(GL12.GL_RESCALE_NORMAL);
		GL11.glPopMatrix();//glend
		
        super.func_76986_a(entity, x, y, z, entityYaw, partialTicks);
    }
    
    /**
     * Returns the location of an entity's texture. Doesn't seem to be called unless you call Render.bindEntityTexture.
     */
    protected ResourceLocation func_110775_a(EntityKettenkrad entity)
    {
        return boatTextures;
    }
    
    protected void renderLivingAt(EntityKettenkrad entityLivingBaseIn, double x, double y, double z)
    {
        GlStateManager.func_179109_b((float)x, (float)y, (float)z);
    }
    protected float handleRotationFloat(EntityKettenkrad livingBase, float partialTicks)
    {
        return (float)livingBase.field_70173_aa + partialTicks;
    }
}

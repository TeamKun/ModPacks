package kettenkrad;







import java.io.File;

import kettenkrad.entity.EntityKettenkrad;
import kettenkrad.entity.KKEntityBullet;
import kettenkrad.event.KKEventsGunRender;
import kettenkrad.event.KKSoundEvent;
import kettenkrad.items.ItemKettenkrad;
import kettenkrad.items.ItemRifle;
import kettenkrad.items.KKItemGunBase;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLConstructionEvent;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;

//import net.minecraftforge.fml.common.registry.LanguageRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;


@Mod(
		modid	= mod_Kettenkrad.MOD_ID,
		name	= mod_Kettenkrad.MOD_ID,
		version	= "1.12.2", 
		acceptedMinecraftVersions="[1.12.2]", 
		useMetadata=true
		)
@EventBusSubscriber
public class mod_Kettenkrad 
{
	@SidedProxy(clientSide = "kettenkrad.ClientProxyKK", serverSide = "kettenkrad.CommonSideProxyKK")
	public static CommonSideProxyKK proxy;
	public static final String MOD_ID = "kettenkrad";
	@Mod.Instance(mod_Kettenkrad.MOD_ID)
	 
    public static mod_Kettenkrad INSTANCE;
	
	public static Item kettenkrad;
	public static Item kk_rifle;
	
	protected static File configFile;
	public static boolean cfg_sound = true;
	
	@Mod.EventHandler
    public void construct(FMLConstructionEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
     //   KKSoundEvent.registerSounds();
       
    }

	@SubscribeEvent
    protected static void registerItems(RegistryEvent.Register<Item> event){
		event.getRegistry().register(kettenkrad);
		event.getRegistry().register(kk_rifle);
	}
	
	public void InIt() {
		kettenkrad	= new ItemKettenkrad().func_77655_b("kettenkrad").func_77637_a(CreativeTabs.field_78029_e)
        		.setRegistryName(MOD_ID, "kettenkrad");
		kk_rifle = new ItemRifle().func_77655_b("rifle").func_77637_a(CreativeTabs.field_78037_j)
				.setRegistryName(MOD_ID, "rifle");
		{
			KKItemGunBase gun = (KKItemGunBase) kk_rifle;
			if (FMLCommonHandler.instance().getSide().isClient()) {
				gun.obj_model = AdvancedModelLoader.loadModel(new ResourceLocation("kettenkrad:textures/model/rifle.mqo"));
				gun.arm_model = AdvancedModelLoader.loadModel(new ResourceLocation("kettenkrad:textures/model/arm.obj"));
			}
			//gun.obj_models = "kettenkrad:textures/model/rifle.obj";
			//gun.arm_models = "kettenkrad:textures/model/arm.obj";
			gun.obj_tex = "kettenkrad:textures/model/rifle.png";
			gun.func_77656_e(4);
			gun.powor = 12;
			gun.speed = 4;
			gun.bure = 1.0F;
			gun.recoil = 3D;
			gun.reloadtime = 50;
			gun.cycle = 2;
			gun.scopezoombase = 1.5F;
			gun.cocktime = 15;
			gun.soundsp = 1.0F;
			
			gun.obj_true = true;
			gun.scopezoom = 1.5F;
			
			gun.model_y = -2.0F;
			gun.model_y_ads = -1.2F;
			
			gun.mat25rotationz = -90;
			gun.cock_left = false;
			gun.arm_r_posy = - 0.5F;
			gun.arm_l_posx = - 0F;
			gun.arm_l_posy = - 0.6F;
			gun.arm_l_posz = + 1.5F;
			{
				
				gun.mat_rk_25 = 3;
				gun.mat_r_25 = new String[]{
			    		"mat25", "0", "10", 
			    		"0", "0.75F", "1", //pos
			    		"0", "0", "0F", //off
			    		"0", "0", "-0", //roteoff
			    		"0", "0", "-1", //move
			    		"0", "0", "0", "0.07F","0",
			    		"mat25", "10", "30", 
			    		"0", "0.75F", "1", //pos
			    		"0", "0F", "-0.7F", //off
			    		"0", "0", "-90", //roteoff
			    		"0", "0", "0", //move
			    		"0", "0", "0", "0F","0",
			    		"mat25", "30", "40", 
			    		"0", "0.75F", "1", //pos
			    		"0", "0F", "-0.7F", //off
			    		"0", "0", "-0", //roteoff
			    		"0", "0", "1", //move
			    		"0", "0", "0", "0.07F","0"
			    		};
				
				gun.mat_rk_3 = 2;
				gun.mat_r_3 = new String[]{
			    		"mat25", "0", "10", 
			    		"0", "0", "0", //pos
			    		"0", "20", "0", //off
			    		"0", "0", "0", //roteoff
			    		"0", "0", "0", //move
			    		"0", "0", "0", "0F","0",
			    		"mat25", "10", "30", 
			    		"0", "0", "0", //pos
			    		"0", "2F", "0", //off
			    		"0", "0", "0", //roteoff
			    		"0", "1", "0", //move
			    		"0", "0", "0", "-0.1F","0"
			    		};
				
				gun.mat_rk_rightarm = 3;
				gun.mat_r_rightarm = new String[]{
			    		"rightarm", "0", "10", 
			    		"0", "0", "0", //pos
			    		"0", "0.8F", "0", //off
			    		"0", "0", "-1", //roteoff
			    		"0", "0", "-1", //move
			    		"0", "0", "0", "0.07F","0",
			    		"rightarm", "10", "30", 
			    		"0", "0", "0", //pos
			    		"-1", "3F", "2F", //off
			    		"0", "0", "0", //roteoff
			    		"0", "1", "0", //move
			    		"0", "0", "0", "-0.1F","0",
			    		"rightarm", "30", "40", 
			    		"0", "0", "0", //pos
			    		"0", "0.8F", "-0.7F", //off
			    		"0", "0", "0", //roteoff
			    		"0", "0", "1", //move
			    		"0", "0", "0", "0.07F","0"
			    		};
				gun.mat_rk_leftarm = 1;
				gun.mat_r_leftarm = new String[]{
			    		"rightarm", "0", "50", 
			    		"0", "0", "0", //pos
			    		"0", "-0.6F", "1.5F", //off
			    		"0", "0", "0", //roteoff
			    		"0", "0", "0", //move
			    		"0", "0", "0", "0.0F","0"
			    		};
				
			}
		}
	}
	
	@SubscribeEvent
    @SideOnly(Side.CLIENT)
    public void registerModels(ModelRegistryEvent event) {
		{
			ModelLoader.setCustomModelResourceLocation(kk_rifle, 0, new ModelResourceLocation(new ResourceLocation(mod_Kettenkrad.MOD_ID, "rifle"), 
					"inventory"));
			ModelLoader.setCustomModelResourceLocation(kettenkrad, 0, new ModelResourceLocation(new ResourceLocation(mod_Kettenkrad.MOD_ID, "kettenkrad"), 
					"inventory"));
		}
	}
	
	@SubscribeEvent
	public static void registerSoundEvents(RegistryEvent.Register<SoundEvent> event) {	
		{
			final ResourceLocation soundID = new ResourceLocation(mod_Kettenkrad.MOD_ID, "kettenkrad.fire");
			event.getRegistry().register(new SoundEvent(soundID).setRegistryName(soundID));		
		}
		{
			final ResourceLocation soundID = new ResourceLocation(mod_Kettenkrad.MOD_ID, "kettenkrad.reload");
			event.getRegistry().register(new SoundEvent(soundID).setRegistryName(soundID));		
		}
		{
			final ResourceLocation soundID = new ResourceLocation(mod_Kettenkrad.MOD_ID, "kettenkrad.tank");
			event.getRegistry().register(new SoundEvent(soundID).setRegistryName(soundID));		
		}
		
	}
	
	
	@Mod.EventHandler
	public void preInit(net.minecraftforge.fml.common.event.FMLPreInitializationEvent pEvent) {
		KKSoundEvent.registerSounds();
		InIt();
		configFile = pEvent.getSuggestedConfigurationFile();
		Configuration lconf = new Configuration(configFile);
		lconf.load();
		cfg_sound	= lconf.get("sound", "cfg_sound", true).getBoolean(true);
		lconf.save();
	}
	
	
	
	@Mod.EventHandler
	public void init(FMLInitializationEvent pEvent) {
		int D = Short.MAX_VALUE;
		 EntityRegistry.registerModEntity(new ResourceLocation("KKBullet"), KKEntityBullet.class, "KKBullet", 180, this, 128, 5, true);
		 EntityRegistry.registerModEntity(new ResourceLocation("Kettenkrad"), EntityKettenkrad.class, "Kettenkrad", 181, this, 128, 5, true);
		 if(pEvent.getSide().isClient()) {
			 MinecraftForge.EVENT_BUS.register(new KKEventsGunRender());
		 }
			FMLCommonHandler.instance().bus().register(this);
			proxy.reisterRenderers();
			proxy.registerTileEntity();
			proxy.InitRendering();
		//NetworkRegistry.INSTANCE.registerGuiHandler(this, new GuiHandlerKK());
	}
	
}

	
	

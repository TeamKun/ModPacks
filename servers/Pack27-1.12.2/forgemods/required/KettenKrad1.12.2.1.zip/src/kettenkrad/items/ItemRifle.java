package kettenkrad.items;

import java.util.List;

import com.google.common.collect.Multimap;

import kettenkrad.entity.KKEntityBullet;
import kettenkrad.event.KKSoundEvent;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.stats.StatList;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.World;


	public class ItemRifle extends KKItemGunBase {
		private float attackDamage;
		public static String ads;
		
		public ItemRifle() {
			super();
		}
		

		public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4)
		  {
			String powor = String.valueOf(this.powor + EnchantmentHelper.func_77506_a(Enchantments.field_185309_u, par1ItemStack));
			String speed = String.valueOf(this.speed);
			String bure = String.valueOf(this.bure);
			String recoil = String.valueOf(this.recoil);
			String retime = String.valueOf(this.reloadtime);
            String nokori = String.valueOf(func_77612_l() - par1ItemStack.func_77952_i());
			
			par3List.add(TextFormatting.RED + "RemainingBullet " + I18n.func_74838_a(nokori));
		    par3List.add(TextFormatting.WHITE + "FireDamege " + "+" + I18n.func_74838_a(powor));
		    par3List.add(TextFormatting.WHITE + "BlletSpeed " + "+" + I18n.func_74838_a(speed));
		    par3List.add(TextFormatting.WHITE + "BlletSpread "+ "+" + I18n.func_74838_a(bure));
		    par3List.add(TextFormatting.WHITE + "Recoil " + "+" + I18n.func_74838_a(recoil));
		    par3List.add(TextFormatting.YELLOW + "ReloadTime " + "+" + I18n.func_74838_a(retime));
		   // par3List.add(EnumChatFormatting.YELLOW + "MagazimeType " + StatCollector.translateToLocal("ARMagazine"));
		    if(!(this.scopezoom == 1.0f)){
				String scopezoom = String.valueOf(this.scopezoom);
				par3List.add(TextFormatting.WHITE + "ScopeZoom " + "x" + I18n.func_74838_a(scopezoom));
			}
		   // par3List.add(TextFormatting.WHITE + "FirePowor " + I18n.translateToLocal("600"));
		  }
		
		
		
		public void func_77663_a(ItemStack itemstack, World world, Entity entity, int i, boolean flag)
	    {
			{
				EntityPlayer entityplayer = (EntityPlayer)entity;
				int s;
				int li = func_77612_l() - itemstack.func_77952_i();
				boolean lflag = cycleBolt(itemstack);
				boolean var5 = entityplayer.field_71075_bZ.field_75098_d || EnchantmentHelper.func_77506_a(Enchantments.field_185312_x, itemstack) > 0;
				Item item = itemstack.func_77973_b();
				ItemStack item_m = entityplayer.func_184614_ca();
				ItemStack item_o = entityplayer.func_184592_cb();
				
				NBTTagCompound nbt = itemstack.func_77978_p();
				boolean recoiled = nbt.func_74767_n("Recoiled");
				int recoiledtime = nbt.func_74762_e("RecoiledTime");
				{
					boolean cocking = nbt.func_74767_n("Cocking");
					int cockingtime = nbt.func_74762_e("CockingTime");
					if(!cocking && flag){
						++cockingtime;
						nbt.func_74768_a("CockingTime", cockingtime);
						if(cockingtime == 2 && flag && !this.semi){
							//world.playSoundAtEntity(entityplayer, this.soundcock, 1.0F, 1.0F);
							world.func_184148_a((EntityPlayer)null, entityplayer.field_70165_t, entityplayer.field_70163_u, entityplayer.field_70161_v,
									KKSoundEvent.Reload, SoundCategory.NEUTRAL, 1.0F, 1.0F);
						}
						if(cockingtime > cocktime && flag){
							nbt.func_74768_a("CockingTime", 0);
							nbt.func_74757_a("Cocking", true);
						}
					}
				}
				
				{
					if(!recoiled){
						++recoiledtime;
						nbt.func_74768_a("RecoiledTime", recoiledtime);
						if(recoiledtime > 0){
							nbt.func_74768_a("RecoiledTime", 0);
							nbt.func_74757_a("Recoiled", true);
						}
					}
				}
				
				
				{
					KKItemGunBase gun = (KKItemGunBase) itemstack.func_77973_b();
					if (itemstack.func_77952_i() == itemstack.func_77958_k() && flag && entityplayer.field_71071_by.func_70431_c(new ItemStack(Items.field_151032_g))) {
							if (entity != null && entity instanceof EntityPlayer) {
								if (itemstack == entityplayer.func_184614_ca()) {
									int reloadti = nbt.func_74762_e("RloadTime");
									{
										gun.retime = reloadti;
										++reloadti;
										if (reloadti == gun.reloadtime) {
											gun.retime = reloadti = 0;
											nbt.func_74768_a("RloadTime", 0);
											{
											getReload(itemstack, world, entityplayer);
											}
											gun.resc = 0;
										}else{
											nbt.func_74768_a("RloadTime", reloadti);
										}
									}
								}
							}
					}
				}
			}
				super.func_77663_a(itemstack, world, entity, i, flag);
		 }
		
		@Override
	    public byte getCycleCount(ItemStack pItemstack)
	    {
	        return 1;
	    }
		
		public void func_77615_a(ItemStack par1ItemStack, World par2World, EntityLivingBase par3EntityPlayer, int par4){
        	EntityPlayer entityplayer = (EntityPlayer)par3EntityPlayer;
			int s;
			int li = func_77612_l() - par1ItemStack.func_77952_i();
			boolean lflag = cycleBolt(par1ItemStack);
			boolean var5 = entityplayer.field_71075_bZ.field_75098_d || EnchantmentHelper.func_77506_a(Enchantments.field_185312_x, par1ItemStack) > 0;
			Item item = par1ItemStack.func_77973_b();
			NBTTagCompound nbt = par1ItemStack.func_77978_p();
			boolean cocking = nbt.func_74767_n("Cocking");;
			
			//if (var5 || par3EntityPlayer.inventory.hasItemStack(new ItemStack(mod_GeneralGuns.gg_bullet)))
	        {
	         if(par1ItemStack.func_77952_i() == this.func_77612_l())
			 {
	        	 //this.isreload = 1;
	        	 //par2World.playSoundAtEntity(par3EntityPlayer, "gvcguns:gvcguns.reload", 1.0F, 1.0F);
			 }
	        	else	 if(cocking)
				 {
					FireBullet(par1ItemStack,par2World,(EntityPlayer) par3EntityPlayer);
					entityplayer.func_71029_a(StatList.func_188057_b(this));
					nbt.func_74757_a("Cocking", false);
					nbt.func_74757_a("Recoiled", false);
		  }
			}
			
        }
		
		public ActionResult<ItemStack> onItemRightClick(ItemStack itemStackIn, World worldIn, EntityPlayer playerIn, EnumHand hand)
	    {
			int li = func_77612_l() - itemStackIn.func_77952_i();
			boolean flag = this.func_185060_a(playerIn) != null;

	        ActionResult<ItemStack> ret = net.minecraftforge.event.ForgeEventFactory.onArrowNock(itemStackIn, worldIn, playerIn, hand, flag);
	        if (ret != null) return ret;

	        if (!playerIn.field_71075_bZ.field_75098_d && !flag && !(itemStackIn.func_77952_i() == this.func_77612_l()))
	        {
	            return !flag ? new ActionResult(EnumActionResult.FAIL, itemStackIn) : new ActionResult(EnumActionResult.PASS, itemStackIn);
	        }
	        else
	        {
	            playerIn.func_184598_c(hand);
	            return new ActionResult(EnumActionResult.SUCCESS, itemStackIn);
	        }
	    }

		 public void FireBullet(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) 
			{
	        	par2World.func_184148_a((EntityPlayer)null, par3EntityPlayer.field_70165_t, par3EntityPlayer.field_70163_u, par3EntityPlayer.field_70161_v,
	        			KKSoundEvent.Fire_Bullet, SoundCategory.NEUTRAL, 1.0F, 1.0F);
	            par1ItemStack.func_77972_a(1, par3EntityPlayer);
	            
	            int pluspower = EnchantmentHelper.func_77506_a(Enchantments.field_185309_u, par1ItemStack);
	            KKEntityBullet var8 = new KKEntityBullet(par2World,(EntityLivingBase) par3EntityPlayer, this.powor+pluspower, this.speed, this.bure);
	            //var8.func_184538_a(par3EntityPlayer, par3EntityPlayer.rotationPitch, par3EntityPlayer.rotationYaw, 0.0F, this.speed, this.bure);
	            var8.func_70012_b(par3EntityPlayer.field_70165_t, par3EntityPlayer.field_70163_u + 1.5D, par3EntityPlayer.field_70161_v, 
	            		par3EntityPlayer.field_70177_z, par3EntityPlayer.field_70125_A);
	            float bbure = this.bure;
				if (par3EntityPlayer.func_70093_af()) {
					bbure = this.bure / 5;
				}
	            //var8.setAim(par3EntityPlayer, par3EntityPlayer.rotationPitch, par3EntityPlayer.rotationYaw, 0.0F, this.speed, bbure);
				var8.setHeadingFromThrower(par3EntityPlayer, par3EntityPlayer.field_70125_A, par3EntityPlayer.field_70177_z, 0.0F,
						this.speed, bbure);
	               if (!par2World.field_72995_K)
	               {
	                par2World.func_72838_d(var8);
	               }
	               par3EntityPlayer.field_70125_A += (field_77697_d.nextFloat() * -3F) * this.recoil;
			}
			
			public void getReload(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) 
			{
				par2World.func_184148_a((EntityPlayer)null, par3EntityPlayer.field_70165_t, par3EntityPlayer.field_70163_u, par3EntityPlayer.field_70161_v,
						KKSoundEvent.Reload, SoundCategory.NEUTRAL, 1.0F, 1.0F);
				
				int li = func_77612_l() - par1ItemStack.func_77952_i();
				boolean linfinity = EnchantmentHelper.func_77506_a(Enchantments.field_185312_x, par1ItemStack) > 0;
				//ItemStack item = par3EntityPlayer.inventory.(new ItemStack(mod_GeneralGuns.gg_bullet))
				ItemStack item = this.func_185060_a(par3EntityPlayer);
				if(!par3EntityPlayer.field_71075_bZ.field_75098_d || par3EntityPlayer.field_71071_by.func_70431_c(new ItemStack(Items.field_151032_g))){
				        par1ItemStack.func_77972_a(li, par3EntityPlayer);
						setDamage(par1ItemStack, -this.func_77612_l());
						if (!linfinity) {
							item.func_190918_g(1);
							if (item.func_190926_b())
	                        {
								par3EntityPlayer.field_71071_by.func_184437_d(item);
	                        }
							//--item.stackSize;
							//par3EntityPlayer.inventory.deleteStack(item);
						}
				}
			}
	    
			public Multimap<String, AttributeModifier> func_111205_h(EntityEquipmentSlot equipmentSlot)
		    {
		        Multimap<String, AttributeModifier> multimap = super.func_111205_h(equipmentSlot);

		        if (equipmentSlot == EntityEquipmentSlot.MAINHAND)
		        {
		            multimap.put(SharedMonsterAttributes.field_111264_e.func_111108_a(), new AttributeModifier(field_111210_e, "Weapon modifier", (double)this.attackDamage, 0));
		            multimap.put(SharedMonsterAttributes.field_188790_f.func_111108_a(), new AttributeModifier(field_185050_h, "Weapon modifier", -2.4000000953674316D, 0));
		        }

		        return multimap;
		    }
	}

package kettenkrad.items;

import javax.annotation.Nullable;

import kettenkrad.entity.EntityKettenkrad;
import net.minecraft.block.BlockLiquid;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

public class ItemKettenkrad extends Item
{
	private static final String par3World = null;
	public int mob ;
	
	public ItemKettenkrad()
    {
        super();
        this.field_77777_bU = 64;
    }

	@Nullable
    public void spawnCreature(World worldIn, EntityPlayer playerIn, double par4, double par5, double par6)
    {

    	if(this.mob == 0){
        ++par5;
        int var12 = MathHelper.func_76128_c((double)(playerIn.field_70177_z * 4.0F / 360.0F) + 0.5D) & 3;
        EntityKettenkrad entityskeleton = new EntityKettenkrad(worldIn);
        entityskeleton.func_70012_b(par4+0.5, par5, par6+0.5, var12, 0.0F);
        worldIn.func_72838_d(entityskeleton);
        //entityskeleton.mountEntity(entityskeleton1);
        }
    }//end
	
	public EnumActionResult func_180614_a(EntityPlayer player, World worldIn, BlockPos pos, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ)
    {
		ItemStack itemStackIn = player.func_184586_b(hand);
		int par4 = pos.func_177958_n();
		int par5 = pos.func_177956_o();
		int par6 = pos.func_177952_p();
		
		if (worldIn.field_72995_K)
        {
			return EnumActionResult.PASS;
        }
        else
		{
        	if (!player.field_71075_bZ.field_75098_d)
            {
        		itemStackIn.func_190918_g(1);
            }
        	spawnCreature(worldIn, player, (double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p());
        	return EnumActionResult.PASS;
        }
    }
	
	/**
     * Called when the equipped item is right clicked.
     */
    public ActionResult<ItemStack> func_77659_a(World worldIn, EntityPlayer playerIn, EnumHand handIn)
    {
    	ItemStack itemStackIn = playerIn.func_184586_b(handIn);
        if (worldIn.field_72995_K)
        {
            return new ActionResult(EnumActionResult.PASS, itemStackIn);
        }
        else
        {
            RayTraceResult raytraceresult = this.func_77621_a(worldIn, playerIn, true);

            if (raytraceresult != null && raytraceresult.field_72313_a == RayTraceResult.Type.BLOCK)
            {
                BlockPos blockpos = raytraceresult.func_178782_a();

                if (!(worldIn.func_180495_p(blockpos).func_177230_c() instanceof BlockLiquid))
                {
                    return new ActionResult(EnumActionResult.PASS, itemStackIn);
                }
                else if (worldIn.func_175660_a(playerIn, blockpos) && playerIn.func_175151_a(blockpos, raytraceresult.field_178784_b, itemStackIn))
                {
                    spawnCreature(worldIn, playerIn, (double)blockpos.func_177958_n(), (double)blockpos.func_177956_o(), (double)blockpos.func_177952_p());
                    {

                    	if (!playerIn.field_71075_bZ.field_75098_d)
                        {
                    		itemStackIn.func_190918_g(1);
                        }

                        playerIn.func_71029_a(StatList.func_188057_b(this));
                        return new ActionResult(EnumActionResult.SUCCESS, itemStackIn);
                    }
                }
                else
                {
                    return new ActionResult(EnumActionResult.FAIL, itemStackIn);
                }
            }
            else
            {
                return new ActionResult(EnumActionResult.PASS, itemStackIn);
            }
        }
    }
	
	
	
}

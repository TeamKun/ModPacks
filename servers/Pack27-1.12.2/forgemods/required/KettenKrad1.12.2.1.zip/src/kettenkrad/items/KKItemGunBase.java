package kettenkrad.items;



import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import objmodel.IModelCustom;



	public class KKItemGunBase extends ItemBow {

		public static final String[] bowPullIconNameArray = new String[] {"", "", ""};
	    //private final Item.ToolMaterial field_150933_b;
	    private static final String __OBFID = "CL_00000072";
	    public static final String Tag_Cycle		= "Cycle";
	    public static final String Tag_CycleCount	= "CycleCount";
	    protected float attackDamage = 2;
	    public float f;
	    public int j;
	    
	    public int isreload;
	    public int retime;
	    public int reloadtime;
	    
	    public static int maxdamege;
	    
	    public static boolean canreload;
	    
	    public int firetime;
	    public int firegrenadetime;
	    public int retimegrenade;

		
		public int powor;
	    public float speed;
	    public float bure;
	    public double recoil;
	    public float scopezoom;
	    public int cycle;
	    public float soundsp = 1;
	    
	    public float bureads;
	    public double recoilads;
	    
	    public static int bulletcount;
	    
	    public String ads;
	    public String adsr;
	    public String adss;
	    
	    
	    public boolean ex = false;
	    
	    public boolean milock = true;
	    
	    public int aaa;
	    public static boolean grenadekey;
	    
	    
	    public IModelCustom obj_model = null;//AdvancedModelLoader.loadModel(new ResourceLocation("gvclib:textures/model/ar.obj"));
	    public IModelCustom arm_model = null;//AdvancedModelLoader.loadModel(new ResourceLocation("gvclib:textures/model/arm.obj"));
	    public String obj_models = null;//AdvancedModelLoader.loadModel(new ResourceLocation("gvclib:textures/model/ar.obj"));
	    public String arm_models = null;//AdvancedModelLoader.loadModel(new ResourceLocation("gvclib:textures/model/arm.obj"));
	    public String obj_tex = "gvclib:textures/model/ar.png";
	    public boolean obj_true = false;
		
	    public float model_x = 1.5F;
	    public float model_y = -2F;
	    public float model_z = -3.5F;
	    public float model_x_ads = 0F;
	    public float model_y_ads = -1.7F;
	    public float model_z_ads = -1.5F;
	    public boolean model_hand = false;
	    //public boolean model_heavy = false;
	    public boolean model_zoomrender = false;
	    public boolean model_zoomrenderr = false;
	    public boolean model_zoomrenders = false;
	    
	    //0915
	  //rotation
		public float rotationx = 0F;
		public float rotationx0;
		public float rotationx1;
		public float rotationx2;
		
		public float rotationy = 180F;
		public float rotationy0;
		public float rotationy1;
		public float rotationy2;
		
		public float rotationz = 0F;
		public float rotationz0;
		public float rotationz1;
		public float rotationz2;
	    
	    public float arm_r_posx = 0F;
	    public float arm_r_posy = 0F;
	    public float arm_r_posz = 0F;
	    
	    public float arm_l_posx = 0F;
	    public float arm_l_posy = 0F;
	    public float arm_l_posz = 0F;
	    public float arm_mag_l_posx = 0F;
	    public float arm_mag_l_posy = 0F;
	    public float arm_mag_l_posz = -1.5F;
	    
	    //8/18
	    public boolean knife = false;
	    
	    
	    public IModelCustom flash_model = null;//AdvancedModelLoader.loadModel(new ResourceLocation("gvclib:textures/model/flash.obj"));
	    public String flash_tex = "gvclib:textures/model/flash.png";
	    public float flash_posx = 0F;
	    public float flash_posy = 1F;
	    public float flash_posz = 6F;
	    
	    public boolean flash = false;
	    
	    /*
	     *  zaisitu,retimestart,end,
	     *  xpos,ypos,zpos, //モデルの基準
	     *  xoff,yoff,zoff,//モデルのoffset
	     *  xroteoff,yroteoff,zroteoff,
	     *  xmove,ymove,zmove,
	     *  xrote,yrote,zrote,bairitu
	    
	    move = 1 or -1 or 0*/
	    public boolean newreload = false;
	    
	    public int mat_rk_0 = 2;
	    public String[] mat_r_0 = new String[]{"mat1", "0", "30", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"-20", "0", "20", 
	    		"0", "0", "0", 
	    		"0", "0", "0", "0","0",
	    		"mat3","30", "40",  
	    		"0", "0","0", 
	    		"0", "0", "0", 
	    		"0", "0", "-60", 
	    		"0", "0", "0", 
	    		"0", "0", "0", "0","0"
	    		};
	    public int mat_rk_2 = 1;
	    public String[] mat_r_2 = new String[]{"mat2", "0", "200", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", "0F","0"
	    		};
	    public int mat_rk_3 = 2;
	    public String[] mat_r_3 = new String[]{"mat3", "0", "15", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "-1", "0", 
	    		"1", "0", "0", "0.4F","0",
	    		"mat3","15", "30",  
	    		"0", "0","0", 
	    		"0", "-6", "0", 
	    		"0", "0", "0", 
	    		"0", "1", "0", 
	    		"-1", "0", "0", "0.4F","0"
	    		};
	    
	    public int mat_rk_22 = 1;
	    public String[] mat_r_22 = new String[]{"mat22", "0", "200", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", "0F","0"
	    		};
	    public int mat_rk_25 = 1;
	    public String[] mat_r_25 = new String[]{
	    		"mat25", "0", "200", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", "0F","0"
	    		};
	    
	    public int mat_rk_rightarm = 1;
	    public String[] mat_r_rightarm = new String[]{
	    		"mat25", "0", "200", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", "0F","0"
	    		};
	    
	    public int mat_rk_leftarm = 1;
	    public String[] mat_r_leftarm = new String[]{
	    		"leftarm", "0", "200", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", 
	    		"0", "0", "0", "0F","0"
	    		};
	    
	    
	    
	    

		
		
	    public boolean canex;
	    public String sound;
	    public String soundre;
	    public boolean canobj;
	    public int firetype;
	    public boolean rendercross;
	    
	    public boolean semi = true;
	    public String soundco;
	    
	    
	    public int isrecoil;
	    public int recotime;
	    
	    public boolean isisreload = false;
	    
	    public ResourceLocation texture;
	    public static int righttype;
	    public int right;
	    
	    public int resc;
	    
	    
	    public boolean recoilre;
	    
	    
	    public  String adstexture;
	    
	    
	    
	    
	    public int zox;
	    public int zoy;
	    public int zoz;
	    
	    
	    public float scopezoombase;
	    public float scopezoomred;
	    public float scopezoomscope;
	    public String soundbase;
	    public String soundsu;
	    //public Item magazine;
	    public Item magazinesg = Items.field_151034_e;
	    public Item magazinegl = Items.field_151034_e;
	    public  String adstexturer;
	    public  String adstextures;
	    
	    public  boolean true_mat4 = false;
	    public  boolean true_mat5 = false;
	    public  boolean true_mat6 = false;
	    public  boolean true_mat7 = false;
	    public  boolean true_mat8 = false;
	    public  boolean true_mat9 = false;
	    public  boolean true_mat10 = false;
	    public  boolean true_mat11 = false;
	    
	    public int bullettype = 0;
	    public boolean zoomre = false;
	    
	    public boolean zoomren = false;
	    public boolean zoomrer = false;
	    public boolean zoomres = false;
	    
	    public boolean zoomrent = false;
	    public boolean zoomrert = false;
	    public boolean zoomrest = false;
	    
	    public double motion = 1D;
	    
	    public boolean muzzle = true;
	    
	    public boolean muzzlef;
	    
	    public boolean bullet_c = false;
	    
	    public int ff;
	    
	    public boolean mat22 = false;
	    public float mat22rotationx = 90F;
		public float mat22rotationy = 0F;
		public float mat22rotationz = 0F;
		public float mat22offsetx = 0F;
		public float mat22offsety = 1.5F;
		public float mat22offsetz = 2F;
	    
	    public float mat25rotationx = 0F;
		public float mat25rotationy = 0F;
		public float mat25rotationz = -90F;
		public float mat25offsetx = 0F;
		public float mat25offsety = 0.75F;
		public float mat25offsetz = 1.1F;
		public float soundspeed = 1.0F;
	    public float soundrespeed = 1.0F;
	    public String soundcock = "hmgww2:hmgww2.ing";
	    public int cocktime = 20;
		
	    public float Sprintrotationx = 20F;
		public float Sprintrotationy = 60F;
		public float Sprintrotationz = 0F;
		public float Sprintoffsetx = 0.5F;
		public float Sprintoffsety = 0.0F;
		public float Sprintoffsetz = 0.5F;
	    
		public int shotgun_pellet = 9;
		
		//01/27
		public float gra = 0.029F;
		public float vecy = 0;
		
		public float jump = -1F;
		//01/27
		public boolean all_jump = false;
		public boolean cock_left = false;
		public boolean mat25 = false;
		public boolean mat2 = false;
		
		//02/07
		public float mat31posx = 0F;
		public float mat31posy = 0.55F;
		public float mat31posz = 0F;
		public float mat31rotex = 0F;
		public float mat31rotey = 0F;
		public float mat31rotez = 60F;
	//	public float nox;
	//	public float noy;
	//	public float noz;
		public float rote;
		public float rotey;
		public float rotex;
		
		public float mat32posx;
		public float mat32posy;
		public float mat32posz;
		public float mat32rotex;
		public float mat32rotey;
		public float mat32rotez;
		
		//02/14
			public int gun_type = 0;
			public boolean noads = false;
			public int c_type;
			public boolean canmagazine = true;
			public boolean remat31 = true;
	    
	    
	    //0307
			public float model_x_adsr = 0F;
		    public float model_y_adsr = -1.7F;
		    public float model_z_adsr = -1.5F;
		    
		    public float model_x_adss = 0F;
		    public float model_y_adss = -1.7F;
		    public float model_z_adss = -1.5F;
	    
		  //0307
			public String soundunder_gl= "handmadeguns:handmadeguns.cooking";
			public String soundunder_sg= "handmadeguns:handmadeguns.cooking";
			public int under_gl_power = 20;
			public float under_gl_speed = 2;
			public float under_gl_bure = 5;
			public double under_gl_recoil = 5;
			public float under_gl_gra = 0.01F;
			public int under_sg_power = 4;
			public float under_sg_speed = 3;
			public float under_sg_bure = 20;
			public double under_sg_recoil = 5;
			public float under_sg_gra = 0.029F;
	    
		//0916
			public float model_x_adsro = 0F;
		    public float model_y_adsro = -1.7F;
		    public float model_z_adsro = -1.5F;
		    
		//0930
		    public float model_cock_x = 0F;
		    public float model_cock_y = 0F;
		    public float model_cock_z = -0.4F;
		    
		    public float modek_third_offset_rote_x = 70F;
		
		public KKItemGunBase() {
			//iconNames = new String[] {"reload", ""};
			//maxdamege = this.getMaxDamage();
		}
		
		public boolean checkTags(ItemStack pitemstack) {
			if (pitemstack.func_77942_o()) {
				return true;
			}
			NBTTagCompound ltags = new NBTTagCompound();
			pitemstack.func_77982_d(ltags);
			ltags.func_74768_a("Reload", 0x0000);
			ltags.func_74774_a("Bolt", (byte)0);
			NBTTagCompound lammo = new NBTTagCompound();
			for (int li = 0; li < func_77612_l(); li++) {
				lammo.func_74772_a(Integer.toString(li), 0L);
			}
			//ltags.setCompoundTag("Ammo", lammo);
			return false;
		}
		
		protected boolean cycleBolt(ItemStack pItemstack) {
			checkTags(pItemstack);
			NBTTagCompound lnbt = pItemstack.func_77978_p();
			byte lb = lnbt.func_74771_c("Bolt");
			if (lb <= 0) {
//				if (pReset) resetBolt(pItemstack);
				return true;
			} else {
				lnbt.func_74774_a("Bolt", --lb);
				return false;
			}
		}
		
		protected void resetBolt(ItemStack pItemstack) {
			checkTags(pItemstack);
			pItemstack.func_77978_p().func_74774_a("Bolt", getCycleCount(pItemstack));
		}
		
		public byte getCycleCount(ItemStack pItemstack) {
			return (byte)1;
		}
		
		public static void updateCheckinghSlot(Entity pEntity, ItemStack pItemstack) {
			if (pEntity instanceof EntityPlayerMP) {
				EntityPlayerMP lep = (EntityPlayerMP)pEntity;
				Container lctr = lep.field_71070_bA;
				for (int li = 0; li < lctr.field_75151_b.size(); li++) {
					ItemStack lis = ((Slot)lctr.func_75139_a(li)).func_75211_c(); 
					if (lis == pItemstack) {
						lctr.field_75153_a.set(li, pItemstack.func_77946_l());
						break;
					}
				}
			}
		}
		
		
		public ItemStack func_185060_a(EntityPlayer player)
	    {
	        if (this.func_185058_h_(player.func_184586_b(EnumHand.OFF_HAND)))
	        {
	            return player.func_184586_b(EnumHand.OFF_HAND);
	        }
	        else if (this.func_185058_h_(player.func_184586_b(EnumHand.MAIN_HAND)))
	        {
	            return player.func_184586_b(EnumHand.MAIN_HAND);
	        }
	        else
	        {
	            for (int i = 0; i < player.field_71071_by.func_70302_i_(); ++i)
	            {
	                ItemStack itemstack = player.field_71071_by.func_70301_a(i);

	                if (this.func_185058_h_(itemstack))
	                {
	                    return itemstack;
	                }
	            }

	            return null;
	        }
	    }

	    public boolean func_185058_h_(ItemStack stack)
	    {
	        return stack != null && stack.func_77973_b() == Items.field_151032_g;
	    }
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	public float func_150893_a(ItemStack p_150893_1_, Block p_150893_2_)
    {
        
            return 1.0F;
        
        
    }
    
    /**
     * Returns True is the item is renderer in full 3D when hold.
     */
    public boolean func_77662_d()
    {
        return true;
    }
    
    public ItemStack onEaten(ItemStack p_77654_1_, World p_77654_2_, EntityPlayer p_77654_3_)
    {
        return p_77654_1_;
    }
    
    /**
     * returns the action that specifies what animation to play when the items is being used
     */
    public EnumAction func_77661_b(ItemStack par1ItemStack)
    {
    	return EnumAction.BOW;
    }

    /**
     * How long it takes to use or consume an item
     */
    /*public int getMaxItemUseDuration(ItemStack par1ItemStack)
    {
    	if(par1ItemStack.getItemDamage() == this.getMaxDamage()){
    		return 20;
    		
    	}
    	return 7200;
    	
    }*/
    public int func_77626_a(ItemStack par1ItemStack)
    {
    	return 7200;
    }

    

    public boolean func_150897_b(Block p_150897_1_)
    {
        return p_150897_1_ == Blocks.field_150321_G;
    }

    public boolean isWeaponReload(ItemStack itemstack, EntityPlayer entityplayer)
    {
    	/*NBTTagCompound nbt = itemstack.getTagCompound();
		int reloadtime = nbt.getInteger("gvcreloadtime");
		int reload = nbt.getInteger("gvcreload");
		return reload==1;*/
     return false;
    }
    public boolean isWeaponFullAuto(ItemStack itemstack) {
		return false;
	}
    

}

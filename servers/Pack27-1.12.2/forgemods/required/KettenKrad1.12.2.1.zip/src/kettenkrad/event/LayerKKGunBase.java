package kettenkrad.event;

import org.lwjgl.opengl.GL11;

import kettenkrad.items.KKItemGunBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class LayerKKGunBase extends LayerHeldItem//implements LayerRenderer<EntityLivingBase>
{
    protected final RenderLivingBase<?> livingEntityRenderer;

    
    public LayerKKGunBase(RenderLivingBase<?> livingEntityRendererIn)
    {
    	super(livingEntityRendererIn);
        this.livingEntityRenderer = livingEntityRendererIn;
        //GL11.glScalef(5F, 5F, 5F);
    }

    public void func_177141_a(EntityLivingBase entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale)
    {
    	//GL11.glScalef(5F, 5F, 5F);
        boolean flag = entitylivingbaseIn.func_184591_cq() == EnumHandSide.RIGHT;
        ItemStack itemstack = flag ? entitylivingbaseIn.func_184592_cb() : entitylivingbaseIn.func_184614_ca();
        ItemStack itemstack1 = flag ? entitylivingbaseIn.func_184614_ca() : entitylivingbaseIn.func_184592_cb();

        if (!itemstack.func_190926_b() || !itemstack1.func_190926_b())
        {
            GlStateManager.func_179094_E();

            if (this.livingEntityRenderer.func_177087_b().field_78091_s)
            {
                float f = 0.5F;
                GlStateManager.func_179109_b(0.0F, 0.625F, 0.0F);
                GlStateManager.func_179114_b(-20.0F, -1.0F, 0.0F, 0.0F);
                GlStateManager.func_179152_a(0.5F, 0.5F, 0.5F);
            }
            
            this.renderHeldItem(entitylivingbaseIn, itemstack1, ItemCameraTransforms.TransformType.THIRD_PERSON_RIGHT_HAND, EnumHandSide.RIGHT);
            this.renderHeldItem(entitylivingbaseIn, itemstack, ItemCameraTransforms.TransformType.THIRD_PERSON_LEFT_HAND, EnumHandSide.LEFT);
            GlStateManager.func_179121_F();
            
        }
    }

    private void renderHeldItem(EntityLivingBase p_188358_1_, ItemStack itemstack, ItemCameraTransforms.TransformType p_188358_3_, EnumHandSide handSide)
    {
        if (!itemstack.func_190926_b())
        {
        	//System.out.println(String.format("road2"));
            GlStateManager.func_179094_E();
            if (p_188358_1_.func_70093_af())
            {
                GlStateManager.func_179109_b(0.0F, 0.2F, 0.0F);
            }
            // Forge: moved this call down, fixes incorrect offset while sneaking.
            ModelBiped model = (ModelBiped)this.livingEntityRenderer.func_177087_b();
            model.field_178724_i.field_78807_k = false;
            model.field_178721_j.field_78807_k = false;
            ((ModelBiped)this.livingEntityRenderer.func_177087_b()).func_187073_a(0.0625F, handSide);
            GlStateManager.func_179114_b(-90.0F, 1.0F, 0.0F, 0.0F);
            GL11.glScalef(0.1875F, 0.1875F, 0.1875F);
            boolean flag = handSide == EnumHandSide.LEFT;
            GlStateManager.func_179109_b((float)((flag ? -1 : 1) / 16.0F) * -5.33F, 0.125F * 1.8F, -0.625F * -4.5F);//-5.33,-3.33,-4.5
            if (!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof KKItemGunBase) {//item
            	KKItemGunBase gun = (KKItemGunBase) itemstack.func_77973_b();
				Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation(gun.obj_tex));
				gun.obj_model.renderPart("mat1");
				gun.obj_model.renderPart("mat2");
				gun.obj_model.renderPart("mat3");
				gun.obj_model.renderPart("mat20");
				gun.obj_model.renderPart("mat21");
				gun.obj_model.renderPart("mat25");
				gun.obj_model.renderPart("mat31");
				gun.obj_model.renderPart("mat32");/**/
            }
            GlStateManager.func_179121_F();
        }
    }

    
    
    public boolean func_177142_b()
    {
        return false;
    }
}

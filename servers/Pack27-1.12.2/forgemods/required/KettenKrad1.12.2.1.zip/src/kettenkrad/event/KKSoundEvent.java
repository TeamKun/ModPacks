package kettenkrad.event;


import kettenkrad.mod_Kettenkrad;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;

/**
 * Registers this mod's {@link SoundEvent}s.
 *
 * @author Choonster
 */
//@SuppressWarnings("WeakerAccess")
public class KKSoundEvent {
	public static SoundEvent Fire_Bullet;
	public static SoundEvent Reload;
	public static SoundEvent TANK;

	/**
	 * Register the {@link SoundEvent}s.
	 */
	public static void registerSounds() {
		Fire_Bullet = registerSound("kettenkrad.fire");
		Reload = registerSound("kettenkrad.reload");
		TANK = registerSound("kettenkrad.tank");
	}

	/**
	 * Register a {@link SoundEvent}.
	 *
	 * @param soundName The SoundEvent's name without the testmod3 prefix
	 * @return The SoundEvent
	 */
	private static SoundEvent registerSound(String soundName) {
		final ResourceLocation soundID = new ResourceLocation(mod_Kettenkrad.MOD_ID, soundName);
		//return GameRegistry.register(new SoundEvent(soundID).setRegistryName(soundID));
		return new SoundEvent(new ResourceLocation(mod_Kettenkrad.MOD_ID, soundName)).setRegistryName(soundName);
	}
	
	
}

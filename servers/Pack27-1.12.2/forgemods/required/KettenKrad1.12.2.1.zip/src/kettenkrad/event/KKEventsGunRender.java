package kettenkrad.event;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

import kettenkrad.items.KKItemGunBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;;

public class KKEventsGunRender {

	@SideOnly(Side.CLIENT)
    @SubscribeEvent
	  public void renderfov(FOVUpdateEvent event)
	  {
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		EntityPlayer entityplayer = minecraft.field_71439_g;
		ItemStack itemstack = ((EntityPlayer) (entityplayer)).func_184614_ca();
		if (itemstack != null && itemstack.func_77973_b() instanceof KKItemGunBase) {//item
			KKItemGunBase gun = (KKItemGunBase) itemstack.func_77973_b();
			if (entityplayer.func_70093_af()) {
				if (itemstack != null && itemstack.func_77973_b() == gun && gun.scopezoom > 1.0) {
					event.setNewfov(event.getFov() / gun.scopezoom);
				}
			}
		}//item
	  }
	
	@SideOnly(Side.CLIENT)
    @SubscribeEvent
	  public void rendergun(RenderHandEvent event)
	  {
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		EntityPlayer entityplayer = minecraft.field_71439_g;
		ItemStack itemstack = ((EntityPlayer) (entityplayer)).func_184614_ca();
		if (itemstack != null && itemstack.func_77973_b() instanceof KKItemGunBase && itemstack.func_77942_o()) {//item
			KKItemGunBase gun = (KKItemGunBase) itemstack.func_77973_b();
			{
				/*if(gun.obj_model != null){
					gun.obj_model = AdvancedModelLoader.loadModel(new ResourceLocation(gun.obj_models));
					gun.arm_model = AdvancedModelLoader.loadModel(new ResourceLocation(gun.arm_models));
				}*/
				this.rendermain(entityplayer, itemstack, true);
			}
		}//item
	  }
	
	private void rendermain(EntityPlayer entityplayer, ItemStack itemstack, boolean side){
		int xxx = 1;
		if(!side){
			xxx = -1;
		}
		
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		KKItemGunBase gun = (KKItemGunBase) itemstack.func_77973_b();
		NBTTagCompound nbt = itemstack.func_77978_p();
		boolean cocking = nbt.func_74767_n("Cocking");
		int cockingtime = nbt.func_74762_e("CockingTime");
		boolean recoiled = nbt.func_74767_n("Recoiled");
		int recoiledtime = nbt.func_74762_e("RecoiledTime");
		
		boolean left = nbt.func_74767_n("LeftClick");
		boolean right = nbt.func_74767_n("RightClick");
		boolean sidel =false;
		boolean sider = false;
		
		if(minecraft.field_71474_y.field_74320_O == 0){
			GL11.glPushMatrix();//guns
			GL11.glScalef(0.5F, 0.5F, 0.5F);
			GL11.glScalef(0.5F, 0.5F, 0.5F);
	//		GL11.glScalef(0.5F, 0.5F, 0.5F);
	//		GL11.glScalef(0.5F, 0.5F, 0.5F);
			GL11.glEnable(GL12.GL_RESCALE_NORMAL);
			
			//8/18
			if(side && entityplayer.func_184592_cb() == null)
			{
				float f1 = entityplayer.field_70733_aJ;
				GL11.glTranslatef(0,0, -f1*5);
				GL11.glRotatef(f1*30, -1.0F, 0.0F, 1.0F);
			}
			
			if (itemstack.func_77952_i() == itemstack.func_77958_k()) {//1s
				GL11.glTranslatef(gun.model_x * xxx ,gun.model_y, gun.model_z + 1);//1.5,-2,-2.5
				GL11.glRotatef(180F, 0.0F, 1.0F, 0.0F);
				GL11.glRotatef(20F, 0.0F, 0.0F, 1.0F);
				GL11.glRotatef(-20F, 1.0F, 0.0F, 0.0F);
				GL11.glRotatef(50F, 0.0F, 1.0F, 0.0F);
			}
			else if(entityplayer.func_70093_af()){//ADS
				/*if(side && entityplayer.getHeldItemOffhand() != null){
					GL11.glTranslatef(gun.model_x * xxx ,gun.model_y, gun.model_z + 1);//1.5,-2,-2.5
					GL11.glRotatef(180F, 0.0F, 1.0F, 0.0F);
					GL11.glRotatef(00F, 0.0F, 1.0F, 0.0F);
					GL11.glRotatef(0F, 1.0F, 0.0F, 0.0F);
				}else*/
				{
					GL11.glTranslatef(ADS_X(gun) * xxx,ADS_Y(gun), ADS_Z(gun));//0,-1.7,-1.5
					GL11.glRotatef(gun.rotationx, 1.0F, 0.0F, 0.0F);
					GL11.glRotatef(gun.rotationy * xxx, 0.0F, 1.0F, 0.0F);
					GL11.glRotatef(gun.rotationz * xxx, 0.0F, 0.0F, 1.0F);
				}
			}else if(entityplayer.func_70051_ag()){
				GL11.glTranslatef(gun.model_x * xxx -0.5F,gun.model_y, gun.model_z);
				GL11.glTranslatef(gun.Sprintoffsetx * xxx, gun.Sprintoffsety, gun.Sprintoffsetz);
				GL11.glRotatef(-gun.Sprintrotationx, 1.0F, 0.0F, 0.0F);
				GL11.glRotatef(gun.Sprintrotationy * xxx+180, 0.0F, 1.0F, 0.0F);
				GL11.glRotatef(gun.Sprintrotationz, 0.0F, 0.0F, 1.0F);
				
			}
			else{
				
			GL11.glTranslatef(gun.model_x * xxx ,gun.model_y, gun.model_z + 1);//1.5,-2,-2.5
			
			GL11.glRotatef(180F, 0.0F, 1.0F, 0.0F);
			GL11.glRotatef(00F, 0.0F, 1.0F, 0.0F);
			GL11.glRotatef(-3F, 1.0F, 0.0F, 0.0F);
			}//1e
			if (!recoiled)
			{
				GL11.glRotatef(gun.jump, 1.0F, 0.0F, 0.0F);
			}
			
			GL11.glPushMatrix();//guns
			Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation(gun.obj_tex));
			if(entityplayer.func_70093_af()){
				if(gun.scopezoom > 1.1F && gun.model_zoomrender){
				}else{
				this.rendermat(entityplayer, itemstack, gun);//rendermat
				}
			}else{
				this.rendermat(entityplayer, itemstack, gun);//rendermat
			}
			GL11.glPopMatrix();//gune
			
			GL11.glPushMatrix();//flashs
			Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation(gun.flash_tex));
			GL11.glTranslatef(gun.flash_posx,gun.flash_posy, gun.flash_posz);//0,1,6
			if (!recoiled)
			{
				if(entityplayer.func_70093_af()){
					if(!gun.model_zoomrender){
						GL11.glTranslatef(0.0F, 0.0F, 0F);
					}
				}else{
					GL11.glTranslatef(0.0F, 0.0F, 0F);
				}
			}else{
				GL11.glTranslatef(0.0F, -100.0F, 0F);
			}
//			gun.flash_model.renderPart("flash");
			GL11.glPopMatrix();//flashe
			
			GL11.glPushMatrix();//arms
			ResourceLocation resourcelocation = ((AbstractClientPlayer)entityplayer).func_110306_p();
			if (resourcelocation == null)
	        {
	            resourcelocation = new ResourceLocation("textures/entity/steve.png");
	        }
			Minecraft.func_71410_x().field_71446_o.func_110577_a(resourcelocation);
			if(cockingtime != 0)
			{
				if(cockingtime > 0 && cockingtime < (gun.cocktime/2)){
					GL11.glTranslatef(0F, 0F, -cockingtime*0.1F);
					GL11.glRotatef(cockingtime * 3, -1.0F, 1.0F, 1.0F);
				}else if(cockingtime <= gun.cocktime){
					GL11.glTranslatef(0F, 0F, (cockingtime-gun.cocktime)*0.1F);
					GL11.glRotatef((cockingtime-gun.cocktime) * 3, 1.0F, -1.0F, -1.0F);
				}
			}
			if(entityplayer.func_70093_af()){
				{
					this.renderarm(entityplayer, itemstack, gun);//renderarm
				}
			}else{
				this.renderarm(entityplayer, itemstack, gun);//renderarm
			}
			GL11.glPopMatrix();//arme
			GL11.glDisable(GL12.GL_RESCALE_NORMAL);
			GL11.glPopMatrix();//gune
			
		}
	}
	
	
	private void rendermat(EntityPlayer entityplayer, ItemStack itemstack, KKItemGunBase gun){
		NBTTagCompound nbt = itemstack.func_77978_p();
		boolean cocking = nbt.func_74767_n("Cocking");
		int cockingtime = nbt.func_74762_e("CockingTime");
		boolean recoiled = nbt.func_74767_n("Recoiled");
		int recoiledtime = nbt.func_74762_e("RecoiledTime");
		
		//if (recoiled)
		if(cockingtime != 0)
		{
			if(cockingtime > 0 && cockingtime < (gun.cocktime/2)){
				GL11.glTranslatef(0F, 0F, -cockingtime*0.1F);
				GL11.glRotatef(cockingtime * 3, -1.0F, 1.0F, 1.0F);
			}else if(cockingtime <= gun.cocktime){
				GL11.glTranslatef(0F, 0F, (cockingtime-gun.cocktime)*0.1F);
				GL11.glRotatef((cockingtime-gun.cocktime) * 3, 1.0F, -1.0F, -1.0F);
			}
		}
		
		
		gun.obj_model.renderPart("mat1");
		
		this.renderattachment(entityplayer, itemstack, gun);
		if (!recoiled)
		{
			GL11.glTranslatef(0.0F, 0.0F, gun.model_cock_z);//0, 0, -0.4
			gun.obj_model.renderPart("mat2");
			GL11.glTranslatef(0.0F, 0.0F, -gun.model_cock_z);
			this.mat25(gun, false, cockingtime);
			this.rendersight(entityplayer, itemstack, gun);
		}else{
			if (itemstack.func_77952_i() != itemstack.func_77958_k()) {
				gun.obj_model.renderPart("mat2");
				this.mat25(gun, false, cockingtime);
				this.rendersight(entityplayer, itemstack, gun);
			}else{
				this.mat25(gun, true, cockingtime);
				gun.obj_model.renderPart("mat24");
				GL11.glTranslatef(0.0F, 0.0F, gun.model_cock_z);
				gun.obj_model.renderPart("mat2");
				GL11.glTranslatef(0.0F, 0.0F, -gun.model_cock_z);
			}
		}
		
		if (itemstack.func_77952_i() != itemstack.func_77958_k()) {
			gun.obj_model.renderPart("mat3");
		}else{
			for(int kais = 0; kais <= gun.mat_rk_3;++kais){
				renderreload(gun, kais, gun.mat_r_3);
			}
			gun.obj_model.renderPart("mat3");
		}
	}
	
	private void renderattachment(EntityPlayer entityplayer, ItemStack itemstack, KKItemGunBase gun){
		{
			gun.obj_model.renderPart("mat21");
		}
	}
	
	private void rendersight(EntityPlayer entityplayer, ItemStack itemstack, KKItemGunBase gun){
		{
			gun.obj_model.renderPart("mat20");
		}
		gun.obj_model.renderPart("mat22");
	}
	
	private void mat25(KKItemGunBase gun, boolean recoil, int cockingtime){
		if(recoil){
			GL11.glPushMatrix();//glstart11
			{
				for(int kais = 0; kais <= gun.mat_rk_25;++kais){
					renderreload(gun, kais, gun.mat_r_25);
				}
				gun.obj_model.renderPart("mat25");
			}
			GL11.glPopMatrix();//glend11
		}else{

			GL11.glPushMatrix();//glstart11
			if(cockingtime <= 0){
				gun.obj_model.renderPart("mat25");
			}else{
				GL11.glTranslatef(gun.mat25offsetx, gun.mat25offsety, gun.mat25offsetz);
				GL11.glRotatef(gun.mat25rotationx, 1.0F, 0.0F, 0.0F);
				GL11.glRotatef(gun.mat25rotationy, 0.0F, 1.0F, 0.0F);
				GL11.glRotatef(gun.mat25rotationz, 0.0F, 0.0F, 1.0F);
				GL11.glTranslatef(-gun.mat25offsetx, -gun.mat25offsety, -gun.mat25offsetz);
				if(cockingtime > 0 && cockingtime < (gun.cocktime/2)){
					GL11.glTranslatef(0F, 0F, -cockingtime*0.1F);
				}else{
					GL11.glTranslatef(0F, 0F, (cockingtime-gun.cocktime)*0.1F);
				}
				gun.obj_model.renderPart("mat25");
			}
			GL11.glPopMatrix();//glend11
		}
		
	}
	
	
	public float ADS_X(KKItemGunBase gun){
		{
			return gun.model_x_ads;
		}
	}
	public float ADS_Y(KKItemGunBase gun){
		{
			return gun.model_y_ads;
		}
	}
	public float ADS_Z(KKItemGunBase gun){
		{
			return gun.model_z_ads;
		}
	}
	
	
	private void renderarm(EntityPlayer entityplayer, ItemStack itemstack, KKItemGunBase gun){
		ItemStack leftitem = ((EntityPlayer) (entityplayer)).func_184592_cb();
		NBTTagCompound nbt = itemstack.func_77978_p();
		boolean cocking = nbt.func_74767_n("Cocking");
		int cockingtime = nbt.func_74762_e("CockingTime");
		boolean recoiled = nbt.func_74767_n("Recoiled");
		int recoiledtime = nbt.func_74762_e("RecoiledTime");
		{
			if (itemstack.func_77952_i() != itemstack.func_77958_k())
			{
				GL11.glPushMatrix();//glstart1
				GL11.glTranslatef(gun.arm_r_posx,gun.arm_r_posy, gun.arm_r_posz);
				if(cockingtime != 0)
				{
					GL11.glTranslatef(0,1.7F, 0);
					if(cockingtime > 0 && cockingtime < (gun.cocktime/2)){
						GL11.glTranslatef(0F, 0F, -cockingtime*0.1F);
						GL11.glRotatef(cockingtime * 3, -1.0F, 1.0F, 1.0F);
					}else if(cockingtime <= gun.cocktime){
						GL11.glTranslatef(0F, 0F, (cockingtime-gun.cocktime)*0.1F);
						GL11.glRotatef((cockingtime-gun.cocktime) * 3, 1.0F, -1.0F, -1.0F);
					}
				}
				gun.arm_model.renderPart("rightarm");
				GL11.glPopMatrix();//glend1
			}else{
				GL11.glPushMatrix();//glstart1
				for(int kais = 0; kais <= gun.mat_rk_rightarm;++kais){
					renderreload(gun, kais, gun.mat_r_rightarm);
				}
				gun.arm_model.renderPart("rightarm");
				GL11.glPopMatrix();//glend1
			}
			
		
		
		if (itemstack.func_77952_i() != itemstack.func_77958_k()) {
			GL11.glTranslatef(gun.arm_l_posx,gun.arm_l_posy, gun.arm_l_posz);
			if(gun.cock_left){
	        	if(cockingtime <= 0){
				}else{
					if(cockingtime > 0 && cockingtime < (gun.cocktime/2)){
						GL11.glTranslatef(0F, 0F, -cockingtime*0.1F);
					}else{
						GL11.glTranslatef(0F, 0F, (cockingtime-gun.cocktime)*0.1F);
					}
				}
	        }
			
			if(gun.knife && entityplayer.field_70733_aJ > 0.0F)
			{
				float f1 = entityplayer.field_70733_aJ;
				GL11.glTranslatef(f1*2,0, f1*3);
				GL11.glRotatef(60, 0.0F, 1.0F, 0.0F);
			}
		//	if(leftitem == null)
			{
				gun.arm_model.renderPart("leftarm");
			}
			
		}else{
		//	if(leftitem == null)
			{
				for(int kais = 0; kais <= gun.mat_rk_leftarm;++kais){
					renderreload(gun, kais, gun.mat_r_leftarm);
				}
				gun.arm_model.renderPart("leftarm");
			}
		}
		}
	}
	
	private static void renderreload(KKItemGunBase gun, int kaisu, String[] mat){
		if(kaisu != 0){
			kaisu = kaisu - 1;
		}
		int ka = 20 * kaisu; 
		if(mat != null){
			float bai = Float.parseFloat(mat[18 + ka]);
			float bairote = Float.parseFloat(mat[19 + ka]);
			if(gun.retime >= Integer.parseInt(mat[1 + ka]) && gun.retime <= Integer.parseInt(mat[2 + ka])){
				int time = gun.retime - Integer.parseInt(mat[1 + ka]);
				GL11.glTranslatef(Float.parseFloat(mat[3 + ka]),Float.parseFloat(mat[4 + ka]),Float.parseFloat(mat[5 + ka]));
				GL11.glTranslatef(Float.parseFloat(mat[6 + ka]),Float.parseFloat(mat[7 + ka]),Float.parseFloat(mat[8 + ka]));
				GL11.glRotatef(Float.parseFloat(mat[9 + ka]) + (time * bairote * Float.parseFloat(mat[15 + ka])), 1.0F, 0.0F, 0.0F);
				GL11.glRotatef(Float.parseFloat(mat[10 + ka]) + (time * bairote * Float.parseFloat(mat[16 + ka])), 0.0F, 1.0F, 0.0F);
				GL11.glRotatef(Float.parseFloat(mat[11 + ka]) + (time * bairote * Float.parseFloat(mat[17 + ka])), 0.0F, 0.0F, 1.0F);
				GL11.glTranslatef(
						time * Float.parseFloat(mat[12 + ka]) * bai,
						time * Float.parseFloat(mat[13 + ka]) * bai,
						time * Float.parseFloat(mat[14 + ka]) * bai
						);
				//GL11.glRotatef(Float.parseFloat(mat[9 + ka]) + gun.retime * bairote, Float.parseFloat(mat[15 + ka]), 0.0F, 0.0F);
				//GL11.glRotatef(Float.parseFloat(mat[10 + ka]) + gun.retime * bairote, 0.0F, Float.parseFloat(mat[16 + ka]), 0.0F);
				//GL11.glRotatef(Float.parseFloat(mat[11 + ka]) + gun.retime * bairote, 0.0F, 0.0F, Float.parseFloat(mat[17 + ka]));
				GL11.glTranslatef(-Float.parseFloat(mat[3 + ka]),-Float.parseFloat(mat[4 + ka]),-Float.parseFloat(mat[5 + ka]));
			}
		}
	}
	
	
	
	public boolean on = true;
	@SideOnly(Side.CLIENT)
    @SubscribeEvent
	  public void rendergunthird(RenderLivingEvent.Pre event)
	  {
		EntityLivingBase entity = (EntityLivingBase) event.getEntity();
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		EntityPlayer entityplayer = minecraft.field_71439_g;
		ItemStack itemstack = entity.func_184614_ca();
		ItemStack itemstackl = entity.func_184592_cb();
		
		if(on) {
		for (Render render : Minecraft.func_71410_x().func_175598_ae().field_78729_o.values()) {
	          if ((render instanceof RenderLivingBase))
	          {
	            RenderLivingBase renderbase = (RenderLivingBase)render;
	            if ((renderbase.func_177087_b() instanceof ModelBiped))
	            {
	            	renderbase.func_177094_a(new LayerKKGunBase(renderbase));
	            	//System.out.println(String.format("road"));
	              on = false;
	            }
	          }
	     }
		}
	  }
	
	/*@SideOnly(Side.CLIENT)
    @SubscribeEvent
	  public void rendergunthirdmain(RenderPlayerEvent.Pre event)
	  {
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		EntityPlayer entityplayer = minecraft.player;
		ItemStack itemstack = ((EntityPlayer) (entityplayer)).getHeldItemMainhand();
		ItemStack itemstackl = ((EntityPlayer) (entityplayer)).getHeldItemOffhand();
		if (itemstack != null && itemstack.getItem() instanceof KKItemGunBase && itemstack.hasTagCompound()) {//item
			this.rendergunthird2(entityplayer, itemstack, true, event.getPartialRenderTick());
		}//item
		if (itemstackl != null && itemstackl.getItem() instanceof KKItemGunBase && itemstackl.hasTagCompound()) {//item
			this.rendergunthird2(entityplayer, itemstackl, false, event.getPartialRenderTick());
		}//item
	  }
	
	
	  public void rendergunthird2(EntityPlayer entityplayer, ItemStack itemstack, boolean side, float tick){
			int xxx = 1;
			if(!side){
				xxx = -1;
			}
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		if (itemstack != null && itemstack.getItem() instanceof KKItemGunBase) {//item
			KKItemGunBase gun = (KKItemGunBase) itemstack.getItem();
				GL11.glPushMatrix();
				GL11.glEnable(GL12.GL_RESCALE_NORMAL);
				{
					float f5 = 0.0F;
		            float f6 = 0.0F;
		            f5 = this.F5(entityplayer, tick);
		            f6 = this.F6(entityplayer, tick);
					
					boolean flag = entityplayer instanceof EntityLivingBase && ((EntityLivingBase)entityplayer).getTicksElytraFlying() > 4;
					float f = 1.0F;
			        if (flag)
			        {
			            f = (float)(entityplayer.motionX * entityplayer.motionX + entityplayer.motionY * entityplayer.motionY + entityplayer.motionZ * entityplayer.motionZ);
			            f = f / 0.2F;
			            f = f * f * f;
			        }
			        if (f < 1.0F)
			        {
			            f = 1.0F;
			        }
			        float x = MathHelper.cos(f6 * 0.6662F + (float)Math.PI) * 2.0F * f5 * 0.5F / f;
			        if(entityplayer.isHandActive()){
			        	GL11.glRotatef(180F, 0.0F, 1.0F, 0.0F);
						GL11.glRotatef(180-entityplayer.rotationYawHead, 0.0F, 1.0F, 0.0F);
						if(entityplayer.isSneaking()){
							GL11.glTranslatef(-0.36F * xxx,1.2F,0F);
						}else{
			        	GL11.glTranslatef(-0.36F * xxx,1.45F,0F);
						}
			        	GL11.glRotatef(entityplayer.rotationPitch, 1.0F, 0.0F, 0.0F);
			        	GL11.glTranslatef(0,0F,0.30F);
			        }else{
			        	GL11.glRotatef(180F, 0.0F, 1.0F, 0.0F);
						GL11.glRotatef(180-entityplayer.renderYawOffset, 0.0F, 1.0F, 0.0F);
						if(entityplayer.isSneaking()){
							GL11.glTranslatef(-0.36F * xxx,1.2F,0.0F);
						}else{
			        	GL11.glTranslatef(-0.36F * xxx,1.375F,0.0F);
						}
	                    {
	                        GlStateManager.rotate(x * (180F / (float)Math.PI) * xxx, 1.0F, 0.0F, 0.0F);
	                        GL11.glTranslatef(0,-0.6F,0.2F);
	                    }
						{
						GL11.glRotatef(gun.modek_third_offset_rote_x, 1.0F, 0.0F, 0.0F);//GL11.glRotatef(70F, 1.0F, 0.0F, 0.0F);
						}
			        }
			        GL11.glScalef(0.5F, 0.5F, 0.5F);
					GL11.glScalef(0.5F, 0.5F, 0.5F);
					GL11.glScalef(0.75F, 0.75F, 0.75F);
			        
			        
				}
				Minecraft.getMinecraft().renderEngine.bindTexture(new ResourceLocation(gun.obj_tex));
				gun.obj_model.renderPart("mat1");
				{
					GL11.glPushMatrix();//flashs
					NBTTagCompound nbt = itemstack.getTagCompound();
					boolean cocking = nbt.getBoolean("Cocking");
					int cockingtime = nbt.getInteger("CockingTime");
					boolean recoiled = nbt.getBoolean("Recoiled");
					int recoiledtime = nbt.getInteger("RecoiledTime");
					if (!recoiled)
					{
						GL11.glTranslatef(0.0F, 0.0F, gun.model_cock_z);//0, 0, -0.4
						gun.obj_model.renderPart("mat2");
						GL11.glTranslatef(0.0F, 0.0F, -gun.model_cock_z);
						this.mat25(gun, false, cockingtime);
						this.rendersight(entityplayer, itemstack, gun);
					}else{
						gun.obj_model.renderPart("mat2");
						this.mat25(gun, false, cockingtime);
						this.rendersight(entityplayer, itemstack, gun);
					}
					GL11.glPopMatrix();//flashe
				}
				gun.obj_model.renderPart("mat3");
				gun.obj_model.renderPart("mat20");
				gun.obj_model.renderPart("mat21");
				GL11.glPushMatrix();//flashs
				Minecraft.getMinecraft().renderEngine.bindTexture(new ResourceLocation(gun.flash_tex));
				GL11.glTranslatef(gun.flash_posx,gun.flash_posy, gun.flash_posz);//0,1,6
				//if ((!gun.recoilreBolts(itemstack) || !gun.cycleBolt(itemstack)))
				GL11.glPopMatrix();//flashe
				GL11.glDisable(GL12.GL_RESCALE_NORMAL);
				GL11.glPopMatrix();
		}//item
	  }*/
	
	public float F6(EntityLivingBase entity, float partialTicks){
 		float f6 = 0;
 		if (!entity.func_184218_aH())
        {
            f6 = entity.field_184619_aG - entity.field_70721_aZ * (1.0F - partialTicks);
            if (entity.func_70631_g_())
            {
                f6 *= 3.0F;
            }
        }
 		return f6;
 	}
 	public float F5(EntityLivingBase entity, float partialTicks){
 		float f5 = 0;
 		if (!entity.func_184218_aH())
        {
            f5 = entity.field_184618_aE + (entity.field_70721_aZ - entity.field_184618_aE) * partialTicks;
            if (f5 > 1.0F)
            {
                f5 = 1.0F;
            }
        }
 		return f5;
 	}
	
	

}
